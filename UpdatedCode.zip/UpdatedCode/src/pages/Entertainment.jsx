import React from 'react';
import { useSearchParams } from 'react-router-dom';
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

const Entertainment = () => {
  const [searchParams] = useSearchParams();
  const location = searchParams.get('location');

  const entPlans = plansData.filter(plan =>
    plan.category === 'entertainment' &&
    (!location || plan.locations?.includes(location))
  );

  return (
    <section className="min-h-screen px-5 py-12 md:px-[5%] font-poppins bg-gray-50">
      <h1 className="mb-6 text-4xl font-bold text-primary text-center">
        Entertainment Add-ons
      </h1>

      {location && (
        <p className="mb-6 text-center text-gray-600">
          Showing add-ons available in <b>{location}</b>
        </p>
      )}

      {entPlans.length > 0 ? (
        <div className="max-w-7xl mx-auto">
          <PlanList items={entPlans} />
        </div>
      ) : (
        <p className="mt-16 text-center text-gray-500">
          No entertainment plans available for this location.
        </p>
      )}
    </section>
  );
};

export default Entertainment;
