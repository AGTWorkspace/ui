import React from 'react';
import { useSearchParams } from 'react-router-dom';
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

const Device = () => {
  const [searchParams] = useSearchParams();
  const location = searchParams.get('location');

  const devices = plansData.filter(plan =>
    plan.category === 'device' &&
    (!location || plan.locations?.includes(location))
  );

  return (
    <section className="min-h-screen px-5 py-12 md:px-[5%] font-poppins bg-gray-50">
      <h1 className="mb-6 text-4xl font-bold text-primary text-center">
        Devices & Accessories
      </h1>

      {location && (
        <p className="mb-6 text-center text-gray-600">
          Showing devices available in <b>{location}</b>
        </p>
      )}

      {devices.length > 0 ? (
        <div className="max-w-7xl mx-auto">
          <PlanList items={devices} />
        </div>
      ) : (
        <p className="mt-16 text-center text-gray-500">
          No devices available for this location.
        </p>
      )}
    </section>
  );
};

export default Device;
