import React from 'react';
import { Link } from 'react-router-dom';

const NotFound = () => {
    return (
        <div className="flex flex-col items-center justify-center min-h-[70vh] text-center p-8 font-poppins">
            <h1 className="mb-4 text-7xl font-extrabold text-danger">404</h1>
            <h2 className="mb-4 text-3xl font-semibold text-gray-700">Page Not Found</h2>
            <p className="mb-8 text-lg text-gray-500">The page you are looking for does not exist or has been moved.</p>
            
            {/* Button: Pill shape and primary color */}
            <Link 
                to="/" 
                className="px-8 py-3 font-semibold text-white transition duration-300 rounded-full bg-primary bg-blue-800 shadow-md hover:bg-green-800 shadow-md"
            >
                Go to Home
            </Link>
        </div>
    );
};

export default NotFound;