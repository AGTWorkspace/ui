import React from 'react';
import { useSearchParams } from 'react-router-dom';
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

const PostpaidPlans = () => {
  const [searchParams] = useSearchParams();
  const location = searchParams.get('location');

  const postpaidPlans = plansData.filter(plan =>
    plan.category === 'postpaid' &&
    (!location || plan.locations?.includes(location))
  );

  return (
    <section className="min-h-screen pt-12 bg-gray-50 font-poppins">
      <div className="relative pt-12 pb-12 mb-16 bg-white shadow-inner">
        <div className="max-w-4xl px-4 mx-auto text-center">
          <h1 className="mb-4 text-5xl font-black text-primary">
            Unmatched Postpaid Freedom
          </h1>

          {location && (
            <p className="text-gray-600">
              Showing plans available in <span className="font-semibold">{location}</span>
            </p>
          )}
        </div>
      </div>

      {postpaidPlans.length > 0 ? (
        <div className="grid grid-cols-1 gap-10 px-6 max-w-7xl mx-auto -mt-20">
          <PlanList items={postpaidPlans} />
        </div>
      ) : (
        <p className="mt-20 text-center text-gray-500">
          No postpaid plans available for this location.
        </p>
      )}
    </section>
  );
};

export default PostpaidPlans;
