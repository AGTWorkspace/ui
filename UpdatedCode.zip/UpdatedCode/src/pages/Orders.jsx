import React, { useEffect, useState } from 'react';

const Orders = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const storedOrders =
      JSON.parse(localStorage.getItem('orders')) || [];
    setOrders(storedOrders);
  }, []);

  return (
    <section className="min-h-screen px-5 py-12 md:px-[5%] bg-gray-50 font-poppins">
      <h1 className="text-3xl font-bold text-primary mb-8">
        My Orders
      </h1>

      {orders.length === 0 ? (
        <div className="bg-white p-10 rounded-xl text-center shadow">
          <p className="text-gray-500">No orders found.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {orders.map((order) => (
            <div
              key={order.orderId}
              className="bg-white rounded-2xl shadow-lg p-6 border"
            >
              {/* TOP */}
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h2 className="text-xl font-bold text-primary">
                    {order.description}
                  </h2>
                  <p className="text-sm text-gray-500">
                    Order ID: {order.orderId}
                  </p>
                </div>

                <span className="px-4 py-1 text-sm rounded-full bg-green-100 text-green-700 font-semibold">
                  {order.state}
                </span>
              </div>

              {/* DETAILS */}
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <p><strong>Customer ID:</strong> {order.customerId}</p>
                <p><strong>Product:</strong> {order.productDetails}</p>
                <p><strong>Order Date:</strong> {order.orderDate}</p>
                <p><strong>Payment Due:</strong> {order.paymentDueDate}</p>
              </div>

              <hr className="my-4" />

              {/* PRICE */}
              <div className="flex justify-between text-sm">
                <span>Base Price</span>
                <span>₹{order.basePrice}</span>
              </div>

              <div className="flex justify-between text-sm text-green-600">
                <span>
                  Discount ({order.discount_pct}%)
                </span>
                <span>-₹{order.discount_pct}</span>
              </div>

              <div className="flex justify-between text-lg font-bold mt-2">
                <span>Total Paid</span>
                <span className="text-primary">
                  ₹{order.finalPrice}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};

export default Orders;
