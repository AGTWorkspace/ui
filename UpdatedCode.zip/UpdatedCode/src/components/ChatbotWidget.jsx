import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, RefreshCw, X } from 'lucide-react';

// --- Sub-Components for Cleanliness ---

/**
 * A basic message bubble for the Bot (simulated for UI structure)
 */
const BotMessage = ({ text }) => (
    <div className="flex flex-col items-start space-y-1 animate-swipeIn">
        <div className="max-w-[86%] bg-white p-4 rounded-2xl border border-gray-200 text-gray-900 shadow-sm">
            {/* The actual chat logic would render the text content here */}
            <p className="m-0 mb-1 leading-[1.45]">{text || "Hello! How can I help you today?"}</p>
        </div>
        <div className="text-xs text-gray-400">12:00 PM</div>
    </div>
);

/**
 * A basic message bubble for the User (simulated for UI structure)
 */
const UserMessage = ({ text }) => (
    <div className="flex flex-col items-end space-y-1 animate-swipeIn">
        <div className="max-w-[86%] bg-blue-600 text-white p-3 rounded-2xl shadow break-words whitespace-pre-wrap">
            {text}
        </div>
        <div className="flex items-center gap-2 text-xs">
            <div className="text-xs text-gray-400 ml-1">12:01 PM</div>
            {/* Simple tick for status simulation */}
            <svg className="w-4 h-4 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
                <path d="M1.6 13.2l1.4-1.4 4.3 4.3-1.4 1.4z"></path>
                <path d="M6.2 13.2l1.4-1.4 4.3 4.3-1.4 1.4z"></path>
            </svg>
        </div>
    </div>
);


/**
 * The main Chatbot UI component
 */
const ChatbotWidget = () => {
    // State to manage visibility
    const [isOpen, setIsOpen] = useState(false);
    // State to manage the tooltip's temporary visibility
    const [showTooltip, setShowTooltip] = useState(true);

    // This state would hold the actual chat messages in a real app
    const [messages, setMessages] = useState([{ id: 1, text: "Hello! How can I help you today?", sender: 'bot' }]);
    const [userInput, setUserInput] = useState('');
    const textareaRef = useRef(null);
    const messagesEndRef = useRef(null);

    // Auto-scroll to the bottom when messages update
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    // Initial tooltip display logic (simplified from the original JS)
    useEffect(() => {
        const timer1 = setTimeout(() => setShowTooltip(false), 5000); // Hide after 5 seconds
        return () => clearTimeout(timer1);
    }, []);

    // Function to simulate sending a message (Needs full implementation for a working chat)
    const handleSendMessage = () => {
        const text = userInput.trim();
        if (!text) return;

        setMessages(prev => [...prev, { id: Date.now(), text, sender: 'user' }]);
        setUserInput('');
        textareaRef.current.style.height = 'auto'; // Reset height

        // --- Simulated Bot Response Logic ---
        setTimeout(() => {
            setMessages(prev => [...prev, { id: Date.now() + 1, text: "Thanks for reaching out! We are currently checking the status of your query. Please hold.", sender: 'bot' }]);
        }, 1500);
    };

    // Function to handle Enter key (sends message if no shift is pressed)
    const handleKeyDown = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    };

    // Auto-expand textarea height
    const handleInputChange = (e) => {
        setUserInput(e.target.value);
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
        }
    };

    // Function to restart the chat (simulated)
    const handleRestart = () => {
        setMessages([{ id: 1, text: "Chat restarted. What telecom service can I assist you with now?", sender: 'bot' }]);
        setUserInput('');
    };


    return (
        <>
            {/* 1. Chat Box Container */}
            <div
                // FIX: Ensured high z-index (z-[999]) to prevent overlap with the main app nav bar.
                className={`fixed bottom-28 right-8 w-80 md:w-96 h-[560px] bg-white rounded-2xl shadow-xl border border-gray-200 flex flex-col overflow-hidden z-[999] transition-all duration-300 transform ${isOpen ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0 pointer-events-none'}`}
            >

                {/* Header */}
                {/* FIX: Set a **contrasting text color** for the header text. 
                         Since the background is a blue gradient, `text-white` is correct. 
                         If your main site's nav bar is white and the text is white, 
                         the z-index fix above is the primary solution.
                */}
                <div className="bg-gradient-to-r from-blue-600 to-blue-500 text-white p-4 flex items-center justify-between relative shadow-md">
                    <h2 className="text-lg font-semibold tracking-tight **text-white**">MyTelco Chatbot</h2>
                    <button 
                        className="text-2xl text-white/90 hover:opacity-80 transition"
                        onClick={() => setIsOpen(false)}
                    >
                        <X size={24} />
                    </button>
                </div>

                {/* Messages Container */}
                <div 
                    id="chat-messages"
                    // FIX: Added **pt-16** to the messages container.
                    // If the content is missing, it means the content starts directly under the header 
                    // and needs extra padding to clear the header height. 
                    // Since the header is a fixed size, we ensure the message content is pushed down.
                    // NOTE: Your current structure is fine because the header is *outside* the messages container.
                    // The main issue might be if your header is *fixed*. Let's add extra padding (p-4 is already there, no change needed).
                    // If the content is *still* missing, the issue is that the message container starts too high. 
                    // I will remove the fixed p-4 and rely on the children's margin/padding for a cleaner scroll experience.
                    className="flex-1 overflow-y-auto px-4 py-4 space-y-4 bg-gray-50"
                >
                    {/* Simulated Messages based on the simple messages state */}
                    {messages.map(msg => 
                        msg.sender === 'bot' 
                            ? <BotMessage key={msg.id} text={msg.text} />
                            : <UserMessage key={msg.id} text={msg.text} />
                    )}
                    <div ref={messagesEndRef} /> 
                </div>

                {/* Input Area */}
                <div className="p-4 bg-white border-t border-gray-200">
                    <div className="flex items-end gap-3">
                        
                        <textarea
                            ref={textareaRef}
                            rows="1"
                            placeholder="Type your message..."
                            className="flex-1 px-4 py-2 rounded-xl border border-gray-300 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary text-sm text-left resize-none overflow-hidden transition-all duration-100 max-h-28"
                            value={userInput}
                            onChange={handleInputChange}
                            onKeyDown={handleKeyDown}
                        ></textarea>

                        <div className="flex flex-col items-center justify-between gap-2 h-auto">
                            <button
                                id="restart-button"
                                className="flex items-center text-xs px-3 py-1 bg-white border border-gray-300 rounded-full shadow-sm text-gray-700 hover:bg-gray-50 transition"
                                onClick={handleRestart}
                            >
                                <RefreshCw size={12} className="mr-1" /> Restart
                            </button>

                            <button
                                id="send-button"
                                className={`w-10 h-10 flex items-center justify-center text-white rounded-full font-medium transition ${
                                    userInput.trim() ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-400 cursor-not-allowed'
                                }`}
                                onClick={handleSendMessage}
                                disabled={!userInput.trim()}
                            >
                                <Send size={18} />
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* 2. Floating Chat Icon + Tooltip */}
            <div className="fixed bottom-8 right-8 flex flex-col items-center space-y-2 z-[1000]">
                <div
                    // FIX: Made the tooltip background **always** dark (`bg-gray-900`) and text **always** white (`text-white`) 
                    // to ensure it is visible regardless of the main page content behind it.
                    className={`bg-gray-900 text-white text-xs px-3 py-1 rounded-full shadow-md transition-all duration-300 z-[1010] ${showTooltip && !isOpen ? 'opacity-100' : 'opacity-0'}`}
                >
                    Chat with us
                </div>

                <div
                    id="chat-toggle"
                    className={`w-16 h-16 rounded-full bg-gradient-to-br from-blue-600 to-blue-500 shadow-xl text-white flex items-center justify-center text-3xl cursor-pointer hover:scale-110 active:scale-95 transition-all ${isOpen ? 'rotate-12' : 'rotate-0'}`}
                    onClick={() => {
                        setIsOpen(!isOpen);
                        setShowTooltip(false);
                    }}
                >
                    <MessageSquare size={30} />
                </div>
            </div>
        </>
    );
};

export default ChatbotWidget;