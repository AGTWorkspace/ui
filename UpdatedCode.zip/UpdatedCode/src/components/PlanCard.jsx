import React from 'react';
import { useNavigate } from 'react-router-dom';

// Helper function to map Tailwind class to a defensive hex color
const getButtonColor = (buttonClass) => {
    if (buttonClass.includes('bg-danger')) return '#dc3545';
    if (buttonClass.includes('bg-accent')) return '#28a745';
    return '#007bff';
};

const PlanCard = ({ plan }) => {
    const navigate = useNavigate();
    const isPostpaid = plan.type === 'postpaid';
    const buttonHexColor = getButtonColor(plan.buttonClass || 'bg-primary');

    const handleChoosePlan = () => {
        navigate('/confirm-order', { state: { plan } });
    };

    return (
        <div 
            className={`p-8 bg-white rounded-2xl shadow-xl border-t-8 ${plan.borderColor || 'border-primary'} 
                        transition duration-300 hover:shadow-2xl hover:-translate-y-1 font-poppins 
                        flex flex-col h-full`}
        >
            {plan.badge && (
                <span className={`absolute top-0 right-0 px-4 py-1 text-xs font-bold text-white uppercase rounded-bl-xl ${plan.badgeColor || 'bg-primary'}`}>
                    {plan.badge}
                </span>
            )}

            <h3 className={`mb-4 text-3xl font-extrabold ${plan.borderColor === 'border-danger' ? 'text-danger' : 'text-primary'} 
                             pb-3 border-b-2 border-dashed border-gray-100`}>
                {plan.title}
            </h3>

            <div className="flex flex-col mb-6 p-4 border border-gray-100 rounded-lg shadow-inner bg-blue-50/50 space-y-4">
                <div className="text-center pb-2 border-b border-gray-200">
                    <small className="block text-sm text-gray-600 mb-1">Plan Price</small>
                    <strong className="block text-5xl font-black text-accent">{plan.price}</strong>
                </div>

                <div className="flex justify-between pt-2">
                    <div className="text-center flex-1 pr-2 border-r border-gray-200">
                        <strong className="block text-3xl font-bold text-primary">{plan.data}</strong>
                        <small className="text-gray-500 text-xs">
                            {isPostpaid ? 'Monthly Data' : 'Daily Data'}
                        </small>
                    </div>

                    <div className="text-center flex-1 pl-2">
                        <strong className="block text-3xl font-bold text-primary">{plan.validity}</strong>
                        <small className="text-gray-500 text-xs">Validity</small>
                    </div>
                </div>
            </div>

            {/* ✅ UPDATED BUTTON */}
            <button
                onClick={handleChoosePlan}
                style={{ backgroundColor: buttonHexColor }}
                className={`w-full py-3 font-semibold text-white rounded-full shadow-lg mt-auto
                            transition duration-300 ${plan.buttonClass || 'hover:opacity-90'}`}
            >
                {plan.buttonText || (isPostpaid ? 'Get New Connection' : 'Recharge Now')}
            </button>

            <details className="mt-6 pt-4 border-t border-gray-200">
                <summary className="cursor-pointer font-semibold text-primary hover:text-black">
                    View Key Benefits
                </summary>
                <div className="pt-4 space-y-3 text-sm text-gray-700">
                    {plan.details.map((detail, index) => (
                        <div key={index} className="flex items-start">
                            <svg className="w-4 h-4 mr-2 mt-1 text-accent" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16z" />
                            </svg>
                            <p>{detail}</p>
                        </div>
                    ))}
                </div>
            </details>
        </div>
    );
};

export default PlanCard;

