// src/components/PlanList.jsx
import React from 'react';
import PlanCard from './PlanCard';

const DeviceCard = ({ item }) => (
  <div className="p-6 bg-white rounded-xl shadow-lg">
    <h3 className="text-xl font-semibold mb-2 text-primary">{item.offeringDetails.name}</h3>
    <p className="text-sm text-gray-600 mb-3">{item.description}</p>
    {item.specification && (
      <ul className="text-sm text-gray-700 mb-3">
        {Object.entries(item.specification).map(([k, v]) => <li key={k}><strong>{k}:</strong> {v}</li>)}
      </ul>
    )}
    <div className="flex items-center justify-between mt-4">
      <div className="text-lg font-bold">{typeof item.price === 'number' ? `₹ ${item.price}` : item.price}</div>
      <button className="px-4 py-2 rounded-full bg-primary text-black">Buy</button>
    </div>
  </div>
);

const PlanList = ({ items }) => {
  return (
    <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {items.map(item => {
        // use PlanCard for plans (pre-paid/postpaid/fiber/entertainment/bundle if shape fits)
        if (['pre-paid', 'postpaid', 'fiber-net', 'entertainment', 'bundle'].includes(item.category)) {
          // Create a normalized plan object to pass to PlanCard
          const plan = {
            id: item.id,
            type: item.category === 'postpaid' ? 'postpaid' : 'prepaid',
            title: item.offeringDetails.name || item.offeringDetails.plan?.serviceId,
            price: typeof item.price === 'number' ? `₹ ${item.price}` : item.price,
            data: item.offeringDetails.plan?.data || '',
            validity: item.validityMonths ? `${item.validityMonths}m` : '—',
            badge: item.isRecurring ? 'Recurring' : undefined,
            badgeColor: item.isRecurring ? 'bg-accent' : 'bg-primary',
            borderColor: item.borderColor || '',
            buttonClass: item.buttonClass || 'bg-primary',
            buttonText: item.buttonText || 'Choose Plan',
            details: item.offeringDetails.plan?.features ? Object.keys(item.offeringDetails.plan.features).map(k => {
              const v = item.offeringDetails.plan.features[k];
              if (Array.isArray(v)) return `${k}: ${v.join(', ')}`;
              return `${k}: ${v}`;
            }) : (item.specification ? Object.entries(item.specification).map(([k,v]) => `${k}: ${v}`) : ['—'])
          };
          return <PlanCard key={item.id} plan={plan} />;
        }

        // fallback device card
        return <DeviceCard key={item.id} item={item} />;
      })}
    </div>
  );
};

export default PlanList;
