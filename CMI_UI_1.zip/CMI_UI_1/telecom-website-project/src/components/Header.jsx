// src/components/Header.jsx
import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { MapPin, LogOut } from 'lucide-react';
import LoginModal from './LoginModal';

const Header = ({ isLoggedIn: initialIsLoggedIn, mobileNumber: initialMobileNumber }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(initialIsLoggedIn || false);
  const [mobileNumber, setMobileNumber] = useState(initialMobileNumber || '');
  const [locationInput, setLocationInput] = useState('');

  const navigate = useNavigate();
  const routeLocation = useLocation();

  /* ---------------- SYNC FROM APP ---------------- */
  useEffect(() => {
    setIsLoggedIn(initialIsLoggedIn);
    setMobileNumber(initialMobileNumber);
  }, [initialIsLoggedIn, initialMobileNumber]);

  /* ---------------- LOGIN ---------------- */
  const handleLoginSuccess = (number) => {
    setIsLoggedIn(true);
    setMobileNumber(number);
    setIsModalOpen(false);
  };

  /* ---------------- LOGOUT ---------------- */
  const handleLogout = () => {
    setIsLoggedIn(false);
    setMobileNumber('');
  };

  /* ---------------- SEARCH ---------------- */
  const handleSearch = () => {
    if (!locationInput.trim()) return;

    const targetRoute = routeLocation.pathname.includes('postpaid')
      ? '/postpaid'
      : routeLocation.pathname.includes('recharge')
      ? '/recharge'
      : routeLocation.pathname;

    navigate(`${targetRoute}?location=${encodeURIComponent(locationInput.trim())}`);
  };

  return (
    <>
      <header className="sticky top-0 z-50 bg-white shadow-md font-poppins">
        <div className="flex items-center justify-between px-[5%] py-4">

          {/* LOGO */}
          <div className="text-3xl font-bold text-primary">MyTelco</div>

          {/* NAV */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/" className="font-semibold text-gray-700 hover:text-primary transition">Home</Link>
            <Link to="/recharge" className="font-semibold text-gray-700 hover:text-primary transition">Prepaid</Link>
            <Link to="/postpaid" className="font-semibold text-gray-700 hover:text-primary transition">Postpaid</Link>
            <Link to="/fiber" className="font-semibold text-gray-700 hover:text-primary transition">Fiber-net</Link>
            <Link to="/entertainment" className="font-semibold text-gray-700 hover:text-primary transition">Entertainment</Link>
            <Link to="/device" className="font-semibold text-gray-700 hover:text-primary transition">Devices</Link>
            <Link to="/bundle" className="font-semibold text-gray-700 hover:text-primary transition">Bundles</Link>
            <Link to="/support" className="font-semibold text-gray-700 hover:text-primary transition">Support</Link>

            {/* 📍 LOCATION SEARCH */}
            <div className="ml-4 flex items-center bg-gray-100 border border-gray-300 rounded-full px-4 py-2
                            shadow-sm focus-within:ring-2 focus-within:ring-gray-400 transition">

              <MapPin size={16} className="text-gray-600 mr-2" />

              <input
                type="text"
                value={locationInput}
                onChange={(e) => setLocationInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Enter your State"
                className="bg-transparent text-sm text-gray-800 placeholder-gray-500
                           focus:outline-none w-36"
              />

              <button
                onClick={handleSearch}
                className="ml-3 px-4 py-1.5 text-sm font-semibold text-white rounded-full
                           bg-gray-900 hover:bg-gray-800 transition shadow-md"
              >
                Search
              </button>
            </div>
          </nav>

          {/* RIGHT SIDE */}
          <div className="flex items-center gap-3">
            {isLoggedIn ? (
              <>
                <div className="px-5 py-2 font-semibold text-primary border-2 border-primary rounded-full">
                  User ***{mobileNumber?.slice(-4)}
                </div>

                <button
                  onClick={handleLogout}
                  className="flex items-center gap-1 px-4 py-2 text-sm font-semibold
                             text-red-600 border border-red-500 rounded-full
                             hover:bg-red-50 transition"
                >
                  <LogOut size={16} />
                  Logout
                </button>
              </>
            ) : (
              <button
                style={{ backgroundColor: '#007bff' }}
                className="px-6 py-3 font-semibold text-white rounded-full shadow-lg
                           hover:opacity-90 transition"
                onClick={() => setIsModalOpen(true)}
              >
                Login / Recharge
              </button>
            )}
          </div>
        </div>
      </header>

      {/* LOGIN MODAL */}
      <LoginModal
        isVisible={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />
    </>
  );
};

export default Header;
