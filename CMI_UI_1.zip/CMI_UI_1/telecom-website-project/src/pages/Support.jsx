// src/pages/Support.jsx
import React, { useState } from 'react';

const faqs = [
  {
    question: 'How do I recharge my prepaid/postpaid plan?',
    answer: 'You can recharge using our website, mobile app, or authorized retailers. Enter your mobile number and select a plan to complete payment securely.',
  },
  {
    question: 'How can I check my data balance?',
    answer: 'Log in to your account on our website or app to see real-time usage details and remaining data balance.',
  },
  {
    question: 'How to pay my postpaid bill?',
    answer: 'Go to the Postpaid section and click "Pay Bill". You can use netbanking, UPI, or credit/debit cards.',
  },
  {
    question: 'How do I report a network issue?',
    answer: 'Contact our support team via call, chat, or submit a request using the form below. We will resolve it as soon as possible.',
  },
];

const Support = () => {
  const [activeIndex, setActiveIndex] = useState(null);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Support request submitted! Our team will contact you soon.');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <section className="min-h-screen px-5 py-12 md:px-[5%] font-poppins bg-gradient-to-b from-blue-50 via-purple-50 to-pink-50">
      <h1 className="mb-8 text-4xl md:text-5xl font-bold text-primary text-center">Customer Support</h1>
      <p className="mb-12 text-center text-gray-700 max-w-3xl mx-auto">
        Need help with your plan, device, or network? Find answers to common questions or reach out to us directly.
      </p>

      {/* QUICK LINKS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-7xl mx-auto mb-12">
        {['Billing & Payments', 'Recharge & Plans', 'Network Issues', 'Devices & Services'].map((item, i) => (
          <div
            key={i}
            className="p-6 bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 text-white shadow-lg rounded-xl hover:scale-105 transition transform cursor-pointer font-semibold text-center"
          >
            {item}
          </div>
        ))}
      </div>

      {/* FAQ SECTION */}
      <div className="max-w-3xl mx-auto mb-12">
        <h2 className="mb-6 text-2xl md:text-3xl font-bold text-primary text-center">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-lg p-5 cursor-pointer hover:shadow-2xl transition"
              onClick={() => setActiveIndex(activeIndex === index ? null : index)}
            >
              <div className="flex justify-between items-center">
                <h3 className="font-semibold text-gray-800">{faq.question}</h3>
                <span className="text-primary font-bold text-xl">{activeIndex === index ? '−' : '+'}</span>
              </div>
              {activeIndex === index && <p className="mt-3 text-gray-600">{faq.answer}</p>}
            </div>
          ))}
        </div>
      </div>

      {/* CONTACT FORM */}
      <div className="max-w-3xl mx-auto mb-12 p-8 rounded-xl bg-gradient-to-r from-purple-100 via-pink-100 to-red-100 shadow-lg">
        <h2 className="mb-6 text-2xl md:text-3xl font-bold text-primary text-center">Contact Us</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Your Name"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            required
          />
          <input
            type="email"
            placeholder="Your Email"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            required
          />
          <textarea
            placeholder="Your Message"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400 resize-none"
            rows={5}
            value={formData.message}
            onChange={(e) => setFormData({ ...formData, message: e.target.value })}
            required
          ></textarea>
          <button
            type="submit"
            className="w-full py-3 font-semibold text-white rounded-full bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 hover:opacity-90 transition shadow-md"
          >
            Submit
          </button>
        </form>
      </div>

      {/* SUPPORT INFO */}
      <div className="max-w-3xl mx-auto text-center text-gray-700 space-y-2">
        <p>Or reach us via:</p>
        <p>📞 Call: <span className="font-semibold text-gray-900">1800-123-4567</span></p>
        <p>💬 Live Chat available in app</p>
      </div>
    </section>
  );
};

export default Support;
