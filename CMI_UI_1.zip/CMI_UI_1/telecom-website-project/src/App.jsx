// src/App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Header from './components/Header';
import Footer from './components/Footer';
import LoginModal from './components/LoginModal';
import ChatbotWidget from './components/ChatbotWidget';

import HomePage from './pages/HomePage';
import RechargePlans from './pages/RechargePlans';
import PostpaidPlans from './pages/PostpaidPlans';
import NotFound from './pages/NotFound';
import FiberNet from './pages/FiberNet';
import Entertainment from './pages/Entertainment';
import Device from './pages/Device';
import Bundle from './pages/Bundle';
import Support from './pages/Support'; // <-- Import Support page

function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [mobileNumber, setMobileNumber] = useState('');

  const handleLoginSuccess = (number) => {
    setMobileNumber(number);
    setIsLoggedIn(true);
    setIsModalOpen(false);
  };

  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        <Header
          onShowLogin={() => setIsModalOpen(true)}
          isLoggedIn={isLoggedIn}
          mobileNumber={mobileNumber}
        />

        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/recharge" element={<RechargePlans />} />
            <Route path="/postpaid" element={<PostpaidPlans />} />
            <Route path="/fiber" element={<FiberNet />} />
            <Route path="/entertainment" element={<Entertainment />} />
            <Route path="/device" element={<Device />} />
            <Route path="/bundle" element={<Bundle />} />
            <Route path="/support" element={<Support />} /> {/* <-- Support route */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>

        <LoginModal
          isVisible={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onLoginSuccess={handleLoginSuccess}
        />

        <Footer />

        <ChatbotWidget />
      </div>
    </Router>
  );
}

export default App;
