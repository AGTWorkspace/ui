import React from 'react';
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

const FiberNet = () => {
  const fiberPlans = plansData.filter(p => p.category === 'fiber-net');
  return (
    <section className="min-h-screen px-5 py-12 md:px-[5%] font-poppins bg-gray-50">
      <h1 className="mb-6 text-4xl font-bold text-primary text-center">Fiber Net Plans</h1>
      <p className="mb-10 text-center text-gray-600">High-speed home broadband plans with router & installation options.</p>

      <div className="max-w-7xl mx-auto">
        <PlanList items={fiberPlans} />
      </div>
    </section>
  );
};

export default FiberNet;
