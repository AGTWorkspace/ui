import React from 'react';
import HeroCarousel from '../components/HeroCarousel';
import { Link } from 'react-router-dom';
import { ArrowUpRight, Wifi, Headset, Leaf, Smartphone } from 'lucide-react';

// Card for Today's Best Offers section
const PromoCard = ({ title, subtitle, borderColor }) => (
    <div className={`flex-none w-72 p-6 bg-white rounded-xl shadow-lg text-center border-l-4 ${borderColor} transition transform duration-300 hover:-translate-y-1 hover:shadow-xl`}>
        <h3 className="mb-2 text-xl font-semibold text-primary font-poppins">{title}</h3>
        <p className="text-gray-600 text-sm">{subtitle}</p>
    </div>
);

// Card for Why Choose Us section
const ValueItem = ({ title, subtitle, icon: Icon }) => (
    <div className="flex flex-col items-center p-8 bg-white rounded-xl shadow-lg transition duration-300 hover:shadow-xl hover:scale-[1.02] h-full font-poppins">
        <Icon className="mb-3 text-accent" size={36} />
        <h4 className="mb-1 text-lg font-semibold text-primary">{title}</h4>
        <p className="text-center text-sm text-gray-600">{subtitle}</p>
    </div>
);

// Card for Quick Links section
const QuickLinkCard = ({ title, subtitle, linkTo, icon: Icon }) => (
    <Link 
        to={linkTo} 
        className="flex flex-col items-center flex-1 max-w-xs p-8 bg-white rounded-xl shadow-lg border-t-4 border-primary 
                   transition transform duration-300 hover:-translate-y-1 hover:shadow-xl font-poppins"
    >
        <Icon className="mb-3 text-primary" size={40} />
        <h3 className="mb-1 text-xl font-semibold text-gray-800">{title}</h3>
        <p className="text-center text-sm text-gray-500">{subtitle}</p>
    </Link>
);


const HomePage = () => {
    return (
        <div className="min-h-screen pb-12 font-poppins">
            <HeroCarousel />

            {/* Promotional Slider Section */}
            <section className="p-8 mt-8 bg-gray-50">
                <h2 className="mb-8 text-3xl font-bold text-center text-primary">⚡ Today's Best Offers</h2>
                <div className="flex justify-center gap-6 pb-2 overflow-x-auto promo-card-container">
                    <PromoCard title="Truly Unlimited Data" subtitle="No daily limits! Stream, download, and game worry-free." borderColor="border-l-primary" />
                    <PromoCard title="Free OTT Bundle" subtitle="Get Disney+ Hotstar and SonyLIV included with any plan above ₹699." borderColor="border-l-accent" />
                    <PromoCard title="Family Plan Discount" subtitle="Add 4 members and save 25% on your total monthly bill." borderColor="border-l-danger" />
                    <PromoCard title="Flat 50 Cashback" subtitle="Get ₹50 cashback instantly on your first recharge using the App." borderColor="border-l-yellow-500" />
                </div>
            </section>

            {/* Key Value Propositions */}
            <section className="px-5 py-16 md:px-[5%] text-center">
                <h2 className="mb-12 text-3xl font-bold text-primary">Why Choose MyTelco?</h2>
                <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
                    <ValueItem title="Ultra-Low Latency 🚀" subtitle="Experience gaming and video conferencing without any lag. Powered by 5G." icon={ArrowUpRight} />
                    <ValueItem title="99.9% Uptime 📶" subtitle="India's most reliable network connection, guaranteed coverage." icon={Wifi} />
                    <ValueItem title="24/7 Priority Support 📞" subtitle="Dedicated customer service for instant solutions via chat, call, or App." icon={Headset} />
                    <ValueItem title="Green Network 🌱" subtitle="Committed to eco-friendly, sustainable network operations." icon={Leaf} />
                </div>
            </section>

            {/* Feature Grid (Quick Links) */}
            <section className="flex justify-center px-5 pt-5 pb-16 feature-grid gap-8">
                <QuickLinkCard title="📱 Recharge Now" subtitle="Quick top-ups & plan renewals." linkTo="/recharge" icon={Smartphone} />
                <QuickLinkCard title="🔗 New Connection" subtitle="Get a new SIM delivered to your home." linkTo="#new" icon={ArrowUpRight} />
                <QuickLinkCard title="📡 Pay Bill" subtitle="Clear your postpaid or broadband bills instantly." linkTo="#pay" icon={Wifi} />
            </section>
        </div>
    );
};

export default HomePage;