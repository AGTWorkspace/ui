// src/pages/RechargePlans.jsx
import React from 'react';
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

const RechargePlans = () => {
  const prepaidPlans = plansData.filter(p => p.category === 'pre-paid');

  return (
    <section className="min-h-screen px-5 py-12 md:px-[5%] font-poppins bg-gray-50">
      <h1 className="mb-4 text-4xl font-bold text-center text-primary">Prepaid Recharge Plans</h1>
      <p className="mb-12 text-center text-gray-600">Choose the best plan tailored for your data and entertainment needs.</p>

      <div className="max-w-7xl mx-auto">
        <PlanList items={prepaidPlans} />
      </div>
    </section>
  );
};

export default RechargePlans;
