import React from 'react';
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

const Entertainment = () => {
  const entPlans = plansData.filter(p => p.category === 'entertainment');
  return (
    <section className="min-h-screen px-5 py-12 md:px-[5%] font-poppins bg-gray-50">
      <h1 className="mb-6 text-4xl font-bold text-primary text-center">Entertainment Add-ons</h1>
      <p className="mb-10 text-center text-gray-600">OTT and streaming add-ons to enjoy your favourite content.</p>

      <div className="max-w-7xl mx-auto">
        <PlanList items={entPlans} />
      </div>
    </section>
  );
};

export default Entertainment;
