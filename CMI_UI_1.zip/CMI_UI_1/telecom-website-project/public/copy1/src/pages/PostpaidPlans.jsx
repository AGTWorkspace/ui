// src/pages/PostpaidPlans.jsx
import React from 'react';
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

const PostpaidPlans = () => {
  const postpaidPlans = plansData.filter(p => p.category === 'postpaid');

  return (
    <section className="min-h-screen pt-12 bg-gray-50 font-poppins">
      <div className="relative pt-12 pb-12 mb-16 overflow-hidden bg-white shadow-inner">
        <div className="relative max-w-4xl px-4 mx-auto text-center">
          <h1 className="mb-4 text-5xl font-black tracking-tight text-primary md:text-6xl">Unmatched Postpaid Freedom</h1>
          <p className="mb-8 text-xl text-gray-700 md:text-2xl">Explore our best 5G Family Plans with data rollover, priority support, and premium OTT subscriptions included.</p>
          <div className="inline-block px-8 py-3 text-sm font-bold text-gray uppercase bg-accent rounded-full shadow-xl transform hover:scale-105 transition duration-300">
            ⭐️ Priority, Perks & Power ⭐️
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-10 px-6 max-w-7xl mx-auto -mt-20">
        <PlanList items={postpaidPlans} />
      </div>

      <div className="max-w-4xl px-4 mx-auto mt-24 text-sm text-center text-gray-500">
        <p>*Taxes and regulatory fees may apply. All plans include 5G connectivity where available.</p>
      </div>
    </section>
  );
};

export default PostpaidPlans;
