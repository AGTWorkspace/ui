import React from 'react';
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

const Bundle = () => {
  const bundles = plansData.filter(p => p.category === 'bundle');
  return (
    <section className="min-h-screen px-5 py-12 md:px-[5%] font-poppins bg-gray-50">
      <h1 className="mb-6 text-4xl font-bold text-primary text-center">Bundles</h1>
      <p className="mb-10 text-center text-gray-600">Best combos: devices + plans for savings and perks.</p>

      <div className="max-w-7xl mx-auto">
        <PlanList items={bundles} />
      </div>
    </section>
  );
};

export default Bundle;
