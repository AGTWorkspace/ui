import React from 'react';
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

const Device = () => {
  const devices = plansData.filter(p => p.category === 'device');
  return (
    <section className="min-h-screen px-5 py-12 md:px-[5%] font-poppins bg-gray-50">
      <h1 className="mb-6 text-4xl font-bold text-primary text-center">Devices & Accessories</h1>
      <p className="mb-10 text-center text-gray-600">Phones, routers, and device protection services.</p>

      <div className="max-w-7xl mx-auto">
        <PlanList items={devices} />
      </div>
    </section>
  );
};

export default Device;
