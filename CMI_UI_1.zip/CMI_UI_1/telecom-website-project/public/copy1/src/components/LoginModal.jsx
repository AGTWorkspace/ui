import React, { useState, useEffect, useRef } from 'react';
import { X, Smartphone, CheckCircle } from 'lucide-react';

const LoginModal = ({ isVisible, onClose, onLoginSuccess }) => {
    // Hardcoded hex for primary color to force visibility
    const PRIMARY_COLOR = '#007bff';
    
    const [step, setStep] = useState('mobile'); 
    const [mobileInput, setMobileInput] = useState('');
    const [otpInput, setOtpInput] = useState(Array(6).fill(''));
    const [otpError, setOtpError] = useState(false);
    const [timer, setTimer] = useState(60);
    const timerRef = useRef(null);
    const otpRefs = useRef([]);

    // Reset state when modal closes/opens
    useEffect(() => {
        if (!isVisible) {
            setStep('mobile');
            setMobileInput('');
            setOtpInput(Array(6).fill(''));
            setOtpError(false);
            clearInterval(timerRef.current);
            setTimer(60);
        }
    }, [isVisible]);

    // Timer logic
    useEffect(() => {
        if (step === 'otp' && isVisible) {
            const startTimer = () => {
                clearInterval(timerRef.current);
                setTimer(60);
                timerRef.current = setInterval(() => {
                    setTimer((prev) => (prev > 0 ? prev - 1 : (clearInterval(timerRef.current), 0)));
                }, 1000);
            };
            startTimer();
        }
        return () => clearInterval(timerRef.current);
    }, [step, isVisible]);
    
    // --- Handlers ---
    const handleMobileSubmit = (e) => {
        e.preventDefault();
        if (mobileInput.length === 10 && !isNaN(mobileInput)) {
            setStep('otp');
            setTimeout(() => otpRefs.current[0]?.focus(), 50);
        } else {
            // Using a simple alert for demonstration, replace with a custom modal in production
            alert("Please enter a valid 10-digit mobile number."); 
        }
    };

    const handleOtpChange = (index, value) => {
        const char = value.slice(-1); 
        if (!/^\d*$/.test(char)) return; 

        const newOtp = [...otpInput];
        newOtp[index] = char;
        setOtpInput(newOtp);
        setOtpError(false);

        if (char && index < 5) {
            otpRefs.current[index + 1]?.focus();
        }
    };

    const handleOtpKeyDown = (index, e) => {
        if (e.key === 'Backspace' && !otpInput[index] && index > 0) {
            otpRefs.current[index - 1]?.focus();
        }
    };

    const handleOtpVerify = (e) => {
        e.preventDefault();
        const enteredOtp = otpInput.join('');
        const correctOtp = '123456'; 

        if (enteredOtp === correctOtp) {
            onLoginSuccess(mobileInput);
            onClose(); // Close on success
        } else {
            setOtpError(true);
            setOtpInput(Array(6).fill('')); 
            otpRefs.current[0]?.focus();
        }
    };

    const handleResend = () => {
        // Using a simple alert for demonstration, replace with a custom modal in production
        alert('Resending new OTP...'); 
        // Logic to restart the timer is already in the useEffect triggered by setTimer(60)
        setTimer(60);
    };

    if (!isVisible) return null;

    return (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black bg-opacity-85 font-poppins">
            {/* Modal Container: rounded-xl, shadow-2xl, and generous padding */}
            <div className="relative w-11/12 max-w-md p-10 bg-white rounded-xl shadow-2xl text-center">
                <button 
                    className="absolute text-3xl transition text-gray-400 hover:text-danger top-4 right-4" 
                    onClick={onClose}
                >
                    <X size={30} />
                </button>
                <h2 className="mb-6 text-3xl font-bold text-primary">Access Your Account</h2>

                {/* Mobile Input Stage */}
                {step === 'mobile' && (
                    <form onSubmit={handleMobileSubmit}>
                        <p className="mb-4 text-gray-700">Enter your **10-digit Mobile Number** to login or register.</p>
                        {/* Input Group: border-2 border-gray-300 and rounded-lg for the container */}
                        <div className="flex mb-8 overflow-hidden transition duration-300 border-2 border-gray-300 rounded-lg focus-within:border-primary">
                            {/* Country Code: bg-gray-100 and explicit border color */}
                            <span className="flex items-center px-4 py-3 font-semibold bg-gray-100 border-r border-gray-300 text-gray-700">+91</span>
                            <input
                                type="tel"
                                className="flex-grow p-3 text-lg border-none outline-none"
                                maxLength="10"
                                placeholder="e.g., 9876543210"
                                value={mobileInput}
                                onChange={(e) => setMobileInput(e.target.value)}
                                required
                            />
                        </div>
                        {/* Button: Pill shape and primary color */}
                        <button 
                            type="submit" 
                            style={{ backgroundColor: PRIMARY_COLOR }} // 💥 FIX APPLIED HERE
                            className="w-full py-3 font-semibold text-white transition rounded-full bg-primary hover:bg-blue-800 shadow-md"
                        >
                            Get OTP
                        </button>
                    </form>
                )}

                {/* OTP Verification Stage */}
                {step === 'otp' && (
                    <form onSubmit={handleOtpVerify}>
                        <p className="mb-5 text-accent font-semibold flex items-center justify-center">
                            <CheckCircle size={18} className="mr-2" /> OTP sent to: **+91 {mobileInput}**
                        </p>
                        
                        {/* OTP Input Group: Uses explicit dimensions and blue focus ring/shadow */}
                        <div className="flex justify-between gap-3 mb-6">
                            {otpInput.map((digit, index) => (
                                <input
                                    key={index}
                                    type="text"
                                    maxLength="1"
                                    className={`w-12 h-14 text-2xl font-semibold text-center border-2 rounded-lg outline-none ${
                                        otpError ? 'border-danger' : 'border-gray-300'
                                    } focus:border-primary focus:shadow-[0_0_0_3px_rgba(0,123,255,0.2)] transition duration-300`}
                                    value={digit}
                                    onChange={(e) => handleOtpChange(index, e.target.value)}
                                    onKeyDown={(e) => handleOtpKeyDown(index, e)}
                                    ref={el => otpRefs.current[index] = el}
                                    required
                                />
                            ))}
                        </div>
                        {otpError && <div className="mb-4 text-sm font-semibold text-danger">Invalid OTP. Please try again.</div>}

                        {/* Button: Pill shape and primary color */}
                        <button 
                            type="submit" 
                            style={{ backgroundColor: PRIMARY_COLOR }} // 💥 FIX APPLIED HERE
                            className="w-full py-3 font-semibold text-white transition rounded-full bg-primary hover:bg-blue-800 shadow-md"
                        >
                            Verify OTP
                        </button>
                        
                        <div className="flex items-center justify-center mt-6 space-x-2 text-sm text-gray-500">
                            {timer > 0 ? (
                                <span>Resend in {timer}s</span>
                            ) : (
                                <button type="button" className="text-primary hover:underline font-semibold" onClick={handleResend}>Resend OTP</button>
                            )}
                            <span className="text-gray-400">|</span> 
                            <button type="button" className="text-primary hover:underline font-semibold" onClick={() => setStep('mobile')}>Change Number</button>
                        </div>
                    </form>
                )}
            </div>
        </div>
    );
};

export default LoginModal;