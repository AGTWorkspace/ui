import React from 'react';

// Helper function to map Tailwind class to a defensive hex color
const getButtonColor = (buttonClass) => {
    if (buttonClass.includes('bg-danger')) return '#dc3545'; // For RedX/Danger plans
    if (buttonClass.includes('bg-accent')) return '#28a745'; // For Accent/Green plans
    // Default to primary color if no specific class is provided (e.g., bg-primary)
    return '#007bff'; 
};

const PlanCard = ({ plan }) => {
    const isPostpaid = plan.type === 'postpaid';
    const buttonHexColor = getButtonColor(plan.buttonClass || 'bg-primary');

    return (
        <div 
            className={`p-8 bg-white rounded-2xl shadow-xl border-t-8 ${plan.borderColor || 'border-primary'} 
                        transition duration-300 hover:shadow-2xl hover:-translate-y-1 font-poppins 
                        flex flex-col h-full`}
        >
            {/* Badge */}
            {plan.badge && (
                <span className={`absolute top-0 right-0 px-4 py-1 text-xs font-bold text-white uppercase rounded-bl-xl ${plan.badgeColor || 'bg-primary'}`}>
                    {plan.badge}
                </span>
            )}
            
            {/* Title */}
            <h3 className={`mb-4 text-3xl font-extrabold ${plan.borderColor === 'border-danger' ? 'text-danger' : 'text-primary'} 
                             pb-3 border-b-2 border-dashed border-gray-100`}>
                {plan.title}
            </h3>

            {/* UPDATED LAYOUT: Price, Data, & Validity STACKED VERTICALLY */}
            <div className="flex flex-col justify-start items-stretch mb-6 p-4 border border-gray-100 rounded-lg shadow-inner bg-blue-50/50 space-y-4">
                
                {/* 1. Price (Largest and most prominent) */}
                <div className="text-center pb-2 border-b border-gray-200">
                    <small className="block text-sm text-gray-600 font-medium mb-1">Plan Price</small>
                    <strong className="block text-5xl font-black text-accent leading-tight">{plan.price}</strong>
                </div>
                
                <div className="flex justify-between items-center w-full pt-2">
                    {/* 2. Data */}
                    <div className="text-center flex-1 pr-2 border-r border-gray-200">
                        <strong className="block text-3xl font-bold text-primary leading-tight">{plan.data}</strong>
                        <small className="text-gray-500 text-xs">{isPostpaid ? 'Monthly Data' : 'Daily Data'}</small>
                    </div>
                    
                    {/* 3. Validity */}
                    <div className="text-center flex-1 pl-2">
                        <strong className="block text-3xl font-bold text-primary leading-tight">{plan.validity}</strong>
                        <small className="text-gray-500 text-xs">Validity</small>
                    </div>
                </div>
            </div>

            {/* Button: Pill shape, fixed background, and shadow */}
            <button 
                // Defensive Inline Style for guaranteed visibility
                style={{ backgroundColor: buttonHexColor }} 
                className={`w-full py-3 font-semibold text-white rounded-full transition duration-300 shadow-lg mt-auto 
                            ${plan.buttonClass || 'bg-primary hover:bg-blue-800'}`}
            >
                {plan.buttonText || (isPostpaid ? 'Get New Connection' : 'Recharge Now')}
            </button>
            
            {/* Details Section */}
            <details className="mt-6 pt-4 border-t border-gray-200">
                <summary className={`flex justify-between items-center cursor-pointer font-semibold ${plan.borderColor === 'border-danger' ? 'text-danger' : 'text-primary'} hover:text-black transition`}>
                    View Key Benefits
                </summary>
                <div className="pt-4 space-y-3 text-sm text-gray-700">
                    {plan.details.map((detail, index) => (
                        <div key={index} className="flex items-start">
                            <svg className={`flex-shrink-0 w-4 h-4 mr-2 mt-1 ${plan.borderColor === 'border-danger' ? 'text-danger' : 'text-accent'}`} fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                            </svg>
                            <p>{detail}</p>
                        </div>
                    ))}
                </div>
            </details>
        </div>
    );
};

export default PlanCard;