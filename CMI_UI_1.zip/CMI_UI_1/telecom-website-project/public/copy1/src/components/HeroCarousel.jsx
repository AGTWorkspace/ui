import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const banners = [
    { id: 1, title: "India's Fastest 5G Network", subtitle: "Get unlimited data and OTT benefits starting at ₹499/month.", buttonText: "View Best Plans", bgColor: "from-blue-50 to-white", ctaBg: "bg-primary hover:bg-blue-800", titleColor: "text-primary" },
    { id: 2, title: "🎉 New Unlimited Data Plans", subtitle: "Unlock truly unlimited data usage and say goodbye to daily limits on 5G network.", buttonText: "Explore Unlimited", bgColor: "from-red-50 to-white", ctaBg: "bg-danger hover:bg-red-700", titleColor: "text-danger" },
    { id: 3, title: "🏡 Fiber Broadband Upgrade", subtitle: "Get up to 300 Mbps speed and zero installation charges this month!", buttonText: "Check Availability", bgColor: "from-green-50 to-white", ctaBg: "bg-accent hover:bg-green-700", titleColor: "text-accent" },
];

/**
 * Helper function to defensively force the correct background color.
 * This overrides the initial Tailwind rendering conflict.
 */
const getBackgroundColor = (ctaBgClass) => {
    // These hex codes match the colors defined in your tailwind.config.js (primary, danger, accent)
    if (ctaBgClass.includes('bg-primary')) return '#007bff';
    if (ctaBgClass.includes('bg-danger')) return '#dc3545';
    if (ctaBgClass.includes('bg-accent')) return '#28a745';
    return 'transparent';
};

const HeroCarousel = () => {
    const [currentSlide, setCurrentSlide] = useState(0);
    const totalSlides = banners.length;
    const trackRef = useRef(null);

    // Auto-rotate effect (no change in logic)
    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentSlide((prevSlide) => (prevSlide + 1) % totalSlides);
        }, 5000);
        return () => clearInterval(interval);
    }, [totalSlides]);

    // Update track position (no change in logic)
    useEffect(() => {
        if (trackRef.current) {
            // NOTE: Using calc() is safer than interpolation for w-1/${totalSlides}
            const translateValue = `translateX(-${currentSlide * (100 / totalSlides)}%)`;
            trackRef.current.style.transform = translateValue;
        }
    }, [currentSlide, totalSlides]);

    const nextSlide = () => setCurrentSlide((prevSlide) => (prevSlide + 1) % totalSlides);
    const prevSlide = () => setCurrentSlide((prevSlide) => (prevSlide - 1 + totalSlides) % totalSlides);

    return (
        <section className="relative w-full overflow-hidden shadow-xl h-[450px] rounded-xl font-poppins">
            <div ref={trackRef} className={`flex w-[${totalSlides * 100}%] h-full transition-transform duration-500 ease-in-out`}>
                {banners.map((banner) => (
                    <div 
                        key={banner.id} 
                        // Note: Using hardcoded width for consistency, as w-1/${totalSlides} interpolation is not supported in Tailwind JIT.
                        style={{ width: `${100 / totalSlides}%` }}
                        className={`flex items-center justify-center h-full p-5 text-center bg-gradient-to-r ${banner.bgColor}`}
                    >
                        {/* Inner Card: Use shadow-lg and rounded-xl for consistency */}
                        <div className="p-10 bg-white rounded-xl shadow-lg max-w-lg">
                            {/* Title: Uses dynamic color from banner object */}
                            <h1 className={`mb-4 text-5xl font-extrabold ${banner.titleColor}`}>{banner.title}</h1>
                            <p className="mb-8 text-lg text-gray-600">{banner.subtitle}</p>
                            
                            {/* CTA Button FIX */}
                            <a 
                                href="#" 
                                style={{ backgroundColor: getBackgroundColor(banner.ctaBg) }} // Defensive inline style override
                                className={`inline-block px-8 py-3 font-semibold text-white rounded-full transition duration-300 ${banner.ctaBg} shadow-md border border-transparent`}
                            >
                                {banner.buttonText}
                            </a>
                        </div>
                    </div>
                ))}
            </div>
            
            {/* Controls */}
            <button onClick={prevSlide} className="absolute left-5 top-1/2 -translate-y-1/2 p-3 bg-black bg-opacity-50 text-white rounded-full transition hover:bg-opacity-80">
                <ChevronLeft size={30} />
            </button>
            <button onClick={nextSlide} className="absolute right-5 top-1/2 -translate-y-1/2 p-3 bg-black bg-opacity-50 text-white rounded-full transition hover:bg-opacity-80">
                <ChevronRight size={30} />
            </button>
        </section>
    );
};

export default HeroCarousel;