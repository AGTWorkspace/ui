// src/components/Header.jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import LoginModal from './LoginModal';

const Header = ({ isLoggedIn: initialIsLoggedIn, mobileNumber: initialMobileNumber }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(initialIsLoggedIn || false);
  const [mobileNumber, setMobileNumber] = useState(initialMobileNumber || '');

  const handleLoginSuccess = (number) => {
    setIsLoggedIn(true);
    setMobileNumber(number);
    setIsModalOpen(false);
  };

  return (
    <>
      <header className="sticky top-0 z-50 flex items-center justify-between px-[5%] py-4 bg-white shadow-md font-poppins">
        <div className="text-3xl font-bold text-primary">MyTelco</div>

        <nav className="hidden space-x-6 md:flex items-center">
          <Link to="/" className="font-semibold text-gray-700 hover:text-primary transition">Home</Link>

          <div className="relative group">
            <span className="font-semibold cursor-pointer text-gray-700 hover:text-primary transition">Prepaid</span>
            <div className="absolute left-0 hidden w-48 pt-4 bg-white rounded-b-xl shadow-xl group-hover:block border-t-4 border-primary z-10">
              <Link to="/recharge" className="block px-4 py-3 text-sm text-gray-700 hover:bg-gray-100/50">Recharge Plans</Link>
              <a href="#data" className="block px-4 py-3 text-sm text-gray-700 hover:bg-gray-100/50">Data Boosters</a>
            </div>
          </div>

          <div className="relative group">
            <span className="font-semibold cursor-pointer text-gray-700 hover:text-primary transition">Postpaid</span>
            <div className="absolute left-0 hidden w-48 pt-4 bg-white rounded-b-xl shadow-xl group-hover:block border-t-4 border-primary z-10">
              <Link to="/postpaid" className="block px-4 py-3 text-sm text-gray-700 hover:bg-gray-100/50">View Plans</Link>
              <a href="#pay" className="block px-4 py-3 text-sm text-gray-700 hover:bg-gray-100/50">Pay Bill</a>
            </div>
          </div>

          {/* NEW NAV ITEMS */}
          <Link to="/fiber" className="font-semibold text-gray-700 hover:text-primary transition">Fiber-net</Link>
          <Link to="/entertainment" className="font-semibold text-gray-700 hover:text-primary transition">Entertainment</Link>
          <Link to="/device" className="font-semibold text-gray-700 hover:text-primary transition">Devices</Link>
          <Link to="/bundle" className="font-semibold text-gray-700 hover:text-primary transition">Bundles</Link>

          <a href="#support" className="font-semibold text-gray-700 hover:text-primary transition">Support</a>
        </nav>

        <div className="flex items-center gap-4">
          {isLoggedIn ? (
            <div
              className="px-6 py-2 font-semibold text-primary border-2 border-primary rounded-full cursor-pointer transition hover:bg-blue-50"
              onClick={() => alert('User menu/profile click simulated!')}
            >
              Welcome, User {mobileNumber ? mobileNumber.slice(-4) : ''}
            </div>
          ) : (
            <button
              style={{ backgroundColor: '#007bff' }}
              className="px-6 py-3 font-semibold text-white transition duration-300 rounded-full shadow-lg border border-transparent"
              onClick={() => setIsModalOpen(true)}
            >
              Login / Recharge
            </button>
          )}

          {/* Mobile menu toggle (simple) */}
          <div className="md:hidden">
            <button className="p-2 rounded-md border" onClick={() => alert('Open mobile nav (implement)')}>
              Menu
            </button>
          </div>
        </div>
      </header>

      <LoginModal
        isVisible={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />
    </>
  );
};

export default Header;
