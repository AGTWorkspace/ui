import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
    return (
        <footer className="bg-gray-800 text-gray-400 py-12 px-5 md:px-[5%] text-sm font-poppins">
            <div className="max-w-7xl mx-auto flex flex-wrap justify-between">
                
                {/* Section: About MyTelco */}
                <div className="w-full md:w-1/4 mb-8 corporate-info min-w-[200px]">
                    <h4 className="mb-4 text-lg font-semibold text-white border-b border-gray-700 pb-2">About MyTelco</h4>
                    <p className="text-xs leading-relaxed">We are India's leading telecom service provider, dedicated to connecting millions with high-speed 5G network.</p>
                    <p className="mt-4 text-xs">**Corporate Office:** MyTelco Towers, Cyber City, Mumbai - 400001</p>
                </div>
                
                {/* Section: Products & Services */}
                <div className="w-1/2 md:w-1/5 mb-8 min-w-[150px]">
                    <h4 className="mb-4 text-lg font-semibold text-white border-b border-gray-700 pb-2">Products</h4>
                    {/* Use custom primary color for hover */}
                    <Link to="/recharge" className="block mb-2 transition hover:text-primary">Prepaid Plans</Link>
                    <Link to="/postpaid" className="block mb-2 transition hover:text-primary">Postpaid Plans</Link>
                    <a href="#" className="block mb-2 transition hover:text-primary">Fiber Broadband</a>
                    <a href="#" className="block mb-2 transition hover:text-primary">DTH Services</a>
                </div>
                
                {/* Section: Support & Help */}
                <div className="w-1/2 md:w-1/5 mb-8 min-w-[150px]">
                    <h4 className="mb-4 text-lg font-semibold text-white border-b border-gray-700 pb-2">Support</h4>
                    <a href="#" className="block mb-2 transition hover:text-primary">Help Center</a>
                    <a href="#" className="block mb-2 transition hover:text-primary">Track Order/SIM</a>
                    <a href="#" className="block mb-2 transition hover:text-primary">Store Locator</a>
                    <a href="#" className="block mb-2 transition hover:text-primary">Raise a Complaint</a>
                </div>
                
                {/* Section: Legal & Corporate */}
                <div className="w-full md:w-1/5 mb-8 legal-info min-w-[150px]">
                    <h4 className="mb-4 text-lg font-semibold text-white border-b border-gray-700 pb-2">Legal</h4>
                    <a href="#" className="block mb-2 transition hover:text-primary">Terms & Conditions</a>
                    <a href="#" className="block mb-2 transition hover:text-primary">Privacy Policy</a>
                    <a href="#" className="block mb-2 transition hover:text-primary">Careers at MyTelco</a>
                    <a href="#" className="block mb-2 transition hover:text-primary">Investor Relations</a>
                </div>
            </div>
            
            {/* Footer Bottom */}
            <div className="pt-6 mt-6 text-center text-xs border-t border-gray-700">
                &copy; 2025 MyTelco Private Limited. All Rights Reserved.
            </div>
        </footer>
    );
};

export default Footer;