import React from 'react';
import HeroCarousel from '../components/HeroCarousel';
import { Link } from 'react-router-dom';
import { ArrowUpRight, Wifi, Headset, Leaf, Smartphone } from 'lucide-react';
import { motion } from 'framer-motion';

// 🐛 FIX APPLIED: Changed motion.create(Link) to the modern recommended motion(Link)
const MotionLink = motion(Link);

/* ---------------- Promo Card ---------------- */
const PromoCard = ({ title, subtitle, borderColor }) => (
  <motion.div
    className={`flex-none w-72 p-6 bg-white rounded-xl shadow-md text-center border-l-4 ${borderColor}`}
    whileHover={{ scale: 1.05 }}
    transition={{ duration: 0.3 }}
  >
    <h3 className="mb-2 text-xl font-semibold text-teal-700 font-poppins">
      {title}
    </h3>
    <p className="text-sm text-gray-700">{subtitle}</p>
  </motion.div>
);

/* ---------------- Value Item ---------------- */
const ValueItem = ({ title, subtitle, icon: Icon }) => (
  <motion.div
    className="flex flex-col items-center p-8 bg-white rounded-xl shadow-md font-poppins"
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5 }}
    whileHover={{ scale: 1.03 }}
  >
    <Icon className="mb-3 text-cyan-500" size={36} />
    <h4 className="mb-1 text-lg font-semibold text-teal-700">
      {title}
    </h4>
    <p className="text-sm text-center text-gray-600">{subtitle}</p>
  </motion.div>
);

/* ---------------- Quick Link Card ---------------- */
const QuickLinkCard = ({ title, subtitle, linkTo, icon: Icon }) => (
  <MotionLink
    to={linkTo}
    className="flex flex-col items-center flex-1 max-w-xs p-8 bg-white rounded-xl shadow-md border-t-4 border-cyan-500 font-poppins"
    whileHover={{
      scale: 1.05,
      boxShadow: '0 20px 40px rgba(0,0,0,0.15)',
    }}
    transition={{ duration: 0.3 }}
  >
    <Icon className="mb-3 text-cyan-500" size={40} />
    <h3 className="mb-1 text-xl font-semibold text-gray-800">
      {title}
    </h3>
    <p className="text-sm text-center text-gray-500">{subtitle}</p>
  </MotionLink>
);

/* ---------------- Home Page ---------------- */
const HomePage = () => {
  return (
    <div className="min-h-screen pb-12 font-poppins bg-gray-50">
      <HeroCarousel />

      {/* -------- Today's Best Offers -------- */}
      <section className="p-8 mt-8 bg-gradient-to-r from-teal-50 to-cyan-50">
        <h2 className="mb-8 text-3xl font-bold text-center text-teal-700">
          ⚡ Today's Best Offers
        </h2>

        <div className="flex gap-6 pb-4 overflow-x-auto snap-x snap-mandatory">
          <PromoCard
            title="Truly Unlimited Data"
            subtitle="No daily limits! Stream, download, and game worry-free."
            borderColor="border-teal-500"
          />
          <PromoCard
            title="Free OTT Bundle"
            subtitle="Disney+ Hotstar & SonyLIV with plans above ₹699."
            borderColor="border-cyan-500"
          />
          <PromoCard
            title="Family Plan Discount"
            subtitle="Add 4 members and save 25% monthly."
            borderColor="border-sky-500"
          />
          <PromoCard
            title="₹50 Cashback"
            subtitle="Instant cashback on first recharge via App."
            borderColor="border-yellow-400"
          />
        </div>
      </section>

      {/* -------- Why Choose Us -------- */}
      <section className="px-5 py-16 text-center bg-white md:px-[5%]">
        <h2 className="mb-12 text-3xl font-bold text-teal-700">
          Why Choose MyTelco?
        </h2>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <ValueItem
            title="Ultra-Low Latency 🚀"
            icon={ArrowUpRight}
            subtitle="Lag-free gaming & conferencing powered by 5G."
          />
          <ValueItem
            title="99.9% Uptime 📶"
            icon={Wifi}
            subtitle="India’s most reliable network coverage."
          />
          <ValueItem
            title="24/7 Priority Support 📞"
            icon={Headset}
            subtitle="Instant help via chat, call, or app."
          />
          <ValueItem
            title="Green Network 🌱"
            icon={Leaf}
            subtitle="Eco-friendly & sustainable operations."
          />
        </div>
      </section>

      {/* -------- Quick Actions -------- */}
      <section className="flex flex-wrap justify-center gap-8 px-5 pt-5 pb-16 bg-gradient-to-r from-cyan-50 to-teal-50">
        <QuickLinkCard
          title="📱 Recharge Now"
          subtitle="Fast & secure top-ups."
          linkTo="/recharge"
          icon={Smartphone}
        />
        <QuickLinkCard
          title="🔗 New Connection"
          subtitle="SIM delivered to your doorstep."
          linkTo="#new"
          icon={ArrowUpRight}
        />
        <QuickLinkCard
          title="📡 Pay Bill"
          subtitle="Postpaid & broadband bills."
          linkTo="#pay"
          icon={Wifi}
        />
      </section>
    </div>
  );
};

export default HomePage;