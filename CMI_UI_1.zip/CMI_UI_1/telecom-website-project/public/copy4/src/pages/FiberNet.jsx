import React from 'react';
import { motion } from 'framer-motion'; // Import motion for animations
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

// --- Theme and Animation Constants ---
const PRIMARY_TEXT = 'text-teal-600';
const ACCENT_BADGE_BG = 'bg-cyan-500';
const HEADER_GRADIENT = 'bg-gradient-to-r from-teal-50 to-cyan-50';

const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
        opacity: 1,
        transition: {
            staggerChildren: 0.1,
            delayChildren: 0.2
        }
    }
};

const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
        y: 0,
        opacity: 1,
        transition: {
            type: 'spring',
            stiffness: 100,
            damping: 20
        }
    }
};

const FiberNet = () => {
    const fiberPlans = plansData.filter(p => p.category === 'fiber-net');
    
    return (
        <section className="min-h-screen pt-12 bg-gray-50 font-poppins">
            
            {/* --- Modernized Animated Header Section --- */}
            <div className={`relative pt-12 pb-16 mb-12 overflow-hidden ${HEADER_GRADIENT} shadow-md`}>
                <motion.div 
                    className="relative max-w-4xl px-4 mx-auto text-center"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                >
                    {/* Main Title - Animated and Themed */}
                    <motion.h1 
                        className={`mb-4 text-5xl font-black tracking-tight ${PRIMARY_TEXT} md:text-6xl`}
                        variants={itemVariants}
                    >
                        Fiber Net Plans
                    </motion.h1>
                    
                    {/* Subtitle - Animated */}
                    <motion.p 
                        className="mb-8 text-xl text-gray-700 md:text-2xl"
                        variants={itemVariants}
                    >
                        High-speed home broadband plans with blazing-fast speeds, free router & installation options.
                    </motion.p>

                     {/* Highlight Badge */}
                    <motion.div 
                        className={`inline-block px-8 py-3 text-sm font-bold text-white uppercase ${ACCENT_BADGE_BG} rounded-full shadow-xl`}
                        variants={itemVariants}
                    >
                        🚀 Lightning-Fast Speeds 🌐
                    </motion.div>
                    
                </motion.div>
            </div>

            {/* Plan List Container */}
            <div className="max-w-7xl mx-auto px-6 mb-16 -mt-10">
                {/* PlanList internally handles staggered animations for individual cards */}
                <PlanList items={fiberPlans} />
            </div>
            
            {/* Disclaimer/Footer space */}
            <div className="max-w-4xl px-4 mx-auto pt-8 pb-8 text-sm text-center text-gray-500">
                <p>*Availability is subject to fiber network coverage in your area. Check serviceability before purchase.</p>
            </div>
        </section>
    );
};

export default FiberNet;