import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Frown } from 'lucide-react'; // Added an icon for visual impact

// --- Theme and Animation Constants ---
const ERROR_RED = 'text-red-600';
const BUTTON_TEAL = 'bg-teal-600 hover:bg-teal-700';

const containerVariants = {
    hidden: { opacity: 0, scale: 0.95 },
    visible: { 
        opacity: 1, 
        scale: 1, 
        transition: {
            when: "beforeChildren",
            staggerChildren: 0.15
        }
    }
};

const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
        y: 0, 
        opacity: 1, 
        transition: { type: 'spring', stiffness: 150, damping: 20 } 
    }
};

const NotFound = () => {
    return (
        <motion.div 
            className="flex flex-col items-center justify-center min-h-[70vh] text-center p-8 font-poppins bg-gray-50 rounded-xl shadow-lg m-4"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
        >
            {/* Icon */}
            <motion.div 
                className="mb-6 text-red-500"
                variants={itemVariants}
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                transition={{ type: 'spring', stiffness: 100, damping: 10, delay: 0.2 }}
            >
                <Frown size={80} strokeWidth={1.5} />
            </motion.div>

            {/* Error Code */}
            <motion.h1 
                className={`mb-4 text-8xl font-black ${ERROR_RED}`}
                variants={itemVariants}
            >
                404
            </motion.h1>

            {/* Main Message */}
            <motion.h2 
                className="mb-4 text-4xl font-extrabold text-gray-800"
                variants={itemVariants}
            >
                Oops! Page Not Found
            </motion.h2>

            {/* Sub Message */}
            <motion.p 
                className="mb-10 text-xl text-gray-500 max-w-md"
                variants={itemVariants}
            >
                The page you are looking for does not exist, has been moved, or the link is broken.
            </motion.p>
            
            {/* Button: Pill shape and Teal primary color */}
            <motion.div variants={itemVariants}>
                <Link 
                    to="/" 
                    className={`px-10 py-3 font-semibold text-white transition duration-300 rounded-full ${BUTTON_TEAL} shadow-xl hover:shadow-teal-500/50`}
                >
                    Go to Home
                </Link>
            </motion.div>
        </motion.div>
    );
};

export default NotFound;