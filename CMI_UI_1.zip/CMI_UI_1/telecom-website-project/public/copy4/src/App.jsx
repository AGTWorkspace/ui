// src/App.jsx
import React, { useState } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';

import Header from './components/Header';
import Footer from './components/Footer';
import LoginModal from './components/LoginModal';
import ChatbotWidget from './components/ChatbotWidget';
import AnimatedRoutes from './components/AnimatedRoutes';

function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [mobileNumber, setMobileNumber] = useState('');

  const handleLoginSuccess = (number) => {
    setMobileNumber(number);
    setIsLoggedIn(true);
    setIsModalOpen(false);
  };

  return (
    <Router>
      <div className="flex flex-col min-h-screen">
        
        {/* Header stays static */}
        <Header
          onShowLogin={() => setIsModalOpen(true)}
          isLoggedIn={isLoggedIn}
          mobileNumber={mobileNumber}
        />

        {/* Animated page content */}
        <main className="flex-grow overflow-hidden">
          <AnimatedRoutes />
        </main>

        {/* Modals & global UI */}
        <LoginModal
          isVisible={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onLoginSuccess={handleLoginSuccess}
        />

        <Footer />
        <ChatbotWidget />
      </div>
    </Router>
  );
}

export default App;
