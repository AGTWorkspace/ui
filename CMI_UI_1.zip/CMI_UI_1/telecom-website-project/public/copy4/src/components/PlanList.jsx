// src/components/PlanList.jsx
import React from 'react';
import PlanCard from './PlanCard';
import { motion } from 'framer-motion'; // Import motion for DeviceCard animation

// --- Theme Constants ---
const PRIMARY_TEAL = 'text-teal-600';
const BUTTON_TEAL = 'bg-teal-600 hover:bg-teal-700';

// DeviceCard component updated for theme consistency and animation
const DeviceCard = ({ item, index }) => (
    // Add Framer Motion for entrance animation
    <motion.div 
        className="p-6 bg-white rounded-xl shadow-lg border border-gray-100 transition duration-300"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ 
            type: 'spring', 
            stiffness: 100, 
            damping: 20,
            delay: index * 0.1 // Staggered delay
        }}
        whileHover={{ scale: 1.02, boxShadow: '0 10px 20px rgba(13, 148, 136, 0.2)' }}
    >
        {/* Title uses Primary Teal color */}
        <h3 className={`text-xl font-semibold mb-2 ${PRIMARY_TEAL}`}>{item.offeringDetails.name}</h3>
        <p className="text-sm text-gray-600 mb-3">{item.description}</p>
        
        {/* Specifications List */}
        {item.specification && (
            <ul className="text-sm text-gray-700 mb-3 pl-4 list-disc space-y-1">
                {Object.entries(item.specification).map(([k, v]) => <li key={k}>**{k}:** {v}</li>)}
            </ul>
        )}
        
        <div className="flex items-center justify-between mt-4 border-t pt-4 border-gray-100">
            {/* Price uses Cyan for slight emphasis */}
            <div className="text-xl font-bold text-cyan-500">{typeof item.price === 'number' ? `₹ ${item.price}` : item.price}</div>
            
            {/* Button uses Primary Teal color */}
            <button className={`px-4 py-2 rounded-full text-white font-semibold shadow-md transition ${BUTTON_TEAL}`}>
                Buy Now
            </button>
        </div>
    </motion.div>
);

const PlanList = ({ items }) => {
    return (
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {items.map((item, index) => { // 💡 Passed index to the map function
                
                if (['pre-paid', 'postpaid', 'fiber-net', 'entertainment', 'bundle'].includes(item.category)) {
                    // Normalize plan object
                    const plan = {
                        id: item.id,
                        type: item.category === 'postpaid' ? 'postpaid' : 'prepaid',
                        title: item.offeringDetails.name || item.offeringDetails.plan?.serviceId,
                        price: typeof item.price === 'number' ? `₹ ${item.price}` : item.price,
                        data: item.offeringDetails.plan?.data || '—', // Added fallback
                        validity: item.validityMonths ? `${item.validityMonths}m` : '—',
                        // Adjusted badge/button classes to use theme-consistent defaults if missing
                        badge: item.isRecurring ? 'Recurring' : undefined,
                        borderColor: item.borderColor || 'border-teal-500', // Default to Teal border
                        buttonClass: item.buttonClass || 'bg-teal-600', // Default to Teal button
                        buttonText: item.buttonText || 'Choose Plan',
                        details: item.offeringDetails.plan?.features 
                            ? Object.keys(item.offeringDetails.plan.features).map(k => {
                                const v = item.offeringDetails.plan.features[k];
                                if (Array.isArray(v)) return `${k}: ${v.join(', ')}`;
                                return `${k}: ${v}`;
                              }) 
                            : (item.specification 
                                ? Object.entries(item.specification).map(([k,v]) => `${k}: ${v}`) 
                                : ['Unlimited Calling', 'High Speed Data']) // Better default details
                    };
                    
                    // Pass the index for the staggered animation
                    return <PlanCard key={item.id} plan={plan} index={index} />;
                }

                // Device Card is also passed the index for animation
                return <DeviceCard key={item.id} item={item} index={index} />;
            })}
        </div>
    );
};

export default PlanList;