import React from 'react';
import { motion } from 'framer-motion';

const PlanCard = ({ plan, index }) => {
    const isPostpaid = plan.type === 'postpaid';
    
    // --- Tailwind Class Mapping ---
    // Define the primary color classes based on the Teal theme.
    const PRIMARY_TEAL = 'text-teal-600';
    const BORDER_TEAL = 'border-teal-500';
    const ACCENT_CYAN = 'text-cyan-500';
    const DANGER_RED = 'text-red-600';
    const SHADOW_TEAL = 'shadow-teal-500/30'; // Teal shadow for hover

    // Helper function to map plan attributes to theme classes
    const getPlanClasses = () => {
        if (plan.title.toLowerCase().includes('redx')) {
            return {
                borderColor: 'border-red-500',
                titleColor: DANGER_RED,
                detailColor: DANGER_RED,
                buttonClass: 'bg-red-600 hover:bg-red-700',
                shadowColor: 'shadow-red-500/30',
            };
        }
        return {
            borderColor: BORDER_TEAL,
            titleColor: PRIMARY_TEAL,
            detailColor: PRIMARY_TEAL,
            buttonClass: 'bg-teal-600 hover:bg-teal-700',
            shadowColor: SHADOW_TEAL,
        };
    };

    const { borderColor, titleColor, detailColor, buttonClass, shadowColor } = getPlanClasses();

    // Framer Motion Variants for Staggered Entrance
    const itemVariants = {
        hidden: { opacity: 0, y: 50 },
        visible: { 
            opacity: 1, 
            y: 0, 
            transition: { 
                type: 'spring', 
                stiffness: 100, 
                damping: 20,
                delay: index * 0.1 // Staggered delay based on index
            } 
        },
    };

    return (
        <motion.div 
            className={`relative p-8 bg-white rounded-2xl shadow-xl border-t-8 ${borderColor} 
                        font-poppins flex flex-col h-full`}
            // 1. Entrance Animation
            variants={itemVariants}
            initial="hidden"
            animate="visible"
            
            // 2. Hover Effect
            whileHover={{ 
                y: -8, // Lift the card slightly more on hover
                boxShadow: `0 10px 25px -3px ${shadowColor}`, // Pronounced color shadow
            }}
        >
            {/* Badge */}
            {plan.badge && (
                <span className={`absolute top-0 right-0 px-4 py-1 text-xs font-bold text-white uppercase rounded-bl-xl 
                                ${plan.title.toLowerCase().includes('redx') ? 'bg-red-600' : 'bg-cyan-500'}`}>
                    {plan.badge}
                </span>
            )}
            
            {/* Title */}
            <h3 className={`mb-4 text-3xl font-extrabold ${titleColor} 
                             pb-3 border-b-2 border-dashed border-gray-100`}>
                {plan.title}
            </h3>

            {/* Price, Data, & Validity Block */}
            <div className="flex flex-col justify-start items-stretch mb-6 p-4 border border-gray-100 rounded-lg shadow-inner bg-teal-50/50 space-y-4">
                
                {/* 1. Price (Largest and most prominent - using Cyan for emphasis) */}
                <div className="text-center pb-2 border-b border-gray-200">
                    <small className="block text-sm text-gray-600 font-medium mb-1">Plan Price</small>
                    <strong className={`block text-5xl font-black ${ACCENT_CYAN} leading-tight`}>{plan.price}</strong>
                </div>
                
                <div className="flex justify-between items-center w-full pt-2">
                    {/* 2. Data (Using Teal) */}
                    <div className="text-center flex-1 pr-2 border-r border-gray-200">
                        <strong className={`block text-3xl font-bold ${PRIMARY_TEAL} leading-tight`}>{plan.data}</strong>
                        <small className="text-gray-500 text-xs">{isPostpaid ? 'Monthly Data' : 'Daily Data'}</small>
                    </div>
                    
                    {/* 3. Validity (Using Teal) */}
                    <div className="text-center flex-1 pl-2">
                        <strong className={`block text-3xl font-bold ${PRIMARY_TEAL} leading-tight`}>{plan.validity}</strong>
                        <small className="text-gray-500 text-xs">Validity</small>
                    </div>
                </div>
            </div>

            {/* Button: Pill shape, fixed background, and shadow */}
            <button 
                className={`w-full py-3 font-semibold text-white rounded-full transition duration-300 shadow-lg mt-auto 
                            ${buttonClass}`} 
            >
                {plan.buttonText || (isPostpaid ? 'Get New Connection' : 'Recharge Now')}
            </button>
            
            {/* Details Section */}
            <details className="mt-6 pt-4 border-t border-gray-200">
                {/* Summary (Using dynamic detailColor) */}
                <summary className={`flex justify-between items-center cursor-pointer font-semibold ${detailColor} hover:text-black transition`}>
                    View Key Benefits
                </summary>
                <div className="pt-4 space-y-3 text-sm text-gray-700">
                    {plan.details.map((detail, detailIndex) => (
                        <div key={detailIndex} className="flex items-start">
                            <svg className={`flex-shrink-0 w-4 h-4 mr-2 mt-1 ${detailColor}`} fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                            </svg>
                            <p>{detail}</p>
                        </div>
                    ))}
                </div>
            </details>
        </motion.div>
    );
};

export default PlanCard;