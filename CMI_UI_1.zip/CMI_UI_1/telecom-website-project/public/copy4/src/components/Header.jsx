import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, LogIn, LogOut, Globe, MapPin, Search } from 'lucide-react'; 
import LoginModal from './LoginModal';

const NAV_ITEMS = [
  { name: 'Home', path: '/' },
  { name: 'Prepaid', path: '/recharge' },
  { name: 'Postpaid', path: '/postpaid' },
  { name: 'Fiber', path: '/fiber' },
  { name: 'Entertainment', path: '/entertainment' },
  { name: 'Devices', path: '/device' },
  { name: 'Bundles', path: '/bundle' },
  { name: 'Support', path: '/support'},
];

const Header = ({ isLoggedIn: initialIsLoggedIn, mobileNumber: initialMobileNumber }) => {
  const navigate = useNavigate();
  const location = useLocation();

  // --- States ---
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(initialIsLoggedIn || false);
  const [mobileNumber, setMobileNumber] = useState(initialMobileNumber || '');
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [locationInput, setLocationInput] = useState('');

  // --- Effects ---
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setIsLoggedIn(initialIsLoggedIn);
    setMobileNumber(initialMobileNumber);
  }, [initialIsLoggedIn, initialMobileNumber]);

  // --- Handlers ---
  const handleLogout = () => {
    setIsLoggedIn(false);
    setMobileNumber('');
  };

  const handleLoginSuccess = (num) => {
    setIsLoggedIn(true);
    setMobileNumber(num);
    setIsModalOpen(false);
  };

  const handleSearch = () => {
    if (!locationInput.trim()) return;
    const targetRoute = location.pathname.includes('postpaid')
      ? '/postpaid'
      : location.pathname.includes('recharge')
      ? '/recharge'
      : location.pathname;

    navigate(`${targetRoute}?location=${encodeURIComponent(locationInput.trim())}`);
  };

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 font-poppins ${
          scrolled 
            ? 'bg-white/90 backdrop-blur-md shadow-lg py-3' 
            : 'bg-gradient-to-r from-teal-700 via-cyan-600 to-blue-700 py-4'
        }`}
      >
        <div className="max-w-[1400px] mx-auto flex items-center justify-between px-6 gap-4">
          
          {/* 1. LOGO */}
          <Link to="/" className="flex items-center gap-2 shrink-0 group">
            <motion.div 
              whileHover={{ rotate: 360 }}
              className={`p-1.5 rounded-lg ${scrolled ? 'bg-teal-600 text-white' : 'bg-white text-teal-700'}`}
            >
              <Globe size={22} />
            </motion.div>
            <span className={`text-xl font-black tracking-tighter ${scrolled ? 'text-slate-800' : 'text-white'}`}>
              My<span className={scrolled ? 'text-teal-600' : 'text-cyan-200'}>Telco</span>
            </span>
          </Link>

          {/* 2. DESKTOP NAV */}
          <nav className="hidden xl:flex items-center gap-6">
            {NAV_ITEMS.map((item) => {
              const active = location.pathname === item.path;
              return (
                <Link 
                  key={item.name}
                  to={item.path}
                  className={`relative text-xs font-bold transition-all ${
                    scrolled 
                      ? (active ? 'text-teal-600' : 'text-slate-600 hover:text-teal-500') 
                      : (active ? 'text-cyan-200' : 'text-white/90 hover:text-white')
                  }`}
                >
                  {item.name}
                  {active && (
                    <motion.div 
                      layoutId="navUnderline"
                      className={`absolute -bottom-1 left-0 right-0 h-0.5 ${scrolled ? 'bg-teal-600' : 'bg-cyan-300'}`}
                    />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* 3. 📍 SEARCH BAR (The New Component) */}
          <div className="hidden lg:flex items-center flex-1 max-w-sm mx-4">
            <div className={`flex items-center w-full rounded-full px-3 py-1.5 border transition-all duration-300 ${
              scrolled 
                ? 'bg-gray-100 border-gray-200 focus-within:bg-white focus-within:ring-2 focus-within:ring-teal-500/20' 
                : 'bg-white/10 border-white/20 focus-within:bg-white/20'
            }`}>
              <MapPin size={16} className={scrolled ? 'text-gray-400' : 'text-white/60'} />
              <input
                type="text"
                value={locationInput}
                onChange={(e) => setLocationInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Search your state..."
                className={`bg-transparent text-xs w-full px-2 focus:outline-none font-medium ${
                  scrolled ? 'text-slate-800 placeholder-gray-400' : 'text-white placeholder-white/50'
                }`}
              />
              <button 
                onClick={handleSearch}
                className={`p-1.5 rounded-full transition-transform active:scale-90 ${
                  scrolled ? 'bg-teal-600 text-white' : 'bg-cyan-400 text-teal-900'
                }`}
              >
                <Search size={14} />
              </button>
            </div>
          </div>

          {/* 4. ACTIONS */}
          <div className="flex items-center gap-3 shrink-0">
            {isLoggedIn ? (
              <div className="flex items-center gap-3">
                <span className={`text-[10px] font-black hidden 2xl:inline-block uppercase tracking-wider ${scrolled ? 'text-slate-400' : 'text-white/60'}`}>
                   Acc: ***{mobileNumber.slice(-4)}
                </span>
                <motion.button 
                  whileHover={{ scale: 1.05 }}
                  onClick={handleLogout}
                  className="px-4 py-2 text-[11px] font-bold text-white bg-red-500 rounded-full shadow-lg hover:bg-red-600 flex items-center gap-2"
                >
                  <LogOut size={14} /> <span className="hidden sm:inline">Logout</span>
                </motion.button>
              </div>
            ) : (
              <motion.button 
                whileHover={{ scale: 1.05 }}
                onClick={() => setIsModalOpen(true)}
                className={`px-5 py-2 text-xs font-bold rounded-full shadow-xl flex items-center gap-2 transition-all ${
                  scrolled 
                    ? 'bg-teal-600 text-white' 
                    : 'bg-white text-teal-700'
                }`}
              >
                <LogIn size={16} /> <span className="hidden sm:inline">Login</span>
              </motion.button>
            )}

            <button onClick={() => setMobileOpen(true)} className="xl:hidden p-2">
              <Menu size={24} className={scrolled ? 'text-slate-800' : 'text-white'} />
            </button>
          </div>
        </div>
      </motion.header>

      {/* MOBILE MENU (Unchanged logic, added Search to mobile) */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setMobileOpen(false)}
              className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60]"
            />
            <motion.aside
              initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
              className="fixed top-0 right-0 h-full w-72 z-[70] bg-white p-6 shadow-2xl flex flex-col"
            >
              <div className="flex justify-between items-center mb-8">
                <span className="text-lg font-black text-teal-600">Menu</span>
                <button onClick={() => setMobileOpen(false)} className="p-2 bg-slate-100 rounded-full text-slate-600">
                  <X size={20} />
                </button>
              </div>

              {/* Mobile Search */}
              <div className="mb-8 flex items-center bg-gray-100 rounded-xl px-4 py-3 gap-2">
                <MapPin size={18} className="text-teal-600" />
                <input 
                  type="text" 
                  placeholder="State name..."
                  className="bg-transparent text-sm w-full outline-none"
                  value={locationInput}
                  onChange={(e) => setLocationInput(e.target.value)}
                />
                <Search size={18} className="text-gray-400" onClick={handleSearch} />
              </div>

              <div className="flex flex-col gap-4">
                {NAV_ITEMS.map((item) => (
                  <Link 
                    key={item.name} 
                    to={item.path} 
                    onClick={() => setMobileOpen(false)}
                    className="text-base font-bold text-slate-800 hover:text-teal-600 transition-colors"
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <LoginModal isVisible={isModalOpen} onClose={() => setIsModalOpen(false)} onLoginSuccess={handleLoginSuccess} />
    </>
  );
};

export default Header;