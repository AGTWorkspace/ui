import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, RefreshCw, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion'; // Import Framer Motion

// --- Theme Constants ---
const PRIMARY_GRADIENT = 'bg-gradient-to-r from-teal-600 to-cyan-500';
const PRIMARY_TEAL = 'bg-teal-600 hover:bg-teal-700';
const USER_MESSAGE_BG = 'bg-teal-600';
const BOT_MESSAGE_TEXT = 'text-teal-600';
const INPUT_FOCUS_RING = 'focus:ring-teal-500';
const TICK_COLOR = 'text-cyan-400';

// --- Framer Motion Variants ---
const messageVariants = {
    initial: { opacity: 0, y: 20, scale: 0.95 },
    animate: { opacity: 1, y: 0, scale: 1, transition: { type: 'spring', stiffness: 200, damping: 25 } },
    exit: { opacity: 0, height: 0, transition: { duration: 0.2 } }
};

const chatBoxVariants = {
    closed: { scale: 0.8, opacity: 0, y: 50, transition: { type: 'spring', stiffness: 300, damping: 30 } },
    open: { scale: 1, opacity: 1, y: 0, transition: { type: 'spring', stiffness: 100, damping: 15 } }
};

/**
 * A basic message bubble for the Bot (with Framer Motion animation)
 */
const BotMessage = ({ text }) => (
    <motion.div 
        className="flex flex-col items-start space-y-1"
        variants={messageVariants}
        initial="initial"
        animate="animate"
    >
        <div className="max-w-[86%] bg-white p-4 rounded-2xl border border-gray-200 text-gray-900 shadow-sm">
            <p className="m-0 mb-1 leading-[1.45]">{text || "Hello! How can I help you today?"}</p>
        </div>
        <div className="text-xs text-gray-400">12:00 PM</div>
    </motion.div>
);

/**
 * A basic message bubble for the User (with Framer Motion animation)
 */
const UserMessage = ({ text }) => (
    <motion.div 
        className="flex flex-col items-end space-y-1"
        variants={messageVariants}
        initial="initial"
        animate="animate"
    >
        <div className={`max-w-[86%] ${USER_MESSAGE_BG} text-white p-3 rounded-2xl shadow break-words whitespace-pre-wrap`}>
            {text}
        </div>
        <div className="flex items-center gap-2 text-xs">
            <div className="text-xs text-gray-400 ml-1">12:01 PM</div>
            <svg className={`w-4 h-4 ${TICK_COLOR}`} viewBox="0 0 24 24" fill="currentColor">
                <path d="M1.6 13.2l1.4-1.4 4.3 4.3-1.4 1.4z"></path>
                <path d="M6.2 13.2l1.4-1.4 4.3 4.3-1.4 1.4z"></path>
            </svg>
        </div>
    </motion.div>
);


/**
 * The main Chatbot UI component
 */
const ChatbotWidget = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [showTooltip, setShowTooltip] = useState(true);

    const [messages, setMessages] = useState([{ id: 1, text: "Hello! How can I help you today?", sender: 'bot' }]);
    const [userInput, setUserInput] = useState('');
    const textareaRef = useRef(null);
    const messagesEndRef = useRef(null);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    useEffect(() => {
        const timer1 = setTimeout(() => setShowTooltip(false), 5000);
        return () => clearTimeout(timer1);
    }, []);

    const handleSendMessage = () => {
        const text = userInput.trim();
        if (!text) return;

        setMessages(prev => [...prev, { id: Date.now(), text, sender: 'user' }]);
        setUserInput('');
        textareaRef.current.style.height = 'auto';

        // Simulated Bot Response Logic
        setTimeout(() => {
            setMessages(prev => [...prev, { id: Date.now() + 1, text: "Thanks for reaching out! We are currently checking the status of your query. Please hold.", sender: 'bot' }]);
        }, 1500);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    };

    const handleInputChange = (e) => {
        setUserInput(e.target.value);
        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
            textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
        }
    };

    const handleRestart = () => {
        setMessages([{ id: 1, text: "Chat restarted. What telecom service can I assist you with now?", sender: 'bot' }]);
        setUserInput('');
    };


    return (
        <>
            {/* 1. Chat Box Container - Using AnimatePresence and motion.div */}
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        // Use Framer Motion variants for the opening animation
                        variants={chatBoxVariants}
                        initial="closed"
                        animate="open"
                        exit="closed" // Defines the closing animation
                        
                        // Retain fixed positioning and styling
                        className={`fixed bottom-28 right-8 w-80 md:w-96 h-[560px] bg-white rounded-2xl shadow-xl border border-gray-200 flex flex-col overflow-hidden z-[999]`}
                    >

                        {/* Header */}
                        <div className={`${PRIMARY_GRADIENT} text-white p-4 flex items-center justify-between relative shadow-md`}>
                            <h2 className="text-lg font-semibold tracking-tight text-white">MyTelco Chatbot</h2>
                            {/* Enhanced close button interaction */}
                            <motion.button 
                                className="text-2xl text-white/90 transition"
                                onClick={() => setIsOpen(false)}
                                whileHover={{ scale: 1.1, rotate: 90 }}
                                whileTap={{ scale: 0.9 }}
                            >
                                <X size={24} />
                            </motion.button>
                        </div>

                        {/* Messages Container */}
                        <div 
                            id="chat-messages"
                            className="flex-1 overflow-y-auto px-4 py-4 space-y-4 bg-gray-50"
                        >
                            {/* Messages are animated using their own motion.div and variants */}
                            {messages.map(msg => 
                                msg.sender === 'bot' 
                                    ? <BotMessage key={msg.id} text={msg.text} />
                                    : <UserMessage key={msg.id} text={msg.text} />
                            )}
                            <div ref={messagesEndRef} /> 
                        </div>

                        {/* Input Area */}
                        <div className="p-4 bg-white border-t border-gray-200">
                            <div className="flex items-end gap-3">
                                
                                <textarea
                                    ref={textareaRef}
                                    rows="1"
                                    placeholder="Type your message..."
                                    className={`flex-1 px-4 py-2 rounded-xl border border-gray-300 bg-gray-50 focus:outline-none focus:ring-2 ${INPUT_FOCUS_RING} text-sm text-left resize-none overflow-hidden transition-all duration-100 max-h-28`}
                                    value={userInput}
                                    onChange={handleInputChange}
                                    onKeyDown={handleKeyDown}
                                ></textarea>

                                <div className="flex flex-col items-center justify-between gap-2 h-auto">
                                    <motion.button
                                        id="restart-button"
                                        className={`flex items-center text-xs px-3 py-1 bg-white border border-gray-300 rounded-full shadow-sm ${BOT_MESSAGE_TEXT} hover:bg-gray-50 transition`}
                                        onClick={handleRestart}
                                        whileTap={{ scale: 0.95 }} // Added tap effect
                                    >
                                        <RefreshCw size={12} className="mr-1" /> Restart
                                    </motion.button>

                                    <motion.button
                                        id="send-button"
                                        className={`w-10 h-10 flex items-center justify-center text-white rounded-full font-medium shadow-md transition ${
                                            userInput.trim() ? PRIMARY_TEAL : 'bg-gray-400 cursor-not-allowed'
                                        }`}
                                        onClick={handleSendMessage}
                                        disabled={!userInput.trim()}
                                        whileTap={{ scale: 0.8 }} // Added press effect
                                    >
                                        <Send size={18} />
                                    </motion.button>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* 2. Floating Chat Icon + Tooltip - Enhanced Interactivity */}
            <div className="fixed bottom-8 right-8 flex flex-col items-center space-y-2 z-[1000]">
                <div
                    className={`bg-gray-900 text-white text-xs px-3 py-1 rounded-full shadow-md transition-all duration-300 z-[1010] ${showTooltip && !isOpen ? 'opacity-100' : 'opacity-0'}`}
                >
                    Chat with us
                </div>

                <motion.div
                    id="chat-toggle"
                    className={`w-16 h-16 rounded-full ${PRIMARY_GRADIENT} shadow-xl shadow-teal-500/50 text-white flex items-center justify-center text-3xl cursor-pointer`}
                    onClick={() => {
                        setIsOpen(!isOpen);
                        setShowTooltip(false);
                    }}
                    whileHover={{ scale: 1.1 }} // Smooth lift on hover
                    whileTap={{ scale: 0.9 }}   // Press down effect
                    animate={{ rotate: isOpen ? 10 : 0 }} // Smooth rotation change
                >
                    <MessageSquare size={30} />
                </motion.div>
            </div>
        </>
    );
};

export default ChatbotWidget;