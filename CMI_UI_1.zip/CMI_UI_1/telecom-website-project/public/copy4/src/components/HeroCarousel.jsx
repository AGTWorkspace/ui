import React from 'react'; // Explicitly importing React
import { motion } from 'framer-motion';

const HeroCarousel = () => {
  return (
    <div className="relative h-[80vh] w-full overflow-hidden bg-gradient-to-r from-teal-700 to-cyan-700">
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/30 z-10" />

      {/* Content */}
      <div className="relative z-20 flex flex-col items-center justify-center h-full text-center px-6 text-white font-poppins">
        
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-6xl font-bold mb-4"
        >
          Experience the Future of Connectivity
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="max-w-2xl mb-8 text-lg text-gray-200"
        >
          Ultra-fast 5G, unlimited data, and premium support —
          built for modern India.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex gap-4"
        >
          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.95 }}
            className="px-6 py-3 bg-white text-teal-700 font-semibold rounded-full shadow-lg"
          >
            Get Started
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.95 }}
            className="px-6 py-3 border border-white text-white rounded-full"
          >
            View Plans
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
};

export default HeroCarousel;