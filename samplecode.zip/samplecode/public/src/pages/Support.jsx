import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Headset, Mail, Phone, MessageSquare, ChevronDown, Send } from 'lucide-react';

const faqs = [
    {
        question: 'How do I recharge my prepaid/postpaid plan?',
        answer: 'You can recharge using our website, mobile app, or authorized retailers. Enter your mobile number and select a plan to complete payment securely.',
    },
    {
        question: 'How can I check my data balance?',
        answer: 'Log in to your account on our website or app to see real-time usage details and remaining data balance.',
    },
    {
        question: 'How to pay my postpaid bill?',
        answer: 'Go to the Postpaid section and click "Pay Bill". You can use netbanking, UPI, or credit/debit cards.',
    },
    {
        question: 'How do I report a network issue?',
        answer: 'Contact our support team via call, chat, or submit a request using the form below. We will resolve it as soon as possible.',
    },
];

// --- Theme & Animation Constants ---
const PRIMARY_TEXT = 'text-teal-600';
const HEADER_GRADIENT = 'bg-gradient-to-r from-teal-50 to-cyan-50';
const CARD_GRADIENT = 'bg-gradient-to-br from-teal-600 to-cyan-500';

const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.2 } }
};

const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
};

const Support = () => {
    const [activeIndex, setActiveIndex] = useState(null);
    const [formData, setFormData] = useState({ name: '', email: '', message: '' });

    const handleSubmit = (e) => {
        e.preventDefault();
        alert('Support request submitted! Our team will contact you soon.');
        setFormData({ name: '', email: '', message: '' });
    };

    return (
        // Added pt-28 to clear the fixed header height
        <section className="min-h-screen bg-gray-50 font-poppins pb-20 pt-20 md:pt-24">
            
            {/* --- HERO SECTION --- */}
            <div className={`relative pt-16 pb-24 mb-12 overflow-hidden ${HEADER_GRADIENT} shadow-inner`}>
                {/* Decorative Background Circles */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-teal-200/20 rounded-full -mr-20 -mt-20 blur-3xl"></div>
                <div className="absolute bottom-0 left-0 w-64 h-64 bg-cyan-200/20 rounded-full -ml-20 -mb-20 blur-3xl"></div>

                <motion.div 
                    className="relative max-w-4xl px-4 mx-auto text-center"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                >
                    <motion.div variants={itemVariants} className="flex justify-center mb-6">
                        <div className="p-4 bg-white rounded-3xl shadow-xl text-teal-600 ring-4 ring-teal-50">
                            <Headset size={48} strokeWidth={1.5} />
                        </div>
                    </motion.div>
                    
                    <motion.h1 variants={itemVariants} className={`mb-4 text-5xl font-black tracking-tight ${PRIMARY_TEXT} md:text-6xl`}>
                        Customer Support
                    </motion.h1>
                    
                    <motion.p variants={itemVariants} className="mb-0 text-xl text-gray-600 md:text-2xl font-medium">
                        Need help with your plan or network? <br className="hidden md:block" /> We're here 24/7 to keep you connected.
                    </motion.p>
                </motion.div>
            </div>

            {/* --- QUICK LINKS (Overlap Effect) --- */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto px-6 mb-24 -mt-20 relative z-10">
                {['Billing & Payments', 'Recharge & Plans', 'Network Issues', 'Devices & Services'].map((item, i) => (
                    <motion.div
                        key={i}
                        variants={itemVariants}
                        initial="hidden"
                        animate="visible"
                        whileHover={{ y: -10, scale: 1.02 }}
                        className={`${CARD_GRADIENT} p-8 text-white shadow-2xl rounded-3xl cursor-pointer text-center font-bold flex flex-col items-center justify-center gap-4 border border-white/20 backdrop-blur-sm`}
                    >
                        <div className="bg-white/20 p-3 rounded-2xl"><MessageSquare size={28} /></div>
                        <span className="text-lg leading-tight">{item}</span>
                    </motion.div>
                ))}
            </div>

            <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-20">
                
                {/* --- FAQ SECTION --- */}
                <motion.div 
                    initial={{ opacity: 0, x: -30 }} 
                    whileInView={{ opacity: 1, x: 0 }} 
                    viewport={{ once: true }}
                >
                    <h2 className={`mb-8 text-3xl font-black tracking-tight ${PRIMARY_TEXT}`}>
                        Frequently Asked Questions
                    </h2>
                    <div className="space-y-4">
                        {faqs.map((faq, index) => (
                            <div key={index} className="bg-white rounded-2xl border border-gray-100 shadow-sm transition-all hover:shadow-md overflow-hidden">
                                <button
                                    className="w-full flex justify-between items-center p-6 text-left transition hover:bg-teal-50/30"
                                    onClick={() => setActiveIndex(activeIndex === index ? null : index)}
                                >
                                    <span className="font-bold text-gray-800 text-lg">{faq.question}</span>
                                    <motion.div 
                                        animate={{ rotate: activeIndex === index ? 180 : 0, backgroundColor: activeIndex === index ? '#0d9488' : '#f3f4f6' }}
                                        className="p-1 rounded-full transition-colors"
                                    >
                                        <ChevronDown size={20} className={activeIndex === index ? "text-white" : "text-teal-600"} />
                                    </motion.div>
                                </button>
                                <AnimatePresence>
                                    {activeIndex === index && (
                                        <motion.div
                                            initial={{ height: 0, opacity: 0 }}
                                            animate={{ height: 'auto', opacity: 1 }}
                                            exit={{ height: 0, opacity: 0 }}
                                            className="px-6 pb-6 text-gray-600 text-base leading-relaxed border-t border-gray-50 pt-2"
                                        >
                                            {faq.answer}
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        ))}
                    </div>
                </motion.div>

                {/* --- CONTACT FORM --- */}
                <motion.div 
                    initial={{ opacity: 0, x: 30 }} 
                    whileInView={{ opacity: 1, x: 0 }} 
                    viewport={{ once: true }}
                    className="p-10 rounded-[2.5rem] bg-white shadow-2xl border border-teal-50 relative overflow-hidden"
                >
                    <h2 className={`mb-2 text-3xl font-black ${PRIMARY_TEXT}`}>Still need help?</h2>
                    <p className="mb-10 text-gray-500 font-medium text-lg">Send us a message and our team will get back to you shortly.</p>
                    
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="space-y-2">
                            <label className="text-xs font-black text-teal-600/60 uppercase tracking-widest ml-1">Full Name</label>
                            <input
                                type="text"
                                className="w-full px-6 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:border-teal-500/20 focus:bg-white focus:ring-4 focus:ring-teal-500/5 transition-all outline-none text-gray-700 font-medium"
                                placeholder="John Doe"
                                value={formData.name}
                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                required
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-black text-teal-600/60 uppercase tracking-widest ml-1">Email Address</label>
                            <input
                                type="email"
                                className="w-full px-6 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:border-teal-500/20 focus:bg-white focus:ring-4 focus:ring-teal-500/5 transition-all outline-none text-gray-700 font-medium"
                                placeholder="john@example.com"
                                value={formData.email}
                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                required
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-black text-teal-600/60 uppercase tracking-widest ml-1">Your Message</label>
                            <textarea
                                className="w-full px-6 py-4 bg-gray-50 border-2 border-transparent rounded-2xl focus:border-teal-500/20 focus:bg-white focus:ring-4 focus:ring-teal-500/5 transition-all outline-none resize-none text-gray-700 font-medium"
                                rows={4}
                                placeholder="How can we assist you today?"
                                value={formData.message}
                                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                                required
                            ></textarea>
                        </div>
                        <motion.button
                            whileHover={{ scale: 1.02, boxShadow: '0 20px 25px -5px rgba(13, 148, 136, 0.3)' }}
                            whileTap={{ scale: 0.98 }}
                            type="submit"
                            className="w-full py-5 font-black text-white rounded-2xl bg-teal-600 hover:bg-teal-700 transition-all flex items-center justify-center gap-3 text-lg uppercase tracking-wider"
                        >
                            <Send size={20} /> Send Message
                        </motion.button>
                    </form>
                </motion.div>
            </div>

            {/* --- CONTACT METHODS INFO --- */}
            <motion.div 
                initial={{ opacity: 0, y: 20 }} 
                whileInView={{ opacity: 1, y: 0 }} 
                className="mt-24 flex flex-wrap justify-center gap-8 md:gap-16 text-gray-600 border-t border-gray-100 pt-16"
            >
                <div className="flex items-center gap-4 group cursor-pointer">
                    <div className="p-4 bg-teal-50 text-teal-600 rounded-2xl group-hover:bg-teal-600 group-hover:text-white transition-all duration-300 shadow-sm">
                        <Phone size={24} />
                    </div>
                    <div>
                        <p className="text-xs font-black text-teal-600/50 uppercase tracking-widest">Call Toll-Free</p>
                        <p className="text-xl font-black text-gray-800">1800-MY-TELCO</p>
                    </div>
                </div>
                <div className="flex items-center gap-4 group cursor-pointer">
                    <div className="p-4 bg-cyan-50 text-cyan-600 rounded-2xl group-hover:bg-cyan-600 group-hover:text-white transition-all duration-300 shadow-sm">
                        <Mail size={24} />
                    </div>
                    <div>
                        <p className="text-xs font-black text-teal-600/50 uppercase tracking-widest">Email Support</p>
                        <p className="text-xl font-black text-gray-800">help@mytelco.com</p>
                    </div>
                </div>
            </motion.div>
        </section>
    );
};

export default Support;