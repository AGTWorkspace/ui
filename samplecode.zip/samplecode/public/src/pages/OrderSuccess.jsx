import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, Home, ShoppingBag, Calendar, Hash, CreditCard } from 'lucide-react';

const OrderSuccess = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const plan = state?.plan;

  const [orderId, setOrderId] = useState('');

  useEffect(() => {
    if (!plan) return;

    // --- Logic Sync: Updated keys and calculation ---
    const basePrice = Number(plan.price.replace(/[^\d]/g, ''));
    const generatedOrderId = `ORD-${Date.now()}`;
    setOrderId(generatedOrderId);

    const newOrder = {
      orderId: generatedOrderId,
      state: 'Confirmed', // ✅ Logic change: using 'state' key
      description: `${plan.title} Plan Purchase`,
      customerId: `CUST-${Math.floor(100000 + Math.random() * 900000)}`,
      productDetails: `${plan.title} • ${plan.data} • ${plan.validity}`,
      orderDate: new Date().toLocaleDateString(), // ✅ Logic change: simple date string
      paymentDueDate: new Date(Date.now() + 7 * 86400000).toLocaleDateString(),
      basePrice, // ✅ Logic change: using 'basePrice' key
      discount_id: 'DISC50',
      discount_pct: 50,
      finalPrice: basePrice - 50
    };

    // --- LocalStorage Logic ---
    const existingOrders = JSON.parse(localStorage.getItem('orders')) || [];
    
    const alreadyExists = existingOrders.some(
      (o) => 
        o.description === newOrder.description && 
        o.finalPrice === newOrder.finalPrice && // ✅ Logic change: added price check
        o.orderDate === newOrder.orderDate
    );

    if (!alreadyExists) {
      localStorage.setItem('orders', JSON.stringify([newOrder, ...existingOrders]));
    }
  }, [plan]);

  if (!plan) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center font-poppins">
          <p className="text-slate-400 font-bold mb-4">No order found.</p>
          <button onClick={() => navigate('/')} className="text-teal-600 font-black underline">Return Home</button>
        </div>
      </div>
    );
  }

  return (
    <section className="min-h-screen bg-slate-50 font-poppins py-20 px-6 flex items-center justify-center">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-lg w-full bg-white rounded-[3rem] shadow-2xl shadow-teal-900/10 p-10 text-center relative overflow-hidden"
      >
        {/* Decorative Top Bar */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-teal-500 via-cyan-500 to-blue-500" />

        {/* Icon Animation */}
        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
          className="flex justify-center mb-6"
        >
          <div className="relative">
             <motion.div 
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="absolute inset-0 bg-teal-100 rounded-full blur-xl"
             />
             <CheckCircle size={80} className="text-teal-600 relative z-10 fill-white" />
          </div>
        </motion.div>

        <h1 className="text-3xl font-black text-slate-800 mb-2">Order Successful!</h1>
        <p className="text-slate-500 text-sm mb-10 px-4">
          Great news! Your <strong>{plan.title}</strong> plan is now active.
        </p>

        {/* Summary Card */}
        <div className="bg-slate-50 rounded-[2rem] p-6 text-left border border-slate-100 mb-10 space-y-4">
           <div className="flex items-center justify-between pb-3 border-b border-slate-200/50">
              <div className="flex items-center gap-2 text-slate-400">
                 <Hash size={14} />
                 <span className="text-[10px] font-black uppercase tracking-wider">Order ID</span>
              </div>
              <span className="text-xs font-mono font-bold text-slate-700">#{orderId}</span>
           </div>

           <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-400">
                 <Calendar size={14} />
                 <span className="text-[10px] font-black uppercase tracking-wider">Date</span>
              </div>
              <span className="text-xs font-bold text-slate-700">{new Date().toLocaleDateString()}</span>
           </div>

           <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-400">
                 <CreditCard size={14} />
                 <span className="text-[10px] font-black uppercase tracking-wider">Status</span>
              </div>
              <span className="px-3 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black rounded-full uppercase">Paid</span>
           </div>

           <div className="pt-2">
              <p className="text-[10px] font-black text-teal-600 uppercase mb-1">Plan Summary</p>
              <p className="text-sm font-bold text-slate-800">{plan.title} • {plan.data} • {plan.validity}</p>
           </div>
        </div>

        {/* Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            onClick={() => navigate('/')}
            className="flex items-center justify-center gap-2 py-4 px-6 rounded-2xl bg-slate-100 text-slate-600 font-bold text-sm hover:bg-slate-200 transition-all"
          >
            <Home size={18} />
            Home
          </button>

          <button
            onClick={() => navigate('/orders')}
            className="flex items-center justify-center gap-2 py-4 px-6 rounded-2xl bg-teal-600 text-white font-bold text-sm shadow-lg shadow-teal-600/20 hover:bg-teal-700 transition-all"
          >
            <ShoppingBag size={18} />
            My Orders
          </button>
        </div>
      </motion.div>
    </section>
  );
};

export default OrderSuccess;