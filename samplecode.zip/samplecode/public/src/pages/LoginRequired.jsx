import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Lock, ArrowRight, UserCheck } from "lucide-react";

const LoginRequired = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogin = () => {
    // Logic from your snippet: Redirects home and triggers the login modal
    navigate("/", {
      state: { openLogin: true, redirectTo: location.state?.redirectTo }
    });
  };

  return (
    <section className="min-h-[80vh] flex items-center justify-center bg-slate-50 font-poppins px-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-md w-full bg-white rounded-[3rem] shadow-2xl shadow-teal-900/10 p-10 text-center relative overflow-hidden border border-slate-100"
      >
        {/* Decorative Background Element */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-teal-50 rounded-full -mr-16 -mt-16" />
        
        {/* Animated Icon Circle */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            <motion.div 
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 3 }}
              className="absolute inset-0 bg-cyan-100 rounded-full blur-lg"
            />
            <div className="relative z-10 w-20 h-20 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-3xl flex items-center justify-center shadow-lg transform -rotate-6">
              <Lock size={36} className="text-white" />
            </div>
          </div>
        </div>

        {/* Content */}
        <h1 className="text-3xl font-black text-slate-800 mb-4">
          Login Required
        </h1>
        <p className="text-slate-500 mb-10 leading-relaxed">
          To provide a secure checkout and activate your personalized benefits, please sign in to your account.
        </p>

        {/* Action Buttons */}
        <div className="space-y-4">
          <button
            onClick={handleLogin}
            className="w-full flex items-center justify-center gap-3 py-4 bg-teal-600 text-white rounded-2xl font-bold shadow-lg shadow-teal-600/20 hover:bg-teal-700 hover:shadow-teal-600/40 transition-all group"
          >
            <UserCheck size={20} />
            Login Now
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={() => navigate(-1)}
            className="w-full py-4 text-slate-400 font-bold text-sm hover:text-teal-600 transition-colors"
          >
            Go Back
          </button>
        </div>

        {/* Bottom Detail */}
        <div className="mt-8 pt-8 border-t border-slate-50 flex items-center justify-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-300">
          <div className="w-1.5 h-1.5 rounded-full bg-teal-400" />
          Secure Authentication
        </div>
      </motion.div>
    </section>
  );
};

export default LoginRequired;