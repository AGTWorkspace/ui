// src/pages/PostpaidPlans.jsx
import React from 'react';
import { motion } from 'framer-motion';
import { useSearchParams } from 'react-router-dom'; // ✅ Added for location logic
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

// --- Theme Constants for Consistency ---
const PRIMARY_TEXT = 'text-teal-600';
const ACCENT_BADGE_BG = 'bg-cyan-500'; 
const HEADER_GRADIENT = 'bg-gradient-to-r from-teal-50 to-cyan-50';

// --- Framer Motion Variants for Header Content ---
const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
        opacity: 1,
        transition: {
            staggerChildren: 0.2,
            delayChildren: 0.3
        }
    }
};

const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
        y: 0,
        opacity: 1,
        transition: {
            type: 'spring',
            stiffness: 100,
            damping: 20
        }
    }
};

const PostpaidPlans = () => {
  // --- ✅ LOGIC ADDED: URL Location Filtering ---
  const [searchParams] = useSearchParams();
  const location = searchParams.get('location');

  const postpaidPlans = plansData.filter(plan =>
    plan.category === 'postpaid' &&
    (!location || plan.locations?.includes(location))
  );

  return (
    <section className="min-h-screen pt-12 bg-gray-50 font-poppins">
      
      {/* --- Modernized Header Section --- */}
      <div className={`relative pt-12 pb-16 mb-16 overflow-hidden ${HEADER_GRADIENT} shadow-lg border-b-4 border-teal-200`}>
        <motion.div 
          className="relative max-w-4xl px-4 mx-auto text-center"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          
          {/* Main Title - Animated */}
          <motion.h1 
            className={`mb-4 text-5xl font-black tracking-tight ${PRIMARY_TEXT} md:text-6xl`}
            variants={itemVariants}
          >
            Unmatched Postpaid Freedom
          </motion.h1>

          {/* ✅ LOGIC ADDED: Location Status Indicator */}
          {location && (
            <motion.p 
              variants={itemVariants}
              className="mb-4 text-teal-700 font-medium"
            >
              Showing plans available in <span className="font-bold underline text-cyan-600">{location}</span>
            </motion.p>
          )}
          
          {/* Subtitle - Animated */}
          <motion.p 
            className="mb-8 text-xl text-gray-700 md:text-2xl"
            variants={itemVariants}
          >
            Explore our best 5G Family Plans with data rollover, priority support, and premium OTT subscriptions included.
          </motion.p>
          
          {/* Badge/Highlight - Animated */}
          <motion.div 
            className={`inline-block px-8 py-3 text-sm font-bold text-white uppercase ${ACCENT_BADGE_BG} rounded-full shadow-xl transform hover:scale-105 transition duration-300`}
            variants={itemVariants}
          >
            ⭐️ Priority, Perks & Power ⭐️
          </motion.div>
          
        </motion.div>
      </div>

      {/* Plan List Container */}
      <div className="grid grid-cols-1 gap-10 px-6 max-w-7xl mx-auto -mt-20">
        {/* ✅ LOGIC ADDED: Conditional rendering for Empty State */}
        {postpaidPlans.length > 0 ? (
          <PlanList items={postpaidPlans} />
        ) : (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-white p-16 rounded-[2rem] shadow-xl text-center border-2 border-dashed border-teal-100"
          >
            <p className="text-xl text-gray-500 font-medium">
              No postpaid plans available for this location.
            </p>
          </motion.div>
        )}
      </div>

      {/* Footer Text */}
      <motion.div 
        className="max-w-4xl px-4 mx-auto mt-24 pb-8 text-sm text-center text-gray-500"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.5 }}
      >
        <p>*Taxes and regulatory fees may apply. All plans include 5G connectivity where available.</p>
      </motion.div>
    </section>
  );
};

export default PostpaidPlans;