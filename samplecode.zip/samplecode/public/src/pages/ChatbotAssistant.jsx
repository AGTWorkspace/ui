import React, { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useNavigate } from "react-router-dom"; // ✅ Logic Added
import CategorySelector from "../components/chatbot/CategorySelector";
import PlanSelector from "../components/chatbot/PlanSelector";
import plansData from "../data/plansData.json";

const ChatbotAssistant = ({ addMessage, isLoggedIn }) => {
  const navigate = useNavigate(); // ✅ Logic Added

  const [step, setStep] = useState("categories"); // 'categories' | 'plans' | 'confirm'
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedPlan, setSelectedPlan] = useState(null); // ✅ Logic Added

  // --- 🔐 LOGIC: Authentication Guard (Styled to match your Teal UI) ---
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F8FAFC] px-6">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white p-10 rounded-3xl shadow-2xl border border-slate-100 text-center max-w-md"
        >
          <div className="w-16 h-16 bg-red-50 text-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <span className="text-3xl">🔒</span>
          </div>
          <h2 className="text-2xl font-black mb-4 text-slate-900">Login Required</h2>
          <p className="text-slate-500 mb-8 font-medium">
            Please login to continue chatting and explore our premium plans.
          </p>
          <button
            onClick={() => navigate("/")}
            className="w-full py-4 rounded-2xl bg-teal-600 text-white font-bold shadow-lg shadow-teal-200 hover:bg-teal-700 transition-all"
          >
            Go to Login
          </button>
        </motion.div>
      </div>
    );
  }

  // --- ✅ LOGIC: Submit & Confirm Actions ---
  const handleCategorySubmit = () => {
    if (selectedCategories.length > 0) setStep("plans");
  };

  const handleConfirmPay = () => {
    // Add messages to the chat history
    addMessage({
      sender: "user",
      text: "✅ Order Confirmed and Paid"
    });

    addMessage({
      sender: "bot",
      text: "Thank you 🎉 Your payment is successful and order is confirmed."
    });

    navigate("/order-success", { state: { plan: selectedPlan } });
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] px-6 py-12 md:px-12">
      {/* Header Section */}
      <header className="max-w-4xl mx-auto text-center mb-12">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="inline-block px-4 py-1 rounded-full bg-teal-100 text-teal-700 text-xs font-black uppercase tracking-widest mb-4"
        >
          Smart Assistant
        </motion.div>
        <h1 className="text-4xl md:text-5xl font-black text-gray-900">
          Find Your Perfect <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-600 to-cyan-500">Connection</span>
        </h1>
      </header>

      {/* Main Flow with Animation */}
      <main className="relative max-w-6xl mx-auto">
        <AnimatePresence mode="wait">
          {step === "categories" && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.4 }}
            >
              <CategorySelector
                selected={selectedCategories}
                setSelected={setSelectedCategories}
                onSubmit={handleCategorySubmit}
                addMessage={addMessage} // ✅ Logic Added
              />
            </motion.div>
          )}

          {step === "plans" && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4 }}
            >
              <button 
                onClick={() => setStep("categories")}
                className="mb-6 text-teal-600 font-bold flex items-center gap-2 hover:underline"
              >
                ← Back to Categories
              </button>
              
              <PlanSelector
                categories={selectedCategories}
                plansData={plansData}
                setSelectedPlan={setSelectedPlan} // ✅ Logic Added
                setStep={setStep} // To move to 'confirm' step
                addMessage={addMessage} // ✅ Logic Added
              />
            </motion.div>
          )}

          {step === "confirm" && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-md mx-auto bg-white p-8 rounded-3xl shadow-xl border border-slate-100 text-center"
            >
              <h3 className="text-2xl font-black mb-4 text-slate-800">Confirm & Pay</h3>
              <p className="mb-8 text-slate-500 font-medium">
                You have selected: <br/>
                <span className="text-teal-600 text-xl font-bold">{selectedPlan?.title}</span>
              </p>
              <button
                onClick={handleConfirmPay}
                className="w-full py-4 rounded-2xl bg-teal-600 text-white font-bold shadow-lg shadow-teal-200 hover:bg-teal-700 transition-all"
              >
                Proceed to Payment
              </button>
              <button 
                onClick={() => setStep("plans")}
                className="mt-4 text-slate-400 text-sm font-bold hover:text-teal-600"
              >
                Change Plan
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};

export default ChatbotAssistant;