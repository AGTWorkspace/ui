import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, CreditCard, ShieldCheck, Zap, Info } from 'lucide-react';

const ConfirmOrder = ({ addMessage }) => { // ✅ Logic Added: Received addMessage prop
  const navigate = useNavigate();
  const { state } = useLocation();

  const plan = state?.plan;

  // 🔒 Logic: Prevent direct access if no plan is found in state
  if (!plan) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center font-poppins bg-slate-50 px-6">
        <div className="bg-white p-10 rounded-3xl shadow-2xl text-center max-w-md">
           <div className="w-20 h-20 bg-teal-50 text-teal-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Info size={40} />
           </div>
           <h2 className="text-2xl font-black text-slate-800 mb-2">No Plan Selected</h2>
           <p className="text-slate-500 mb-8">It looks like you haven't picked a plan yet. Let's get you started!</p>
           <button 
              onClick={() => navigate('/')}
              className="w-full py-4 bg-teal-600 text-white font-bold rounded-2xl shadow-lg hover:bg-teal-700 transition-all"
           >
              Browse Plans
           </button>
        </div>
      </div>
    );
  }

  // --- Logic Implementation ---
  const price = Number(plan.price.replace(/[^\d]/g, ''));
  const discount = plan.discount ?? 50; 
  const finalPrice = price - discount;

  const handleConfirm = () => {
    // ✅ Logic Added: Send order confirmation messages to Chatbot
    if (addMessage) {
      addMessage({
        sender: 'user',
        text: `✔ Order Confirmed\n• Plan: ${plan.title}\n• Price: ₹${finalPrice}`,
      });

      addMessage({
        sender: 'bot',
        text: 'Your order has been successfully confirmed! 🎉',
      });
    }

    // Navigate to success page
    navigate('/order-success', {
      state: {
        plan,
        price,
        discount,
        finalPrice,
      },
    });
  };

  return (
    <section className="min-h-screen bg-slate-50 font-poppins py-12 px-6">
      <div className="max-w-2xl mx-auto">
        
        {/* Back Button */}
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-slate-400 hover:text-teal-600 font-bold text-sm mb-8 transition-colors group"
        >
          <ChevronLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
          Back to Plans
        </button>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[2.5rem] shadow-2xl shadow-teal-900/5 overflow-hidden border border-slate-100"
        >
          {/* Header Section */}
          <div className="bg-gradient-to-br from-teal-600 to-cyan-600 p-10 text-white text-center relative overflow-hidden">
             <div className="relative z-10">
                <p className="text-cyan-100 text-xs font-black uppercase tracking-[0.2em] mb-2">Checkout Summary</p>
                <h1 className="text-4xl font-black tracking-tight">Review & Pay</h1>
             </div>
             <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
             <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-cyan-400/20 rounded-full blur-3xl"></div>
          </div>

          <div className="p-8 md:p-12">
            {/* Plan Info Card */}
            <div className="flex items-center justify-between p-6 rounded-3xl bg-teal-50 border border-teal-100 mb-10">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                     <Zap size={16} className="text-teal-600 fill-teal-600" />
                     <h2 className="text-xl font-black text-slate-800">{plan.title}</h2>
                  </div>
                  <p className="text-slate-500 font-medium text-sm">
                    {plan.data} Data • {plan.validity} Validity
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-black text-teal-600 uppercase tracking-wider">Plan Type</p>
                  <p className="text-sm font-bold text-slate-700 capitalize">{plan.type || 'Prepaid'}</p>
                </div>
            </div>

            {/* Price Breakdown */}
            <div className="space-y-5 mb-10">
               <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Payment Details</h3>
               
               <div className="flex justify-between items-center">
                  <span className="text-slate-600 font-medium">Base Plan Price</span>
                  <span className="text-slate-800 font-bold text-lg">₹{price.toLocaleString()}</span>
               </div>

               <div className="flex justify-between items-center text-emerald-600">
                  <div className="flex items-center gap-2">
                     <span className="font-medium">Special Discount</span>
                     <span className="text-[10px] bg-emerald-100 px-2 py-0.5 rounded-full font-black uppercase">Promo</span>
                  </div>
                  <span className="font-bold text-lg">- ₹{discount}</span>
               </div>

               <div className="pt-5 border-t border-dashed border-slate-200">
                  <div className="flex justify-between items-end">
                     <div>
                        <span className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-1">Total Payable</span>
                        <span className="text-4xl font-black text-slate-900 tracking-tighter">₹{finalPrice.toLocaleString()}</span>
                     </div>
                     <div className="text-right pb-1">
                        <span className="text-[10px] text-slate-400 font-bold block italic text-right">Incl. all taxes</span>
                     </div>
                  </div>
               </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-4">
               <motion.button
                 whileHover={{ scale: 1.02 }}
                 whileTap={{ scale: 0.98 }}
                 onClick={handleConfirm}
                 className="w-full py-5 bg-teal-600 text-white font-black rounded-2xl shadow-xl shadow-teal-600/20 flex items-center justify-center gap-3 text-lg hover:bg-teal-700 transition-all"
               >
                 <CreditCard size={20} />
                 Pay & Confirm Order
               </motion.button>

               <div className="flex items-center justify-center gap-2 text-slate-400 text-[11px] font-bold uppercase tracking-wider">
                  <ShieldCheck size={14} className="text-emerald-500" />
                  100% Secure SSL Encrypted Payment
               </div>
            </div>
          </div>
        </motion.div>

        {/* Support Link */}
        <p className="text-center mt-8 text-slate-400 text-sm">
          Need help with your order? <span className="text-teal-600 font-bold cursor-pointer hover:underline">Contact Support</span>
        </p>
      </div>
    </section>
  );
};

export default ConfirmOrder;