import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { 
  ShoppingBag, 
  Package, 
  Calendar, 
  User, 
  ArrowRight, 
  Clock, 
  CheckCircle2,
  Inbox,
  Hash,
  Lock
} from 'lucide-react';

const Orders = () => {
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // ✅ Logic: Authentication Check from snippet
    const user = JSON.parse(localStorage.getItem('mytelco_user'));

    if (!user || !user.isLoggedIn) {
      setIsLoggedIn(false);
      setOrders([]);
      return;
    }

    // ✅ Logic: Load Orders from snippet
    setIsLoggedIn(true);
    const storedOrders = JSON.parse(localStorage.getItem('orders')) || [];
    setOrders(storedOrders);
  }, []);

  // --- UI: NOT LOGGED IN STATE (UI Kept as original) ---
  if (!isLoggedIn) {
    return (
      <section className="min-h-screen flex items-center justify-center bg-slate-50 font-poppins px-6">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-10 rounded-[2.5rem] shadow-xl border border-slate-100 text-center max-w-md w-full"
        >
          <div className="w-20 h-20 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Lock size={40} />
          </div>
          <h2 className="text-2xl font-black text-slate-800 mb-3">Login Required</h2>
          <p className="text-slate-500 mb-8 font-medium">
            Please log in to your account to view and track your orders.
          </p>
          <button
            onClick={() => navigate('/')}
            className="w-full py-4 bg-teal-600 text-white font-bold rounded-2xl flex items-center justify-center gap-2 hover:bg-teal-700 transition-all shadow-lg shadow-teal-600/20"
          >
            Go to Home <ArrowRight size={18} />
          </button>
        </motion.div>
      </section>
    );
  }

  // --- UI: LOGGED IN STATE (UI Kept as original) ---
  return (
    <section className="min-h-screen bg-slate-50 font-poppins py-12 px-5 md:px-[10%]">
      {/* Header Section */}
      <div className="max-w-4xl mx-auto mb-10 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tight">My Orders</h1>
          <p className="text-slate-500 font-medium">Manage and track your recharge history.</p>
        </div>
        <div className="flex items-center gap-2 bg-teal-100 text-teal-700 px-4 py-2 rounded-2xl text-sm font-bold w-fit">
          <ShoppingBag size={18} />
          {orders.length} {orders.length === 1 ? 'Order' : 'Orders'}
        </div>
      </div>

      <div className="max-w-4xl mx-auto">
        {orders.length === 0 ? (
          /* Empty State */
          <div className="bg-white rounded-[2.5rem] p-16 text-center shadow-xl border border-slate-100">
            <div className="w-20 h-20 bg-slate-50 text-slate-300 rounded-full flex items-center justify-center mx-auto mb-6">
              <Inbox size={40} />
            </div>
            <h2 className="text-2xl font-black text-slate-800 mb-2">No orders found</h2>
            <p className="text-slate-500 mb-8">You haven't made any purchases yet.</p>
            <button 
              onClick={() => navigate('/')}
              className="mt-2 px-8 py-4 bg-teal-600 text-white font-bold rounded-2xl flex items-center gap-2 mx-auto hover:bg-teal-700 transition-all"
            >
              Browse Plans <ArrowRight size={18} />
            </button>
          </div>
        ) : (
          /* Orders List */
          <div className="space-y-6">
            {orders.map((order, index) => (
              <motion.div
                key={order.orderId || index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-[2rem] shadow-md border border-slate-100 overflow-hidden"
              >
                {/* 1. Header Area */}
                <div className="p-6 md:p-8 flex flex-col md:flex-row justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <div className="p-2 bg-teal-50 text-teal-600 rounded-xl">
                        <Package size={20} />
                      </div>
                      <h2 className="text-xl font-black text-slate-800">
                        {order.description}
                      </h2>
                    </div>
                    <div className="flex flex-wrap gap-4 text-[11px] font-bold text-slate-400 uppercase">
                      <span className="flex items-center gap-1.5"><Hash size={12} /> {order.orderId}</span>
                      <span className="flex items-center gap-1.5"><Calendar size={12} /> {order.orderDate}</span>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <span className="px-4 py-1.5 bg-emerald-50 text-emerald-600 rounded-full text-xs font-black uppercase border border-emerald-100 flex items-center gap-2">
                      <CheckCircle2 size={14} /> {order.state}
                    </span>
                  </div>
                </div>

                {/* 2. Content Area */}
                <div className="px-6 md:px-8 py-6 bg-slate-50/50 border-y border-slate-100 grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <p className="text-sm text-slate-600 flex items-center gap-2">
                      <User size={14} className="text-slate-400" /> 
                      <span className="font-bold text-slate-800">Customer:</span> {order.customerId}
                    </p>
                    <p className="text-sm text-slate-600 flex items-center gap-2">
                      <ShoppingBag size={14} className="text-slate-400" />
                      <span className="font-bold text-slate-800">Product:</span> {order.productDetails}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-slate-600 flex items-center gap-2">
                      <Clock size={14} className="text-slate-400" />
                      <span className="font-bold text-slate-800">Valid Until:</span> {order.paymentDueDate}
                    </p>
                  </div>
                </div>

                {/* 3. Pricing Area */}
                <div className="p-6 md:px-8 flex flex-col sm:flex-row justify-between items-center gap-4 bg-white">
                  <div className="flex gap-6">
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase">Base Price</p>
                      <p className="text-sm font-bold text-slate-600">₹{order.basePrice}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-emerald-500 uppercase">Discount ({order.discount_pct}%)</p>
                      <p className="text-sm font-bold text-emerald-600">-₹{order.discount_pct}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-black text-teal-600 uppercase">Amount Paid</p>
                    <p className="text-2xl font-black text-slate-900">₹{order.finalPrice}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default Orders;