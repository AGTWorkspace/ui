import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, useNavigate } from 'react-router-dom';

// Component Imports
import Header from './components/Header';
import Footer from './components/Footer';
import LoginModal from './components/LoginModal';
import ChatbotWidget from './components/ChatbotWidget';
import AnimatedRoutes from './components/AnimatedRoutes';

/* ---------------- WRAPPER ---------------- */
// We wrap the main App in Router here so App can use useNavigate()
function AppWrapper() {
  return (
    <Router>
      <App />
    </Router>
  );
}

/* ---------------- MAIN APP ---------------- */
function App() {
  const navigate = useNavigate(); // ✅ Logic: Required for redirection

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [mobileNumber, setMobileNumber] = useState('');

  // 🤖 CHATBOT STATE LOGIC
  const [messages, setMessages] = useState([
    { id: 1, sender: "bot", text: "Hi 👋 Type **plans** to explore our telecom plans." }
  ]);

  const addMessage = (msg) => {
    setMessages((prev) => [...prev, { id: Date.now(), ...msg }]);
  };

  // 🔐 PERSISTENCE LOGIC: Load from Session
  useEffect(() => {
    const user = JSON.parse(sessionStorage.getItem("mytelco_user"));
    if (user?.isLoggedIn) {
      setIsLoggedIn(true);
      setMobileNumber(user.mobileNumber || "");
    }
  }, []);

  // ✅ Logic: Handle User Authentication + Redirect
  const handleLoginSuccess = (number) => {
    sessionStorage.setItem(
      "mytelco_user",
      JSON.stringify({ isLoggedIn: true, mobileNumber: number })
    );

    setMobileNumber(number);
    setIsLoggedIn(true);
    setIsModalOpen(false);

    addMessage({
      sender: "bot",
      text: "✅ Login successful! You can continue your plan purchase."
    });

    navigate("/"); // ✅ Logic: Redirect to home after login
  };

  const handleLogout = () => {
    sessionStorage.clear();
    setIsLoggedIn(false);
    setMobileNumber("");
    addMessage({ sender: "bot", text: "👋 You have been logged out." });
    
    navigate("/"); // ✅ Logic: Redirect to home after logout
  };

  return (
    <div className="flex flex-col min-h-screen font-poppins bg-white">
      
      <Header
        onShowLogin={() => setIsModalOpen(true)}
        isLoggedIn={isLoggedIn}
        mobileNumber={mobileNumber}
        onLogout={handleLogout}
      />

      <main className="flex-grow overflow-x-hidden pt-16 md:pt-20">
        {/* AnimatedRoutes handles page transitions internally */}
        <AnimatedRoutes 
          addMessage={addMessage} 
          isLoggedIn={isLoggedIn} 
        />
      </main>

      <LoginModal
        isVisible={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      <Footer />

      <ChatbotWidget 
        messages={messages}
        setMessages={setMessages}
        addMessage={addMessage}
        isLoggedIn={isLoggedIn}
        onLoginClick={() => setIsModalOpen(true)}
      />
    </div>
  );
}

export default AppWrapper;