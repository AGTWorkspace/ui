// src/data/plans.js (You would typically put this in a separate file)
export const PLANS_DATA = [
    // Prepaid
    { id: 'p1', type: 'prepaid', title: 'The Starter Plan', price: '₹ 299', data: '1.5 GB', validity: '28 Days', badge: 'BEST VALUE', badgeColor: 'text-accent', details: ['Unlimited Voice Calls & 100 SMS/Day.', 'Free access to Vi Movies & TV Basic subscription.'] },
    { id: 'p2', type: 'prepaid', title: 'Entertainment Super', price: '₹ 994', data: '2 GB', validity: '84 Days', badge: 'ENTERTAINMENT!', badgeColor: 'text-danger', details: ['All Hero Benefits (Rollover, Binge All Night).', '1-Year Disney+ Hotstar Mobile subscription.'] },
    { id: 'p3', type: 'prepaid', title: 'The Annual Saver', price: '₹ 2999', data: '2 GB', validity: '365 Days', details: ['Total 730 GB High-Speed Data. Unlimited 5G Data.', 'Includes ₹100 cashback via MyTelco App.'] },
    { id: 'p4', type: 'prepaid', title: 'Mega Data Booster', price: '₹ 499', data: '75 GB', validity: 'Existing', badge: 'DATA PACK', badgeColor: 'text-yellow-600', borderColor: 'border-yellow-600', buttonText: 'Activate Now', details: ['Adds 75GB of high-speed data to your existing primary plan.', 'Perfect for heavy users who run out of data.'] },

    // Postpaid
    { id: 'po1', type: 'postpaid', title: 'Basic Postpaid', price: '₹ 451', data: '50 GB', validity: 'Monthly', buttonClass: 'bg-accent hover:bg-green-700', details: ['50 GB High-Speed Data + 200 GB Data Rollover.', 'Choose 1 Complimentary Benefit (e.g., Hotstar Mobile).'] },
    { id: 'po2', type: 'postpaid', title: 'Value Plan', price: '₹ 551', data: '90 GB', validity: 'Monthly', badge: 'POPULAR', badgeColor: 'text-accent', buttonClass: 'bg-accent hover:bg-green-700', details: ['90 GB High-Speed Data + 200 GB Data Rollover.', 'Choose 2 Complimentary Benefits (e.g., Amazon Prime + SonyLIV).'] },
    { id: 'po3', type: 'postpaid', title: 'Premium Choice', price: '₹ 751', data: '150 GB', validity: 'Monthly', buttonClass: 'bg-accent hover:bg-green-700', details: ['150 GB High-Speed Data + 200 GB Data Rollover.', 'Choose 3 Complimentary Benefits and lifestyle benefits.'] },
    { id: 'po4', type: 'postpaid', title: 'The Fully Loaded', price: '₹ 1201', data: 'Unlimited', validity: 'Monthly', badge: 'REDX EXCLUSIVE', badgeColor: 'text-danger', borderColor: 'border-danger', buttonText: 'Activate REDX', details: ['Truly Unlimited High-Speed Data.', 'Premium OTT: Netflix Basic, Amazon Prime, Disney+ Hotstar Super.', 'Airport lounge access + Free International Roaming pack.'] },
];