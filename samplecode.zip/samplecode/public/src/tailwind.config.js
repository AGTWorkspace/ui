/** @type {import('tailwindcss').Config} */
export default {
    // Correct, merged content paths
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}", 
    ],
    theme: {
        extend: {
            colors: {
                // Existing Custom Colors
                primary: '#007bff',      // Blue
                secondary: '#f7f9fc',    
                accent: '#28a745',       // Green
                danger: '#dc3545',       // Red
            },
            borderRadius: {
                'xl': '12px',
            },
            boxShadow: {
                'soft': '0 4px 12px rgba(0, 0, 0, 0.1)',
                // Custom glow for Chatbot toggle button
                glow: "0 8px 30px rgba(0,123,255,0.18)" 
            },
            
            // --- CHATBOT ANIMATIONS ---
            keyframes: {
                bounceDot: {
                    "0%, 80%, 100%": { transform: "translateY(0)", opacity: ".45" },
                    "40%": { transform: "translateY(-6px)", opacity: "1" }
                },
                statusIn: {
                    "0%": { transform: "scale(0.85)", opacity: "0" },
                    "100%": { transform: "scale(1)", opacity: "1" }
                },
                statusOut: {
                    "0%": { transform: "scale(1)", opacity: "1" },
                    "100%": { transform: "scale(0.85)", opacity: "0" }
                },
                swipeIn: {
                    "0%": { transform: "translateX(40px)", opacity: "0" },
                    "100%": { transform: "translateX(0)", opacity: "1" }
                }
            },
            animation: {
                bounceDot: "bounceDot 1s infinite ease-in-out",
                statusIn: "statusIn .25s ease forwards",
                statusOut: "statusOut .25s ease forwards",
                swipeIn: "swipeIn .25s ease-out"
            }
            // --- END CHATBOT ANIMATIONS ---
        }
    },
    plugins: [],
}