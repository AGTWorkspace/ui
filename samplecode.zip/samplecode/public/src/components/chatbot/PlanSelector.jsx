import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Zap, ShieldCheck, Clock } from "lucide-react";

// Added addMessage and setSelectedPlan to props
const PlanSelector = ({ categories, plansData, addMessage, setSelectedPlan }) => {
  const navigate = useNavigate();
  const filteredPlans = plansData.filter((p) => categories.includes(p.category));

  const handleChoosePlan = (plan) => {
    const details = plan.offeringDetails || {};
    const planInfo = details.plan || {};

    const normalizedPlan = {
      title: details.name || "Selected Plan",
      price: `₹${plan.price}`,
      data: planInfo.data || "N/A",
      validity: plan.validityMonths ? `${plan.validityMonths} month(s)` : "N/A",
      rawPlan: plan, // added from logic code
    };

    // LOGIC UPDATE: Save selected plan in parent state
    if (setSelectedPlan) {
        setSelectedPlan(normalizedPlan);
    }

    // LOGIC UPDATE: Send formatted details to chatbot
    if (addMessage) {
      addMessage({
        sender: "user",
        text: `📦 Selected Plan\n• ${normalizedPlan.title}\n• ${normalizedPlan.price}\n• ${normalizedPlan.data}\n• ${normalizedPlan.validity}`,
      });

      setTimeout(() => {
        addMessage({
          sender: "bot",
          text: "Great choice! 🎉 Please confirm your order.",
        });
      }, 600);
    }

    // Navigate to checkout
    navigate("/confirm-order", { state: { plan: normalizedPlan } });
  };

  // --- UI REMAINS UNCHANGED ---
  return (
    <div className="max-w-7xl mx-auto py-8">
      <div className="flex items-center justify-between mb-8">
        <h3 className="text-2xl font-black text-gray-900">Recommended for you</h3>
        <span className="bg-teal-100 text-teal-700 px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
          {filteredPlans.length} Plans Found
        </span>
      </div>

      {filteredPlans.length === 0 ? (
        <div className="bg-white p-12 rounded-[2rem] text-center border-2 border-dashed border-gray-200">
           <p className="text-gray-400 font-medium">No plans matching these categories yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPlans.map((plan, index) => {
            const details = plan.offeringDetails || {};
            const planInfo = details.plan || {};

            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1, transition: { delay: index * 0.1 } }}
                className="group relative bg-white rounded-[2rem] p-8 shadow-xl border border-gray-100 flex flex-col hover:border-teal-400 transition-colors"
              >
                <h4 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-teal-600 transition-colors">
                  {details.name}
                </h4>
                
                <div className="flex items-baseline gap-1 mb-6">
                  <span className="text-4xl font-black text-teal-600">₹{plan.price}</span>
                  <span className="text-gray-400 text-sm">/period</span>
                </div>

                <div className="space-y-4 mb-8 flex-grow">
                  {planInfo.data && (
                    <div className="flex items-center gap-3 text-gray-700">
                      <Zap size={18} className="text-cyan-500" />
                      <span className="text-sm font-semibold">{planInfo.data} High-speed Data</span>
                    </div>
                  )}
                  {plan.validityMonths && (
                    <div className="flex items-center gap-3 text-gray-700">
                      <Clock size={18} className="text-cyan-500" />
                      <span className="text-sm font-semibold">{plan.validityMonths} Months Validity</span>
                    </div>
                  )}
                  <div className="flex items-center gap-3 text-gray-700">
                    <ShieldCheck size={18} className="text-cyan-500" />
                    <span className="text-sm font-semibold">Premium Support Included</span>
                  </div>
                </div>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleChoosePlan(plan)}
                  className="w-full py-4 rounded-xl font-bold bg-gray-900 text-white hover:bg-teal-600 transition-colors shadow-lg"
                >
                  Choose this Plan
                </motion.button>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default PlanSelector;