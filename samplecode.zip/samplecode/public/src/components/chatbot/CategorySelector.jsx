import React from "react";
import { motion } from "framer-motion";
import { Check } from "lucide-react";

const categories = [
  { label: "Prepaid", value: "pre-paid", icon: "📱" },
  { label: "Postpaid", value: "postpaid", icon: "💼" },
  { label: "Fiber-net", value: "fiber-net", icon: "🌐" },
  { label: "Entertainment", value: "entertainment", icon: "🎬" },
  { label: "Devices", value: "device", icon: "📦" },
  { label: "Bundles", value: "bundles", icon: "🎁" }
];

// ✅ LOGIC UPDATE: Added addMessage prop
const CategorySelector = ({ selected, setSelected, onSubmit, addMessage }) => {
  const toggle = (val) => {
    setSelected((prev) =>
      prev.includes(val) ? prev.filter((c) => c !== val) : [...prev, val]
    );
  };

  // ✅ LOGIC UPDATE: Handle continue with chatbot messaging
  const handleContinue = () => {
    if (addMessage) {
      // Send selected categories as a user message
      addMessage({
        sender: "user",
        text: `📂 Selected Categories: ${selected.join(", ")}`
      });

      // Send bot confirmation message
      addMessage({
        sender: "bot",
        text: "Great 👍 Let me show you the best plans."
      });
    }

    onSubmit();
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto bg-white rounded-[2.5rem] p-8 md:p-12 shadow-2xl border border-gray-100"
    >
      <div className="text-center mb-10">
        <h3 className="text-3xl font-black text-gray-900 mb-3">
          What are you looking for?
        </h3>
        <p className="text-gray-500">Select one or more categories to customize your results.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        {categories.map(({ label, value, icon }, index) => {
          const active = selected.includes(value);

          return (
            <motion.button
              key={value}
              whileHover={{ scale: 1.03, y: -5 }}
              whileTap={{ scale: 0.97 }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0, transition: { delay: index * 0.05 } }}
              onClick={() => toggle(value)}
              className={`relative flex flex-col items-center justify-center p-6 rounded-3xl border-2 transition-all duration-300
                ${active 
                  ? "border-teal-500 bg-teal-50 text-teal-700 shadow-lg shadow-teal-100" 
                  : "border-gray-100 bg-gray-50 text-gray-600 hover:border-teal-200"
                }`}
            >
              {active && (
                <div className="absolute top-3 right-3 bg-teal-500 text-white rounded-full p-1">
                  <Check size={12} strokeWidth={4} />
                </div>
              )}
              <span className="text-4xl mb-3">{icon}</span>
              <span className="font-bold tracking-tight">{label}</span>
            </motion.button>
          );
        })}
      </div>

      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={handleContinue} // ✅ LOGIC UPDATE: Switched to handleContinue
        disabled={!selected.length}
        className={`mt-12 w-full py-4 rounded-2xl font-bold text-lg shadow-xl transition-all
          ${selected.length
            ? "bg-gradient-to-r from-teal-600 to-cyan-500 text-white shadow-teal-200"
            : "bg-gray-200 text-gray-400 cursor-not-allowed shadow-none"
          }`}
      >
        Continue to Plans
      </motion.button>
    </motion.div>
  );
};

export default CategorySelector;