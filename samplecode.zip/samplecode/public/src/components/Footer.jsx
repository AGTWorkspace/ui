import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
    // --- Theme Constants ---
    const HOVER_COLOR = 'hover:text-cyan-400';
    const BORDER_COLOR = 'border-teal-500/30';
    const PRIMARY_TEAL_TEXT = 'text-teal-400';

    return (
        <footer className="bg-slate-900 text-gray-400 py-16 px-5 md:px-[5%] text-sm font-poppins relative overflow-hidden">
            {/* Background Decorative Element */}
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-teal-500 via-cyan-500 to-teal-500"></div>
            
            <motion.div 
                className="max-w-7xl mx-auto flex flex-wrap justify-between relative z-10"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
            >
                {/* Section: About MyTelco */}
                <div className="w-full md:w-1/4 mb-10 corporate-info min-w-[250px] pr-4">
                    <h4 className={`mb-6 text-xl font-bold text-white border-b-2 ${BORDER_COLOR} pb-2 inline-block`}>
                        My<span className={PRIMARY_TEAL_TEXT}>Telco</span>
                    </h4>
                    <p className="text-gray-400 leading-relaxed mb-6">
                        Leading India's digital revolution with ultra-fast 5G connectivity and innovative digital solutions for a billion dreams.
                    </p>
                    <div className="space-y-3">
                        <div className="flex items-center gap-3">
                            <MapPin size={16} className={PRIMARY_TEAL_TEXT} />
                            <span className="text-xs">Cyber City, Mumbai - 400001</span>
                        </div>
                        <div className="flex items-center gap-3">
                            <Phone size={16} className={PRIMARY_TEAL_TEXT} />
                            <span className="text-xs">+91 1800-MY-TELCO</span>
                        </div>
                    </div>
                </div>
                
                {/* Section: Products & Services */}
                <div className="w-1/2 md:w-1/6 mb-8 min-w-[150px]">
                    <h4 className="mb-6 text-lg font-semibold text-white">Products</h4>
                    <ul className="space-y-3">
                        <li><Link to="/recharge" className={`transition-colors duration-300 ${HOVER_COLOR}`}>Prepaid Plans</Link></li>
                        <li><Link to="/postpaid" className={`transition-colors duration-300 ${HOVER_COLOR}`}>Postpaid Plans</Link></li>
                        <li><Link to="/fiber" className={`transition-colors duration-300 ${HOVER_COLOR}`}>Fiber Broadband</Link></li>
                        <li><Link to="/devices" className={`transition-colors duration-300 ${HOVER_COLOR}`}>Devices</Link></li>
                    </ul>
                </div>
                
                {/* Section: Support & Help */}
                <div className="w-1/2 md:w-1/6 mb-8 min-w-[150px]">
                    <h4 className="mb-6 text-lg font-semibold text-white">Support</h4>
                    <ul className="space-y-3">
                        <li><a href="#" className={`transition-colors duration-300 ${HOVER_COLOR}`}>Help Center</a></li>
                        <li><a href="#" className={`transition-colors duration-300 ${HOVER_COLOR}`}>Track SIM</a></li>
                        <li><a href="#" className={`transition-colors duration-300 ${HOVER_COLOR}`}>Store Locator</a></li>
                        <li><a href="#" className={`transition-colors duration-300 ${HOVER_COLOR}`}>Contact Us</a></li>
                    </ul>
                </div>
                
                {/* Section: Social & Newsletter */}
                <div className="w-full md:w-1/4 mb-8 min-w-[200px]">
                    <h4 className="mb-6 text-lg font-semibold text-white">Follow Us</h4>
                    <div className="flex gap-4 mb-8">
                        {[Facebook, Twitter, Instagram, Linkedin].map((Icon, index) => (
                            <motion.a 
                                key={index}
                                href="#" 
                                whileHover={{ y: -5, scale: 1.1 }}
                                className={`p-2 rounded-full bg-gray-800 text-gray-300 hover:bg-teal-600 hover:text-white transition-all`}
                            >
                                <Icon size={20} />
                            </motion.a>
                        ))}
                    </div>
                    <p className="text-xs mb-4 text-gray-500 font-medium italic">"Stay connected, stay ahead."</p>
                </div>
            </motion.div>
            
            {/* Footer Bottom */}
            <div className="max-w-7xl mx-auto pt-8 mt-8 border-t border-gray-800/50 flex flex-col md:flex-row justify-between items-center gap-4">
                <p className="text-gray-500 text-xs">
                    &copy; 2025 MyTelco Private Limited. All Rights Reserved.
                </p>
                <div className="flex gap-6 text-xs text-gray-500">
                    <a href="#" className="hover:text-teal-400">Terms</a>
                    <a href="#" className="hover:text-teal-400">Privacy</a>
                    <a href="#" className="hover:text-teal-400">Cookies</a>
                </div>
            </div>
        </footer>
    );
};

export default Footer;