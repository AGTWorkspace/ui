import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';
import PlanCard from './PlanCard';

// --- Theme Constants (Kept as is) ---
const PRIMARY_TEAL = 'text-teal-600';
const BUTTON_TEAL = 'bg-teal-600 hover:bg-teal-700';

/* ---------------- DEVICE CARD ---------------- */
const DeviceCard = ({ item, index }) => {
  const navigate = useNavigate();

  // ✅ UPDATED LOGIC: Auth Check + Navigation Logic added
  const handleBuy = () => {
    // 🔐 Get user from session
    const user = JSON.parse(sessionStorage.getItem("mytelco_user"));

    // Normalize device data for checkout (Kept from your original UI code)
    const plan = {
      id: item.id,
      type: 'device',
      title: item.offeringDetails?.name || 'Device',
      price: typeof item.price === 'number' ? `₹ ${item.price}` : item.price,
      data: '—',
      validity: '—',
      buttonText: 'Buy Device',
      details: item.specification
        ? Object.entries(item.specification).map(([k, v]) => `${k}: ${v}`)
        : [item.description || '—'],
    };

    // 🔐 NOT LOGGED IN → Redirect to Login Required
    if (!user?.isLoggedIn) {
      navigate('/login-required', {
        state: {
          plan,
          redirectTo: '/confirm-order'
        }
      });
      return;
    }

    // ✅ LOGGED IN → Proceed to Confirm Order
    navigate('/confirm-order', { state: { plan } });
  };

  return (
    <motion.div
      className="p-6 bg-white rounded-xl shadow-lg border border-gray-100 flex flex-col h-full"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        type: 'spring',
        stiffness: 100,
        damping: 20,
        delay: index * 0.1, // Staggered delay preserved
      }}
      whileHover={{ scale: 1.02, boxShadow: '0 10px 20px rgba(13, 148, 136, 0.2)' }}
    >
      <h3 className={`text-xl font-bold mb-2 ${PRIMARY_TEAL}`}>
        {item.offeringDetails.name}
      </h3>
      <p className="text-sm text-gray-600 mb-3">{item.description}</p>

      {/* Specifications List */}
      {item.specification && (
        <ul className="text-sm text-gray-700 mb-6 pl-4 list-disc space-y-1">
          {Object.entries(item.specification).map(([k, v]) => (
            <li key={k}>
              <span className="font-semibold">{k}:</span> {v}
            </li>
          ))}
        </ul>
      )}

      <div className="mt-auto flex items-center justify-between border-t pt-4 border-gray-100">
        <div className="text-xl font-bold text-cyan-600">
          {typeof item.price === 'number' ? `₹ ${item.price}` : item.price}
        </div>

        <button
          onClick={handleBuy}
          className={`px-5 py-2 rounded-full text-white font-semibold shadow-md transition ${BUTTON_TEAL}`}
        >
          Buy Now
        </button>
      </div>
    </motion.div>
  );
};

/* ---------------- PLAN LIST ---------------- */
const PlanList = ({ items }) => {
  return (
    <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {items.map((item, index) => {
        // Logic: Handle Plan Categories
        if (['pre-paid', 'postpaid', 'fiber-net', 'entertainment', 'bundle'].includes(item.category)) {
          const plan = {
            id: item.id,
            type: item.category === 'postpaid' ? 'postpaid' : 'prepaid',
            title: item.offeringDetails.name || item.offeringDetails.plan?.serviceId,
            price: typeof item.price === 'number' ? `₹ ${item.price}` : item.price,
            data: item.offeringDetails.plan?.data || '—',
            validity: item.validityMonths ? `${item.validityMonths}m` : '—',
            badge: item.isRecurring ? 'Recurring' : undefined,
            borderColor: item.borderColor || 'border-teal-500',
            buttonClass: item.buttonClass || 'bg-teal-600',
            buttonText: item.buttonText || 'Choose Plan',
            details: item.offeringDetails.plan?.features
              ? Object.keys(item.offeringDetails.plan.features).map((k) => {
                  const v = item.offeringDetails.plan.features[k];
                  return Array.isArray(v) ? `${k}: ${v.join(', ')}` : `${k}: ${v}`;
                })
              : ['Unlimited Calling', 'High Speed Data'],
          };

          return <PlanCard key={item.id} plan={plan} index={index} />;
        }

        // Logic: Handle Device Category
        return <DeviceCard key={item.id} item={item} index={index} />;
      })}
    </div>
  );
};

export default PlanList;