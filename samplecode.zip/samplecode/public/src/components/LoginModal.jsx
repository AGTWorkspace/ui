import React, { useState, useEffect, useRef } from 'react';
import { X, CheckCircle, Smartphone, ShieldCheck, UserPlus, Mail, MapPin, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const LoginModal = ({ isVisible, onClose, onLoginSuccess }) => {
  // --- Theme & State Setup ---
  const ACCENT_COLOR = 'teal-600';
  const BUTTON_STYLE = `w-full py-4 font-bold text-white rounded-2xl transition-all flex justify-center items-center gap-2 bg-teal-600 hover:bg-teal-700 shadow-lg shadow-teal-200 disabled:opacity-50`;

  const [step, setStep] = useState('mobile'); // mobile | otp | register
  const [mobileInput, setMobileInput] = useState('');
  const [otpInput, setOtpInput] = useState(Array(6).fill(''));
  const [otpError, setOtpError] = useState(false);
  const [timer, setTimer] = useState(60);
  const [isLoading, setIsLoading] = useState(false);

  const [form, setForm] = useState({
    email: '', firstName: '', lastName: '', streetNo: '',
    streetName: '', city: '', state: '', postcode: '', country: ''
  });
  const [errors, setErrors] = useState({});
  
  const otpRefs = useRef([]);
  const timerRef = useRef(null);

  // --- Reset & Timer Logic ---
  useEffect(() => {
    if (!isVisible) {
      setStep('mobile');
      setMobileInput('');
      setOtpInput(Array(6).fill(''));
      setErrors({});
      setOtpError(false);
      setForm({ email: '', firstName: '', lastName: '', streetNo: '', streetName: '', city: '', state: '', postcode: '', country: '' });
    }
  }, [isVisible]);

  useEffect(() => {
    if (step === 'otp') {
      setTimer(60);
      timerRef.current = setInterval(() => {
        setTimer(t => (t > 0 ? t - 1 : 0));
      }, 1000);
      return () => clearInterval(timerRef.current);
    }
  }, [step]);

  // --- LOGIC UPDATE: Persistent Login with Profile Data ---
  const completeLogin = (profileData = null) => {
    const userData = {
      mobile: mobileInput,
      isLoggedIn: true,
      profile: profileData
    };

    // Save to localStorage so Header can detect auth on refresh
    localStorage.setItem('mytelco_user', JSON.stringify(userData));

    onLoginSuccess(mobileInput);
    onClose();
  };

  // --- Handlers ---
  const handleMobileSubmit = (e) => {
    e.preventDefault();
    if (/^\d{10}$/.test(mobileInput)) {
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        setStep('otp');
        setTimeout(() => otpRefs.current[0]?.focus(), 100);
      }, 800);
    } else {
      alert('Enter a valid 10-digit mobile number');
    }
  };

  const handleOtpVerify = (e) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      if (otpInput.join('') === '123456') {
        // Logic: If number ends with '0', go to registration, else login
        mobileInput.endsWith('0') ? setStep('register') : completeLogin();
      } else {
        setOtpError(true);
        setOtpInput(Array(6).fill(''));
        otpRefs.current[0]?.focus();
      }
    }, 800);
  };

  const validateForm = () => {
    const e = {};
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = 'Invalid email';
    if (form.firstName.length < 2) e.firstName = 'Too short';
    if (form.lastName.length < 2) e.lastName = 'Too short';
    if (!form.streetNo) e.streetNo = 'Req';
    if (!form.streetName) e.streetName = 'Req';
    if (!form.city) e.city = 'Req';
    if (!form.state) e.state = 'Req';
    if (!/^\d{4,8}$/.test(form.postcode)) e.postcode = 'Invalid';
    if (!form.country) e.country = 'Req';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleRegisterSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        // LOGIC UPDATE: Pass the form data to the completeLogin function
        completeLogin(form);
      }, 1000);
    }
  };

  // --- UI Components ---
  const inputClass = (err) => `w-full px-4 py-3 rounded-xl border-2 text-sm font-medium transition-all outline-none 
    ${err ? 'border-red-400 bg-red-50' : 'border-slate-100 bg-slate-50 focus:border-teal-500 focus:bg-white'}`;

  return (
    <AnimatePresence>
      {isVisible && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={onClose} className="absolute inset-0 bg-slate-900/70 backdrop-blur-sm"
          />
          
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className={`relative w-full ${step === 'register' ? 'max-w-2xl' : 'max-w-md'} bg-white rounded-3xl shadow-2xl overflow-hidden`}
          >
            <div className="h-2 bg-gradient-to-r from-teal-500 to-cyan-400" />
            
            <div className="p-8">
              <button onClick={onClose} className="absolute top-5 right-5 p-2 text-slate-400 hover:bg-slate-100 rounded-full transition-all">
                <X size={20} />
              </button>

              <AnimatePresence mode="wait">
                {/* 1. MOBILE STEP */}
                {step === 'mobile' && (
                  <motion.div key="mobile" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <div className="w-16 h-16 bg-teal-50 text-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                      <Smartphone size={32} />
                    </div>
                    <h2 className="text-2xl font-black text-slate-800 text-center mb-2">Welcome to MyTelco</h2>
                    <p className="text-slate-500 text-sm text-center mb-8">Login or Create an account using your mobile.</p>
                    <form onSubmit={handleMobileSubmit} className="space-y-4">
                      <div className="flex items-center border-2 border-slate-100 rounded-2xl overflow-hidden bg-slate-50 focus-within:border-teal-500 transition-all">
                        <span className="pl-5 pr-3 py-4 font-bold text-slate-400 border-r border-slate-200">+91</span>
                        <input type="tel" maxLength="10" className="w-full p-4 bg-transparent font-bold text-slate-700 outline-none" 
                        placeholder="Mobile Number" value={mobileInput} onChange={e => setMobileInput(e.target.value.replace(/\D/g, ""))} required />
                      </div>
                      <button disabled={isLoading || mobileInput.length < 10} className={BUTTON_STYLE}>
                        {isLoading ? <Loader2 className="animate-spin" /> : 'Get OTP'}
                      </button>
                    </form>
                  </motion.div>
                )}

                {/* 2. OTP STEP */}
                {step === 'otp' && (
                  <motion.div key="otp" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                    <div className="w-16 h-16 bg-cyan-50 text-cyan-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                      <ShieldCheck size={32} />
                    </div>
                    <h2 className="text-2xl font-black text-slate-800 text-center mb-2">Verify OTP</h2>
                    <p className="text-slate-500 text-sm text-center mb-6 flex items-center justify-center gap-2">
                      <CheckCircle size={16} className="text-teal-500" /> Sent to +91 {mobileInput}
                    </p>
                    <form onSubmit={handleOtpVerify} className="space-y-6">
                      <div className="flex justify-between gap-2">
                        {otpInput.map((d, i) => (
                          <input key={i} ref={el => otpRefs.current[i] = el} type="text" maxLength="1" 
                          className={`w-12 h-14 text-xl font-black text-center border-2 rounded-xl transition-all 
                          ${otpError ? 'border-red-400 bg-red-50' : 'border-slate-100 bg-slate-50 focus:border-teal-500 focus:bg-white'}`}
                          value={d} onChange={e => {
                            const v = e.target.value.slice(-1); if (!/\d/.test(v)) return;
                            const o = [...otpInput]; o[i] = v; setOtpInput(o); setOtpError(false);
                            if (v && i < 5) otpRefs.current[i + 1]?.focus();
                          }} onKeyDown={e => e.key === 'Backspace' && !otpInput[i] && i > 0 && otpRefs.current[i-1].focus()} required />
                        ))}
                      </div>
                      <button disabled={isLoading || otpInput.includes('')} className={BUTTON_STYLE}>
                        {isLoading ? <Loader2 className="animate-spin" /> : 'Verify OTP'}
                      </button>
                      <div className="text-center text-xs font-bold text-slate-400 uppercase tracking-widest cursor-pointer" 
                        onClick={() => timer === 0 && setTimer(60)}>
                        {timer > 0 ? `Resend in ${timer}s` : <span className="text-teal-600 hover:underline">Resend Now</span>}
                      </div>
                    </form>
                  </motion.div>
                )}

                {/* 3. REGISTER STEP */}
                {step === 'register' && (
                  <motion.div key="register" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
                    <div className="flex items-center gap-4 mb-6">
                      <div className="w-12 h-12 bg-teal-50 text-teal-600 rounded-xl flex items-center justify-center">
                        <UserPlus size={24} />
                      </div>
                      <div>
                        <h2 className="text-xl font-black text-slate-800 leading-tight">Complete Profile</h2>
                        <p className="text-sm text-slate-500">Just a few more details for +91 {mobileInput}</p>
                      </div>
                    </div>

                    <form onSubmit={handleRegisterSubmit} className="space-y-4">
                      <div className="max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="md:col-span-2">
                            <label className="text-[10px] uppercase font-bold text-slate-400 ml-1 mb-1 block">Email Address</label>
                            <input placeholder="email@example.com" className={inputClass(errors.email)} value={form.email}
                              onChange={e => setForm({...form, email: e.target.value})} />
                          </div>
                          <div>
                            <label className="text-[10px] uppercase font-bold text-slate-400 ml-1 mb-1 block">First Name</label>
                            <input placeholder="John" className={inputClass(errors.firstName)} value={form.firstName}
                              onChange={e => setForm({...form, firstName: e.target.value})} />
                          </div>
                          <div>
                            <label className="text-[10px] uppercase font-bold text-slate-400 ml-1 mb-1 block">Last Name</label>
                            <input placeholder="Doe" className={inputClass(errors.lastName)} value={form.lastName}
                              onChange={e => setForm({...form, lastName: e.target.value})} />
                          </div>
                          <div className="md:col-span-2 mt-2 border-t border-slate-100 pt-4">
                             <p className="text-xs font-bold text-slate-800 mb-3 flex items-center gap-2"><MapPin size={14} className="text-teal-500" /> Address Details</p>
                          </div>
                          <div className="grid grid-cols-3 gap-2 md:col-span-2">
                            <input placeholder="St No" className={`${inputClass(errors.streetNo)} col-span-1`} value={form.streetNo}
                              onChange={e => setForm({...form, streetNo: e.target.value})} />
                            <input placeholder="Street Name" className={`${inputClass(errors.streetName)} col-span-2`} value={form.streetName}
                              onChange={e => setForm({...form, streetName: e.target.value})} />
                          </div>
                          <input placeholder="City" className={inputClass(errors.city)} value={form.city}
                            onChange={e => setForm({...form, city: e.target.value})} />
                          <input placeholder="State" className={inputClass(errors.state)} value={form.state}
                            onChange={e => setForm({...form, state: e.target.value})} />
                          <input placeholder="Postcode" className={inputClass(errors.postcode)} value={form.postcode}
                            onChange={e => setForm({...form, postcode: e.target.value})} />
                          <input placeholder="Country" className={inputClass(errors.country)} value={form.country}
                            onChange={e => setForm({...form, country: e.target.value})} />
                        </div>
                      </div>

                      <button disabled={isLoading} className={`${BUTTON_STYLE} mt-4`}>
                        {isLoading ? <Loader2 className="animate-spin" /> : 'Complete Registration'}
                      </button>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default LoginModal;