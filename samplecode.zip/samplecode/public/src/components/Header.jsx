import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, LogIn, LogOut, Globe, MapPin, Search, ShoppingBag } from 'lucide-react'; 

// Base items always visible
const BASE_NAV_ITEMS = [
  { name: 'Home', path: '/' },
  { name: 'Prepaid', path: '/recharge' },
  { name: 'Postpaid', path: '/postpaid' },
  { name: 'Fiber', path: '/fiber' },
  { name: 'Entertainment', path: '/entertainment' },
  { name: 'Devices', path: '/device' },
  { name: 'Bundles', path: '/bundle' },
];

// LOGIC UPDATE: Now accepting props from parent (App.js)
const Header = ({ isLoggedIn, mobileNumber, onShowLogin, onLogout }) => {
  const navigate = useNavigate();
  const location = useLocation();

  // --- UI States (Kept from original) ---
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [locationInput, setLocationInput] = useState('');

  // --- Scroll Effect ---
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // --- LOGIC UPDATE: Handle Search with navigation ---
  const handleSearch = () => {
    if (!locationInput.trim()) return;
    const targetRoute = location.pathname.includes('postpaid') ? '/postpaid' : 
                        location.pathname.includes('recharge') ? '/recharge' : location.pathname;
    navigate(`${targetRoute}?location=${encodeURIComponent(locationInput.trim())}`);
  };

  // Logic: Combine base items with Orders if logged in
  const currentNavItems = isLoggedIn 
    ? [...BASE_NAV_ITEMS, { name: 'Orders', path: '/orders' }, { name: 'Support', path: '/support' }]
    : [...BASE_NAV_ITEMS, { name: 'Support', path: '/support' }];

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 font-poppins ${
          scrolled 
            ? 'bg-white/95 backdrop-blur-md shadow-lg py-3' 
            : 'bg-gradient-to-r from-teal-700 via-cyan-600 to-blue-700 py-4'
        }`}
      >
        <div className="max-w-[1440px] mx-auto flex items-center justify-between px-6 gap-4">
          
          {/* LOGO */}
          <Link to="/" className="flex items-center gap-2 shrink-0 group">
            <motion.div 
              whileHover={{ rotate: 360 }}
              className={`p-1.5 rounded-lg transition-colors ${scrolled ? 'bg-teal-600 text-white' : 'bg-white text-teal-700'}`}
            >
              <Globe size={22} />
            </motion.div>
            <span className={`text-xl font-black tracking-tighter transition-colors ${scrolled ? 'text-slate-800' : 'text-white'}`}>
              My<span className={scrolled ? 'text-teal-600' : 'text-cyan-200'}>Telco</span>
            </span>
          </Link>

          {/* DESKTOP NAV */}
          <nav className="hidden xl:flex items-center gap-5">
            {currentNavItems.map((item) => {
              const active = location.pathname === item.path;
              return (
                <Link 
                  key={item.name}
                  to={item.path}
                  className={`relative text-[11px] uppercase tracking-wider font-bold transition-all ${
                    scrolled 
                      ? (active ? 'text-teal-600' : 'text-slate-500 hover:text-teal-500') 
                      : (active ? 'text-cyan-200' : 'text-white/80 hover:text-white')
                  }`}
                >
                  {item.name}
                  {active && (
                    <motion.div 
                      layoutId="navUnderline"
                      className={`absolute -bottom-1 left-0 right-0 h-0.5 ${scrolled ? 'bg-teal-600' : 'bg-cyan-300'}`}
                    />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* LOCATION SEARCH */}
          <div className="hidden lg:flex items-center flex-1 max-w-xs mx-4">
            <div className={`flex items-center w-full rounded-full px-3 py-1.5 border transition-all duration-300 ${
              scrolled 
                ? 'bg-slate-100 border-slate-200 focus-within:bg-white focus-within:ring-4 focus-within:ring-teal-500/10' 
                : 'bg-white/10 border-white/20 focus-within:bg-white/20'
            }`}>
              <MapPin size={14} className={scrolled ? 'text-slate-400' : 'text-white/60'} />
              <input
                type="text"
                value={locationInput}
                onChange={(e) => setLocationInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Search state..."
                className={`bg-transparent text-xs w-full px-2 focus:outline-none font-medium ${
                  scrolled ? 'text-slate-800 placeholder-slate-400' : 'text-white placeholder-white/40'
                }`}
              />
              <button onClick={handleSearch} className={`p-1 rounded-full ${scrolled ? 'text-teal-600 hover:bg-teal-50' : 'text-cyan-300 hover:bg-white/10'}`}>
                <Search size={14} />
              </button>
            </div>
          </div>

          {/* ACTIONS */}
          <div className="flex items-center gap-3 shrink-0">
            {isLoggedIn ? (
              <div className="flex items-center gap-3">
                <div className="hidden md:flex flex-col items-end leading-none mr-1">
                   <span className={`text-[10px] font-bold uppercase opacity-60 ${scrolled ? 'text-slate-500' : 'text-white'}`}>Active Acc</span>
                   <span className={`text-xs font-black ${scrolled ? 'text-teal-600' : 'text-cyan-300'}`}>
                     ***{mobileNumber ? mobileNumber.slice(-4) : '0000'}
                   </span>
                </div>
                <motion.button 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={onLogout} // LOGIC UPDATE: Use prop function
                  className="px-4 py-2 text-[11px] font-bold text-white bg-rose-500 rounded-full shadow-lg hover:bg-rose-600 flex items-center gap-2"
                >
                  <LogOut size={14} /> <span className="hidden sm:inline">Logout</span>
                </motion.button>
              </div>
            ) : (
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onShowLogin} // LOGIC UPDATE: Use prop function
                className={`px-5 py-2.5 text-xs font-bold rounded-full shadow-xl flex items-center gap-2 transition-all ${
                  scrolled ? 'bg-teal-600 text-white hover:bg-teal-700' : 'bg-white text-teal-700 hover:bg-slate-50'
                }`}
              >
                <LogIn size={16} /> Login
              </motion.button>
            )}

            <button onClick={() => setMobileOpen(true)} className="xl:hidden p-2 hover:bg-black/5 rounded-lg">
              <Menu size={24} className={scrolled ? 'text-slate-800' : 'text-white'} />
            </button>
          </div>
        </div>
      </motion.header>

      {/* MOBILE MENU (UI Kept exactly as original) */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMobileOpen(false)} className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60]" />
            <motion.aside initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} className="fixed top-0 right-0 h-full w-80 z-[70] bg-white p-8 shadow-2xl flex flex-col">
              <div className="flex justify-between items-center mb-10">
                <div className="text-xl font-black text-teal-600">Menu</div>
                <button onClick={() => setMobileOpen(false)} className="p-2 bg-slate-100 rounded-full text-slate-500">
                  <X size={20} />
                </button>
              </div>

              <div className="flex flex-col gap-1">
                {currentNavItems.map((item) => (
                  <Link key={item.name} to={item.path} onClick={() => setMobileOpen(false)} className="flex items-center justify-between py-4 border-b border-slate-50 text-sm font-bold text-slate-700">
                    {item.name}
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-200" />
                  </Link>
                ))}
              </div>

              {isLoggedIn && (
                <div className="mt-auto p-4 bg-teal-50 rounded-2xl flex items-center gap-3">
                   <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-teal-600 shadow-sm">
                      <ShoppingBag size={18} />
                   </div>
                   <div>
                      <p className="text-[10px] font-bold text-teal-800/50 uppercase">My Account</p>
                      <p className="text-sm font-black text-teal-900">
                        ***{mobileNumber ? mobileNumber.slice(-4) : '0000'}
                      </p>
                   </div>
                </div>
              )}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default Header;