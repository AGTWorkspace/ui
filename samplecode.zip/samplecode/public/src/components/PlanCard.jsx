import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';

const PlanCard = ({ plan, index }) => {
    const navigate = useNavigate();
    const isPostpaid = plan.type === 'postpaid';
    
    // --- ✅ Updated Navigation Logic with Auth Check ---
    const handleChoosePlan = () => {
        const user = JSON.parse(sessionStorage.getItem("mytelco_user"));

        // 🔐 Logic from second snippet: Check if logged in
        if (!user?.isLoggedIn) {
            navigate("/login-required", {
                state: {
                    plan,
                    redirectTo: "/confirm-order"
                }
            });
            return;
        }

        // ✅ If logged in: Proceed to confirmation
        navigate('/confirm-order', { state: { plan } });
    };

    // --- Tailwind Theme Mapping (Kept exactly as original) ---
    const PRIMARY_TEAL = 'text-teal-600';
    const BORDER_TEAL = 'border-teal-500';
    const ACCENT_CYAN = 'text-cyan-500';
    const DANGER_RED = 'text-red-600';
    const SHADOW_TEAL = 'shadow-teal-500/30';

    const getPlanClasses = () => {
        if (plan.title?.toLowerCase().includes('redx')) {
            return {
                borderColor: 'border-red-500',
                titleColor: DANGER_RED,
                detailColor: DANGER_RED,
                buttonClass: 'bg-red-600 hover:bg-red-700 shadow-red-200',
                shadowColor: 'shadow-red-500/30',
                bgTint: 'bg-red-50/50'
            };
        }
        return {
            borderColor: BORDER_TEAL,
            titleColor: PRIMARY_TEAL,
            detailColor: PRIMARY_TEAL,
            buttonClass: 'bg-teal-600 hover:bg-teal-700 shadow-teal-200',
            shadowColor: SHADOW_TEAL,
            bgTint: 'bg-teal-50/50'
        };
    };

    const theme = getPlanClasses();

    // Entrance Animation Settings
    const itemVariants = {
        hidden: { opacity: 0, y: 30 },
        visible: { 
            opacity: 1, 
            y: 0, 
            transition: { type: 'spring', stiffness: 100, delay: index * 0.1 } 
        },
    };

    return (
        <motion.div 
            variants={itemVariants}
            initial="hidden"
            animate="visible"
            whileHover={{ y: -10, boxShadow: `0 20px 25px -5px ${theme.shadowColor}` }}
            className={`relative p-8 bg-white rounded-3xl shadow-xl border-t-8 ${theme.borderColor} 
                        font-poppins flex flex-col h-full transition-shadow duration-300`}
        >
            {/* Badge */}
            {plan.badge && (
                <span className={`absolute top-0 right-0 px-4 py-1.5 text-[10px] font-black text-white uppercase rounded-bl-2xl 
                                ${plan.title.toLowerCase().includes('redx') ? 'bg-red-600' : 'bg-cyan-500'}`}>
                    {plan.badge}
                </span>
            )}
            
            {/* Title */}
            <h3 className={`mb-4 text-2xl font-black ${theme.titleColor} tracking-tight`}>
                {plan.title}
            </h3>

            {/* Price & Data Block */}
            <div className={`flex flex-col mb-6 p-5 border border-slate-100 rounded-2xl ${theme.bgTint} space-y-4`}>
                <div className="text-center pb-3 border-b border-slate-200/60">
                    <p className="text-[10px] uppercase font-bold text-slate-400 mb-1">Total Price</p>
                    <div className="flex items-center justify-center gap-1">
                        <span className={`text-2xl font-bold ${ACCENT_CYAN}`}>₹</span>
                        <strong className={`text-5xl font-black ${ACCENT_CYAN} tracking-tighter`}>
                            {plan.price.replace('₹', '')}
                        </strong>
                    </div>
                </div>
                
                <div className="flex justify-between items-center w-full">
                    <div className="text-center flex-1 border-r border-slate-200/60">
                        <strong className={`block text-2xl font-black ${theme.titleColor}`}>{plan.data}</strong>
                        <p className="text-slate-400 text-[10px] font-bold uppercase">{isPostpaid ? 'Data/mo' : 'Data/day'}</p>
                    </div>
                    
                    <div className="text-center flex-1">
                        <strong className={`block text-2xl font-black ${theme.titleColor}`}>{plan.validity}</strong>
                        <p className="text-slate-400 text-[10px] font-bold uppercase">Validity</p>
                    </div>
                </div>
            </div>

            {/* Action Button */}
            <button 
                onClick={handleChoosePlan}
                className={`w-full py-4 font-bold text-white rounded-2xl transition-all active:scale-95 shadow-lg
                            ${theme.buttonClass}`} 
            >
                {plan.buttonText || (isPostpaid ? 'Get Connection' : 'Recharge Now')}
            </button>
            
            {/* Details Section */}
            <details className="mt-6 group">
                <summary className={`flex justify-between items-center cursor-pointer font-bold text-xs uppercase tracking-widest ${theme.detailColor} opacity-70 hover:opacity-100 transition-opacity`}>
                    View Benefits
                    <span className="text-lg group-open:rotate-180 transition-transform">+</span>
                </summary>
                
                <div className="pt-4 space-y-3">
                    {plan.details?.map((detail, dIdx) => (
                        <div key={dIdx} className="flex items-start gap-3 text-sm text-slate-600">
                            <CheckCircle size={16} className={`shrink-0 mt-0.5 ${theme.titleColor}`} />
                            <p className="leading-tight">{detail}</p>
                        </div>
                    ))}
                </div>
            </details>
        </motion.div>
    );
};

export default PlanCard;