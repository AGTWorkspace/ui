import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, Send, RefreshCw, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// --- Theme Constants (Premium Teal/Cyan) ---
const PRIMARY_GRADIENT = 'bg-gradient-to-r from-teal-600 to-cyan-500';
const PRIMARY_TEAL = 'bg-teal-600 hover:bg-teal-700';
const USER_MESSAGE_BG = 'bg-teal-600';
const TICK_COLOR = 'text-cyan-400';

// --- Framer Motion Variants ---
const messageVariants = {
    initial: { opacity: 0, y: 20, scale: 0.95 },
    animate: { opacity: 1, y: 0, scale: 1, transition: { type: 'spring', stiffness: 200, damping: 25 } },
};

const chatBoxVariants = {
    closed: { scale: 0.8, opacity: 0, y: 50, transition: { type: 'spring', stiffness: 300, damping: 30 } },
    open: { scale: 1, opacity: 1, y: 0, transition: { type: 'spring', stiffness: 100, damping: 15 } }
};

/* --- Sub-Components: Message Bubbles --- */

const BotMessage = ({ text, onLoginClick }) => {
    // Logic from secondary code: Handle login required state
    if (text === "__LOGIN_REQUIRED__") {
        return (
            <motion.div className="flex flex-col items-start space-y-1" variants={messageVariants} initial="initial" animate="animate">
                <div className="max-w-[86%] bg-white p-4 rounded-2xl rounded-tl-none border border-gray-200 text-gray-900 shadow-sm">
                    <button 
                        onClick={onLoginClick}
                        className="text-teal-600 font-bold hover:underline flex items-center gap-2 text-sm"
                    >
                        🔒 Login required — Click here
                    </button>
                </div>
                <div className="text-[10px] text-gray-400 ml-1 uppercase font-bold tracking-wider">Bot • Now</div>
            </motion.div>
        );
    }

    return (
        <motion.div className="flex flex-col items-start space-y-1" variants={messageVariants} initial="initial" animate="animate">
            <div className="max-w-[86%] bg-white p-4 rounded-2xl rounded-tl-none border border-gray-200 text-gray-900 shadow-sm">
                <p className="m-0 leading-relaxed text-sm whitespace-pre-wrap">{text}</p>
            </div>
            <div className="text-[10px] text-gray-400 ml-1 uppercase font-bold tracking-wider">Bot • {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
        </motion.div>
    );
};

const UserMessage = ({ text }) => (
    <motion.div className="flex flex-col items-end space-y-1" variants={messageVariants} initial="initial" animate="animate">
        <div className={`max-w-[86%] ${USER_MESSAGE_BG} text-white p-3 rounded-2xl rounded-tr-none shadow-md break-words whitespace-pre-wrap`}>
            <p className="text-sm">{text}</p>
        </div>
        <div className="flex items-center gap-2 text-xs">
            <div className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">You</div>
            <svg className={`w-4 h-4 ${TICK_COLOR}`} viewBox="0 0 24 24" fill="currentColor">
                <path d="M1.6 13.2l1.4-1.4 4.3 4.3-1.4 1.4z" /><path d="M6.2 13.2l1.4-1.4 4.3 4.3-1.4 1.4z" />
            </svg>
        </div>
    </motion.div>
);

/* --- Main Component --- */

const ChatbotWidget = ({ messages, addMessage, setMessages, onLoginClick, isLoggedIn }) => {
    const navigate = useNavigate();
    const [isOpen, setIsOpen] = useState(false);
    const [showTooltip, setShowTooltip] = useState(true);
    const [userInput, setUserInput] = useState('');
    const textareaRef = useRef(null);
    const messagesEndRef = useRef(null);

    // Auto-scroll logic
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages]);

    // Tooltip timeout
    useEffect(() => {
        const timer = setTimeout(() => setShowTooltip(false), 5000);
        return () => clearTimeout(timer);
    }, []);

    // Global Event Listener (for external messages)
    useEffect(() => {
        const handler = (event) => {
            const { sender = "user", text } = event.detail;
            addMessage({ sender, text });
        };
        window.addEventListener("chatbot:add-message", handler);
        return () => window.removeEventListener("chatbot:add-message", handler);
    }, [addMessage]);

    const handleSendMessage = () => {
        const text = userInput.trim();
        if (!text) return;

        // 1. Add User Message
        addMessage({ sender: "user", text });
        setUserInput('');
        if (textareaRef.current) textareaRef.current.style.height = 'auto';

        // 2. Logic Check: Login Required?
        if (!isLoggedIn) {
            setTimeout(() => {
                addMessage({ sender: "bot", text: "__LOGIN_REQUIRED__" });
            }, 400);
            return;
        }

        // 3. Logic Check: Plans keyword
        if (text.toLowerCase().includes("plan")) {
            setTimeout(() => {
                addMessage({ sender: "bot", text: "Excellent choice! Opening the Plan Assistant now... 🚀" });
                
                setTimeout(() => {
                    navigate("/chatbot-assistant");
                }, 1000);
            }, 600);
        } else {
            setTimeout(() => {
                addMessage({ sender: "bot", text: "I'm here to help! Please type 'plans' to see our latest mobile, fiber, and device offers." });
            }, 800);
        }
    };

    const handleRestart = () => {
        setMessages([{ id: Date.now(), text: "Chat restarted. Type 'plans' to start over.", sender: 'bot' }]);
    };

    return (
        <>
            <AnimatePresence>
                {isOpen && (
                    <motion.div 
                        variants={chatBoxVariants} initial="closed" animate="open" exit="closed" 
                        className="fixed bottom-28 right-8 w-80 md:w-96 h-[560px] bg-white rounded-[2rem] shadow-2xl border border-gray-200 flex flex-col overflow-hidden z-[999]"
                    >
                        {/* Header */}
                        <div className={`${PRIMARY_GRADIENT} text-white p-5 flex items-center justify-between shadow-md`}>
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                                    <MessageSquare size={18} />
                                </div>
                                <h2 className="text-sm font-black uppercase tracking-widest">MyTelco Bot</h2>
                            </div>
                            <motion.button onClick={() => setIsOpen(false)} whileHover={{ scale: 1.1, rotate: 90 }} whileTap={{ scale: 0.9 }}>
                                <X size={20} />
                            </motion.button>
                        </div>

                        {/* Messages Container */}
                        <div className="flex-1 overflow-y-auto px-5 py-6 space-y-6 bg-slate-50">
                            {messages.map((msg, idx) => (
                                msg.sender === 'bot' 
                                    ? <BotMessage key={idx} text={msg.text} onLoginClick={onLoginClick} /> 
                                    : <UserMessage key={idx} text={msg.text} />
                            ))}
                            <div ref={messagesEndRef} />
                        </div>

                        {/* Input Area */}
                        <div className="p-4 bg-white border-t border-gray-100">
                            <div className="flex items-end gap-3">
                                <textarea 
                                    ref={textareaRef} rows="1" placeholder="Type 'plans'..." 
                                    className={`flex-1 px-4 py-3 rounded-2xl border-none bg-gray-100 focus:ring-2 focus:ring-teal-500 text-sm resize-none max-h-28 transition-all`}
                                    value={userInput} 
                                    onChange={(e) => {
                                        setUserInput(e.target.value);
                                        e.target.style.height = 'auto';
                                        e.target.style.height = e.target.scrollHeight + 'px';
                                    }}
                                    onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSendMessage())}
                                />
                                <div className="flex flex-col gap-2">
                                    <motion.button 
                                        onClick={handleRestart} whileTap={{ scale: 0.9 }}
                                        className="p-2 text-gray-400 hover:text-teal-600 transition-colors"
                                    >
                                        <RefreshCw size={18} />
                                    </motion.button>
                                    <motion.button 
                                        onClick={handleSendMessage} disabled={!userInput.trim()} whileTap={{ scale: 0.8 }}
                                        className={`w-12 h-12 flex items-center justify-center text-white rounded-2xl shadow-lg transition-all ${userInput.trim() ? PRIMARY_TEAL : 'bg-gray-300 cursor-not-allowed'}`}
                                    >
                                        <Send size={20} />
                                    </motion.button>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Floating Trigger Button */}
            <div className="fixed bottom-8 right-8 flex flex-col items-center space-y-2 z-[1000]">
                <AnimatePresence>
                    {showTooltip && !isOpen && (
                        <motion.div 
                            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                            className="bg-gray-900 text-white text-[10px] font-bold uppercase tracking-widest px-4 py-2 rounded-full shadow-xl"
                        >
                            Need help finding a plan?
                        </motion.div>
                    )}
                </AnimatePresence>
                
                <motion.div 
                    className={`w-16 h-16 rounded-[1.5rem] ${PRIMARY_GRADIENT} shadow-xl shadow-teal-500/30 text-white flex items-center justify-center cursor-pointer`}
                    onClick={() => { setIsOpen(!isOpen); setShowTooltip(false); }}
                    whileHover={{ scale: 1.05, rotate: 5 }} whileTap={{ scale: 0.95 }}
                >
                    <MessageSquare size={30} />
                </motion.div>
            </div>
        </>
    );
};

export default ChatbotWidget;