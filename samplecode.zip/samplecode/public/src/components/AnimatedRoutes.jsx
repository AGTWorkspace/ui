import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';

// --- Page Imports ---
import HomePage from '../pages/HomePage';
import RechargePlans from '../pages/RechargePlans';
import PostpaidPlans from '../pages/PostpaidPlans';
import FiberNet from '../pages/FiberNet';
import Entertainment from '../pages/Entertainment';
import Device from '../pages/Device';
import Bundle from '../pages/Bundle';
import Support from '../pages/Support';
import ConfirmOrder from '../pages/ConfirmOrder';
import OrderSuccess from '../pages/OrderSuccess';
import Orders from '../pages/Orders';
import ChatbotAssistant from '../pages/ChatbotAssistant';
import LoginRequired from '../pages/LoginRequired'; // ✅ Integrated
import NotFound from '../pages/NotFound';

const pageVariants = {
  initial: { opacity: 0, y: 15 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -15 },
};

const AnimatedPage = ({ children }) => (
  <motion.div
    variants={pageVariants}
    initial="initial"
    animate="animate"
    exit="exit"
    transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    className="h-full"
  >
    {children}
  </motion.div>
);

// Accept logic props from App.jsx
const AnimatedRoutes = ({ addMessage, isLoggedIn }) => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<AnimatedPage><HomePage /></AnimatedPage>} />
        <Route path="/recharge" element={<AnimatedPage><RechargePlans /></AnimatedPage>} />
        <Route path="/postpaid" element={<AnimatedPage><PostpaidPlans /></AnimatedPage>} />
        <Route path="/fiber" element={<AnimatedPage><FiberNet /></AnimatedPage>} />
        <Route path="/entertainment" element={<AnimatedPage><Entertainment /></AnimatedPage>} />
        <Route path="/device" element={<AnimatedPage><Device /></AnimatedPage>} />
        <Route path="/bundle" element={<AnimatedPage><Bundle /></AnimatedPage>} />
        <Route path="/support" element={<AnimatedPage><Support /></AnimatedPage>} />

        <Route 
          path="/chatbot-assistant" 
          element={<AnimatedPage><ChatbotAssistant addMessage={addMessage} isLoggedIn={isLoggedIn} /></AnimatedPage>} 
        />

        <Route path="/login-required" element={<AnimatedPage><LoginRequired /></AnimatedPage>} />

        <Route 
          path="/confirm-order" 
          element={<AnimatedPage><ConfirmOrder addMessage={addMessage} /></AnimatedPage>} 
        />
        
        <Route path="/order-success" element={<AnimatedPage><OrderSuccess /></AnimatedPage>} />
        <Route path="/orders" element={<AnimatedPage><Orders /></AnimatedPage>} />
        <Route path="*" element={<AnimatedPage><NotFound /></AnimatedPage>} />
      </Routes>
    </AnimatePresence>
  );
};

export default AnimatedRoutes;