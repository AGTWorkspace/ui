import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const ConfirmOrder = ({ addMessage }) => {
  const navigate = useNavigate();
  const { state } = useLocation();

  const plan = state?.plan;
  const price = Number(plan?.price.replace(/[^\d]/g, ''));
  const discount = plan?.discount ?? 50;
  const finalPrice = price - discount;

  // 🔒 Prevent direct access
  if (!plan) {
    return (
      <div className="min-h-screen flex items-center justify-center font-poppins bg-gray-50">
        <p className="text-gray-500 text-lg">
          No plan selected. Please choose a plan first.
        </p>
      </div>
    );
  }

  const handleConfirm = () => {
    // ✅ Send messages via addMessage
    addMessage({
      sender: 'user',
      text: `✔ Order Confirmed\n• Plan: ${plan.title}\n• Price: ₹${finalPrice}`,
    });

    addMessage({
      sender: 'bot',
      text: 'Your order has been successfully confirmed! 🎉',
    });

    // Navigate to order success page
    navigate('/order-success', {
      state: {
        plan,
        price,
        discount,
        finalPrice,
      },
    });
  };

  return (
    <section className="min-h-screen px-5 py-12 md:px-[5%] bg-gray-50 font-poppins">
      <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl p-8">
        <h1 className="text-3xl font-bold text-primary mb-8 text-center">
          Order Summary
        </h1>

        <div className="mb-8 p-6 rounded-xl bg-blue-50/60 border border-blue-100">
          <h2 className="text-xl font-bold text-primary mb-1">{plan.title}</h2>
          <p className="text-gray-600 text-sm">
            {plan.data} • {plan.validity}
          </p>
        </div>

        <div className="space-y-4 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Plan Price</span>
            <span className="font-semibold">₹{price}</span>
          </div>

          <div className="flex justify-between text-green-600">
            <span>Discount</span>
            <span>- ₹{discount}</span>
          </div>

          <hr className="my-2" />

          <div className="flex justify-between text-lg font-bold">
            <span>Total Payable</span>
            <span className="text-primary">₹{finalPrice}</span>
          </div>
        </div>

        <button
          type="button"
          onClick={handleConfirm}
          className="mt-10 w-full py-4 text-white font-semibold rounded-full shadow-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:opacity-90 transition"
        >
          Confirm & Pay ₹{finalPrice}
        </button>

        <button
          onClick={() => navigate(-1)}
          className="mt-4 w-full text-sm text-gray-500 hover:text-primary transition"
        >
          ← Go Back
        </button>
      </div>
    </section>
  );
};

export default ConfirmOrder;
