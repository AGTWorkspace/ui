import React from 'react';
import { useSearchParams } from 'react-router-dom';
import plansData from '../data/plansData.json';
import PlanList from '../components/PlanList';

const RechargePlans = () => {
  const [searchParams] = useSearchParams();
  const location = searchParams.get('location');

  const prepaidPlans = plansData.filter(plan =>
    plan.category === 'pre-paid' &&
    (!location || plan.locations?.includes(location))
  );

  return (
    <section className="min-h-screen px-5 py-12 md:px-[5%] font-poppins bg-gray-50">
      <h1 className="mb-4 text-4xl font-bold text-center text-primary">
        Prepaid Recharge Plans
      </h1>

      {location && (
        <p className="mb-8 text-center text-gray-600">
          Showing plans available in <span className="font-semibold">{location}</span>
        </p>
      )}

      {prepaidPlans.length > 0 ? (
        <div className="max-w-7xl mx-auto">
          <PlanList items={prepaidPlans} />
        </div>
      ) : (
        <p className="mt-16 text-center text-gray-500">
          No prepaid plans available for this location.
        </p>
      )}
    </section>
  );
};

export default RechargePlans;
