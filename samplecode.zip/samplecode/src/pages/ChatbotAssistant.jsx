// src/pages/ChatbotAssistant.jsx
import React, { useState } from "react";
import CategorySelector from "../components/chatbot/CategorySelector";
import PlanSelector from "../components/chatbot/PlanSelector";
import plansData from "../data/plansData.json";
import { useNavigate } from "react-router-dom";

const ChatbotAssistant = ({ addMessage, isLoggedIn }) => {
  const navigate = useNavigate();

  const [step, setStep] = useState("categories");
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedPlan, setSelectedPlan] = useState(null);

  /* 🔐 LOGIN REQUIRED UI */
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white p-10 rounded-2xl shadow-xl border text-center max-w-md">
          <h2 className="text-2xl font-bold mb-4 text-red-600">
            🔒 Login Required
          </h2>
          <p className="text-gray-600 mb-6">
            Please login to continue chatting and explore plans.
          </p>
          <button
            onClick={() => navigate("/")}
            className="px-6 py-3 rounded-full bg-blue-600 text-white font-semibold hover:bg-blue-700"
          >
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  /* CATEGORY SUBMIT */
  const handleCategorySubmit = () => {
    setStep("plans");
  };

  /* CONFIRM & PAY */
  const handleConfirmPay = () => {
    addMessage({
      sender: "user",
      text: "✅ Order Confirmed and Paid"
    });

    addMessage({
      sender: "bot",
      text: "Thank you 🎉 Your payment is successful and order is confirmed."
    });

    navigate("/order-success", { state: { plan: selectedPlan } });
  };

  return (
    /* ✅ RIGHT PADDING ADDED ONLY FOR THIS PAGE */
    <div className="min-h-screen bg-gray-50 px-10 py-8 pr-[420px]">
      <h1 className="text-3xl font-bold mb-6">
        Choose the best plan for you
      </h1>

      {step === "categories" && (
        <CategorySelector
          selected={selectedCategories}
          setSelected={setSelectedCategories}
          onSubmit={handleCategorySubmit}
          addMessage={addMessage}
        />
      )}

      {step === "plans" && (
        <PlanSelector
          categories={selectedCategories}
          plansData={plansData}
          setSelectedPlan={setSelectedPlan}
          addMessage={addMessage}
        />
      )}

      {step === "confirm" && (
        <div className="bg-white p-6 rounded-xl shadow border text-center">
          <h3 className="text-xl font-semibold mb-4">Confirm & Pay</h3>
          <p className="mb-6 text-gray-600">
            You selected: <strong>{selectedPlan?.title}</strong>
          </p>
          <button
            onClick={handleConfirmPay}
            className="px-6 py-3 rounded-full bg-green-600 text-white font-semibold hover:bg-green-700"
          >
            Confirm & Pay
          </button>
        </div>
      )}
    </div>
  );
};

export default ChatbotAssistant;
