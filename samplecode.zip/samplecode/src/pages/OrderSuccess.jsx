import React, { useEffect, useState } from 'react';
import { CheckCircle } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';

const OrderSuccess = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const plan = state?.plan;

  const [orderId, setOrderId] = useState('');

  useEffect(() => {
    if (!plan) return;

    const basePrice = Number(plan.price.replace(/[^\d]/g, ''));
    const generatedOrderId = `ORD-${Date.now()}`;

    setOrderId(generatedOrderId);

    const newOrder = {
      orderId: generatedOrderId,
      state: 'Confirmed',
      description: `${plan.title} Plan Purchase`,
      customerId: `CUST-${Math.floor(100000 + Math.random() * 900000)}`,
      productDetails: `${plan.title} • ${plan.data} • ${plan.validity}`,
      orderDate: new Date().toLocaleDateString(),
      paymentDueDate: new Date(Date.now() + 7 * 86400000).toLocaleDateString(),
      basePrice,
      discount_id: 'DISC50',
      discount_pct: 50,
      finalPrice: basePrice - 50
    };

    const existingOrders =
      JSON.parse(localStorage.getItem('orders')) || [];

    const alreadyExists = existingOrders.some(
      (o) =>
        o.description === newOrder.description &&
        o.finalPrice === newOrder.finalPrice &&
        o.orderDate === newOrder.orderDate
    );

    if (!alreadyExists) {
      localStorage.setItem(
        'orders',
        JSON.stringify([newOrder, ...existingOrders])
      );
    }
  }, [plan]);

  if (!plan) {
    return (
      <div className="min-h-screen flex items-center justify-center font-poppins">
        <p className="text-gray-500">No order found.</p>
      </div>
    );
  }

  return (
    <section className="min-h-screen flex items-center justify-center px-5 bg-gray-50 font-poppins">
      <div className="max-w-lg w-full bg-white rounded-2xl shadow-2xl p-10 text-center animate-fadeIn">

        {/* Success Icon */}
        <div className="flex justify-center mb-6">
          <CheckCircle className="w-20 h-20 text-green-600" />
        </div>

        {/* Title */}
        <h1 className="text-4xl font-extrabold text-primary mb-3">
          Order Successful 🎉
        </h1>

        {/* Message */}
        <p className="text-gray-600 mb-8">
          Your plan has been successfully activated.
          A confirmation SMS will be sent to your registered mobile number.
        </p>

        {/* Order Summary */}
        <div className="bg-blue-50/60 rounded-xl p-6 text-left shadow-inner mb-8">
          <h3 className="text-lg font-bold text-primary mb-4">
            Order Summary
          </h3>

          <div className="flex justify-between mb-2 text-gray-700">
            <span>Plan</span>
            <span className="font-semibold">{plan.title}</span>
          </div>

          <div className="flex justify-between mb-2 text-gray-700">
            <span>Payment Status</span>
            <span className="font-semibold text-green-600">Paid</span>
          </div>

          <div className="flex justify-between text-gray-700">
            <span>Order ID</span>
            <span className="font-mono font-semibold">
              #{orderId}
            </span>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={() => navigate('/')}
            style={{ backgroundColor: '#2563eb' }} // solid blue
            className="flex-1 py-3 rounded-full text-white font-semibold
                       shadow-lg hover:opacity-90 transition"
          >
            Go to Home
          </button>

          <button
            onClick={() => navigate('/orders')}
            style={{ backgroundColor: '#16a34a' }} // solid green
            className="flex-1 py-3 rounded-full text-white font-semibold
                       shadow-lg hover:opacity-90 transition"
          >
            View My Orders
          </button>
        </div>

      </div>
    </section>
  );
};

export default OrderSuccess;
