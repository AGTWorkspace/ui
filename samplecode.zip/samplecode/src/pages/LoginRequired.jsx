import React from "react";
import { useNavigate, useLocation } from "react-router-dom";

const LoginRequired = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogin = () => {
    navigate("/", {
      state: { openLogin: true, redirectTo: location.state?.redirectTo }
    });
  };

  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
      <h1 className="text-3xl font-bold text-primary mb-4">
        Login Required 🔐
      </h1>
      <p className="text-gray-600 mb-6">
        Please login to continue with your plan purchase.
      </p>

      <button
        onClick={handleLogin}
        className="px-8 py-3 bg-primary text-white rounded-full font-semibold hover:opacity-90"
      >
        Login Now
      </button>
    </div>
  );
};

export default LoginRequired;
