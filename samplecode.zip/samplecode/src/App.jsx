// src/App.jsx
import React, { useState, useEffect } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  useNavigate
} from "react-router-dom";

import Header from "./components/Header";
import Footer from "./components/Footer";
import LoginModal from "./components/LoginModal";
import ChatbotWidget from "./components/ChatbotWidget";

/* PAGES */
import HomePage from "./pages/HomePage";
import RechargePlans from "./pages/RechargePlans";
import PostpaidPlans from "./pages/PostpaidPlans";
import FiberNet from "./pages/FiberNet";
import Entertainment from "./pages/Entertainment";
import Device from "./pages/Device";
import Bundle from "./pages/Bundle";
import Support from "./pages/Support";

import ConfirmOrder from "./pages/ConfirmOrder";
import OrderSuccess from "./pages/OrderSuccess";
import Orders from "./pages/Orders";
import ChatbotAssistant from "./pages/ChatbotAssistant";
import LoginRequired from "./pages/LoginRequired";
import NotFound from "./pages/NotFound";

/* ---------------- WRAPPER ---------------- */
function AppWrapper() {
  return (
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
}

/* ---------------- MAIN APP ---------------- */
function App() {
  const navigate = useNavigate(); // ✅ REQUIRED

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [mobileNumber, setMobileNumber] = useState("");

  /* 🤖 CHATBOT STATE */
  const [messages, setMessages] = useState([
    { id: 1, sender: "bot", text: "Hi 👋 Type **plans** to explore our telecom plans." }
  ]);

  const addMessage = (msg) => {
    setMessages((prev) => [...prev, { id: Date.now(), ...msg }]);
  };

  /* 🔐 LOAD LOGIN FROM SESSION */
  useEffect(() => {
    const user = JSON.parse(sessionStorage.getItem("mytelco_user"));
    if (user?.isLoggedIn) {
      setIsLoggedIn(true);
      setMobileNumber(user.mobileNumber || "");
    }
  }, []);

  /* ✅ LOGIN → HOME */
  const handleLoginSuccess = (number) => {
    sessionStorage.setItem(
      "mytelco_user",
      JSON.stringify({ isLoggedIn: true, mobileNumber: number })
    );

    setIsLoggedIn(true);
    setMobileNumber(number);
    setIsModalOpen(false);

    addMessage({
      sender: "bot",
      text: "✅ Login successful! You can continue your plan purchase."
    });

    navigate("/"); // ✅ REDIRECT TO HOME
  };

  /* ✅ LOGOUT → HOME */
  const handleLogout = () => {
    sessionStorage.clear();
    setIsLoggedIn(false);
    setMobileNumber("");

    addMessage({
      sender: "bot",
      text: "👋 You have been logged out."
    });

    navigate("/"); // ✅ REDIRECT TO HOME
  };

  return (
    <div className="flex flex-col min-h-screen font-poppins">
      <Header
        onShowLogin={() => setIsModalOpen(true)}
        isLoggedIn={isLoggedIn}
        mobileNumber={mobileNumber}
        onLogout={handleLogout}
      />

      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/recharge" element={<RechargePlans />} />
          <Route path="/postpaid" element={<PostpaidPlans />} />
          <Route path="/fiber" element={<FiberNet />} />
          <Route path="/entertainment" element={<Entertainment />} />
          <Route path="/device" element={<Device />} />
          <Route path="/bundle" element={<Bundle />} />
          <Route path="/support" element={<Support />} />

          {/* 🤖 CHATBOT */}
          <Route
            path="/chatbot-assistant"
            element={
              <ChatbotAssistant
                addMessage={addMessage}
                isLoggedIn={isLoggedIn}
              />
            }
          />

          <Route path="/login-required" element={<LoginRequired />} />

          {/* 🧾 ORDER FLOW */}
          <Route path="/confirm-order" element={<ConfirmOrder addMessage={addMessage} />} />
          <Route path="/order-success" element={<OrderSuccess />} />
          <Route path="/orders" element={<Orders />} />

          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      <LoginModal
        isVisible={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      <Footer />

      <ChatbotWidget
        messages={messages}
        setMessages={setMessages}
        addMessage={addMessage}
        isLoggedIn={isLoggedIn}
        onLoginClick={() => setIsModalOpen(true)}
      />
    </div>
  );
}

export default AppWrapper;
