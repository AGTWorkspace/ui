import React, { useState, useEffect, useRef } from 'react';
import { X, CheckCircle } from 'lucide-react';

const PRIMARY_COLOR = '#007bff';

const LoginModal = ({ isVisible, onClose, onLoginSuccess }) => {
  const [step, setStep] = useState('mobile');
  const [mobileInput, setMobileInput] = useState('');
  const [otpInput, setOtpInput] = useState(Array(6).fill(''));
  const [otpError, setOtpError] = useState(false);
  const [timer, setTimer] = useState(60);

  const [form, setForm] = useState({
    email: '',
    firstName: '',
    lastName: '',
    streetNo: '',
    streetName: '',
    city: '',
    state: '',
    postcode: '',
    country: ''
  });

  const [errors, setErrors] = useState({});
  const otpRefs = useRef([]);

  /* ---------------- RESET ---------------- */
  useEffect(() => {
    if (!isVisible) {
      setStep('mobile');
      setMobileInput('');
      setOtpInput(Array(6).fill(''));
      setErrors({});
      setOtpError(false);
    }
  }, [isVisible]);

  /* ---------------- OTP TIMER ---------------- */
  useEffect(() => {
    if (step === 'otp') {
      setTimer(60);
      const interval = setInterval(() => {
        setTimer(t => (t > 0 ? t - 1 : 0));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [step]);

  /* ---------------- MOBILE ---------------- */
  const handleMobileSubmit = e => {
    e.preventDefault();
    /^\d{10}$/.test(mobileInput)
      ? setStep('otp')
      : alert('Enter a valid 10-digit mobile number');
  };

  /* ---------------- OTP ---------------- */
  const handleOtpVerify = e => {
    e.preventDefault();
    if (otpInput.join('') === '123456') {
      mobileInput.endsWith('0') ? setStep('register') : completeLogin();
    } else {
      setOtpError(true);
      setOtpInput(Array(6).fill(''));
      otpRefs.current[0]?.focus();
    }
  };

  /* ---------------- LOGIN COMPLETE ---------------- */
  const completeLogin = (profileData = null) => {
    const userData = {
      mobile: mobileInput,
      isLoggedIn: true,
      profile: profileData
    };

    localStorage.setItem('mytelco_user', JSON.stringify(userData));

    onLoginSuccess(mobileInput);
    onClose();
  };

  /* ---------------- REGISTRATION ---------------- */
  const validateForm = () => {
    const e = {};
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = 'Invalid email';
    if (form.firstName.length < 2) e.firstName = 'Min 2 chars';
    if (form.lastName.length < 2) e.lastName = 'Min 2 chars';
    if (!form.streetNo) e.streetNo = 'Required';
    if (!form.streetName) e.streetName = 'Required';
    if (!form.city) e.city = 'Required';
    if (!form.state) e.state = 'Required';
    if (!/^\d{4,8}$/.test(form.postcode)) e.postcode = 'Invalid';
    if (!form.country) e.country = 'Required';

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleRegisterSubmit = e => {
    e.preventDefault();
    if (validateForm()) {
      completeLogin(form);
    }
  };

  const inputClass = err =>
    `w-full p-3 rounded-lg border-2 text-sm transition
     ${err ? 'border-red-500' : 'border-gray-300'}
     focus:outline-none focus:border-primary focus:ring-2 focus:ring-blue-200`;

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 font-poppins">
      <div className="relative w-[92%] max-w-lg bg-white rounded-2xl shadow-2xl p-8 animate-swipeIn">

        {/* CLOSE */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-red-500 transition"
        >
          <X size={28} />
        </button>

        {/* MOBILE */}
        {step === 'mobile' && (
          <form onSubmit={handleMobileSubmit}>
            <h2 className="text-3xl font-bold text-primary mb-3">
              Login / Register
            </h2>
            <p className="text-gray-600 mb-6 text-sm">
              Enter your mobile number to continue
            </p>

            <div className="flex overflow-hidden border-2 border-gray-300 rounded-xl mb-6 focus-within:border-primary">
              <span className="px-4 py-3 bg-gray-100 font-semibold text-gray-700">
                +91
              </span>
              <input
                className="flex-1 p-3 outline-none text-sm"
                maxLength="10"
                placeholder="Enter mobile number"
                value={mobileInput}
                onChange={e => setMobileInput(e.target.value)}
              />
            </div>

            <button
              style={{ backgroundColor: PRIMARY_COLOR }}
              className="w-full py-3 rounded-full text-white font-semibold shadow-lg hover:opacity-90 transition"
            >
              Get OTP
            </button>
          </form>
        )}

        {/* OTP */}
        {step === 'otp' && (
          <form onSubmit={handleOtpVerify}>
            <p className="mb-6 text-green-600 flex items-center justify-center gap-2 font-semibold">
              <CheckCircle size={18} /> OTP sent to +91 {mobileInput}
            </p>

            <div className="flex gap-3 justify-center mb-5">
              {otpInput.map((d, i) => (
                <input
                  key={i}
                  maxLength="1"
                  className={`w-12 h-14 text-xl font-semibold text-center border-2 rounded-lg
                    ${otpError ? 'border-red-500' : 'border-gray-300'}
                    focus:border-primary focus:ring-2 focus:ring-blue-200 outline-none`}
                  value={d}
                  onChange={e => {
                    const v = e.target.value.slice(-1);
                    if (!/\d/.test(v)) return;
                    const o = [...otpInput];
                    o[i] = v;
                    setOtpInput(o);
                    otpRefs.current[i + 1]?.focus();
                  }}
                  ref={el => (otpRefs.current[i] = el)}
                />
              ))}
            </div>

            {otpError && (
              <p className="text-red-500 text-sm text-center mb-3">
                Invalid OTP. Try again.
              </p>
            )}

            <button
              style={{ backgroundColor: PRIMARY_COLOR }}
              className="w-full py-3 rounded-full text-white font-semibold shadow-lg hover:opacity-90 transition"
            >
              Verify OTP
            </button>

            <p className="text-center mt-4 text-sm text-gray-500">
              {timer > 0 ? `Resend OTP in ${timer}s` : 'Resend OTP'}
            </p>
          </form>
        )}

        {/* REGISTER */}
        {step === 'register' && (
          <form onSubmit={handleRegisterSubmit}>
            <h2 className="text-3xl font-bold text-primary mb-2">
              Complete Registration
            </h2>
            <p className="text-gray-600 mb-6 text-sm">
              We need a few more details to finish setup
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                ['email', 'Email'],
                ['firstName', 'First Name'],
                ['lastName', 'Last Name'],
                ['streetNo', 'Street No'],
                ['streetName', 'Street Name'],
                ['city', 'City'],
                ['state', 'State'],
                ['postcode', 'Postcode'],
                ['country', 'Country']
              ].map(([k, label]) => (
                <div key={k}>
                  <input
                    placeholder={label}
                    className={inputClass(errors[k])}
                    value={form[k]}
                    onChange={e =>
                      setForm({ ...form, [k]: e.target.value })
                    }
                  />
                  {errors[k] && (
                    <p className="text-xs text-red-500 mt-1">
                      {errors[k]}
                    </p>
                  )}
                </div>
              ))}
            </div>

            <button
              className="mt-8 w-full py-3 rounded-full text-white font-semibold
                         bg-gradient-to-r from-blue-600 to-indigo-600
                         shadow-xl hover:opacity-90 transition"
            >
              Complete & Login
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default LoginModal;
