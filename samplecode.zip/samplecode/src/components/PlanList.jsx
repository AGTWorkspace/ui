import React from "react";
import { useNavigate } from "react-router-dom";
import PlanCard from "./PlanCard";

/* ---------------- DEVICE CARD ---------------- */
const DeviceCard = ({ item }) => {
  const navigate = useNavigate();

  const handleBuy = () => {
    const user = JSON.parse(sessionStorage.getItem("mytelco_user"));

    const plan = {
      id: item.id,
      type: "device",
      title: item.offeringDetails?.name || "Device",
      price: typeof item.price === "number" ? `₹ ${item.price}` : item.price,
      data: "—",
      validity: "—",
      buttonText: "Buy Device",
      details: item.specification
        ? Object.entries(item.specification).map(
            ([k, v]) => `${k}: ${v}`
          )
        : [item.description || "—"]
    };

    // 🔐 NOT LOGGED IN → LOGIN REQUIRED
    if (!user?.isLoggedIn) {
      navigate("/login-required", {
        state: {
          plan,
          redirectTo: "/confirm-order"
        }
      });
      return;
    }

    // ✅ LOGGED IN → CONFIRM ORDER
    navigate("/confirm-order", { state: { plan } });
  };

  return (
    <div
      className="p-6 bg-white rounded-2xl shadow-xl border-t-8 border-primary
                 transition duration-300 hover:shadow-2xl hover:-translate-y-1
                 flex flex-col h-full font-poppins"
    >
      <h3 className="text-2xl font-extrabold mb-2 text-primary">
        {item.offeringDetails?.name}
      </h3>

      <p className="text-sm text-gray-600 mb-4">
        {item.description}
      </p>

      {item.specification && (
        <ul className="text-sm text-gray-700 space-y-1 mb-6">
          {Object.entries(item.specification).map(([k, v]) => (
            <li key={k}>
              <strong>{k}:</strong> {v}
            </li>
          ))}
        </ul>
      )}

      <div className="mt-auto">
        <div className="text-2xl font-black text-accent mb-4">
          {typeof item.price === "number"
            ? `₹ ${item.price}`
            : item.price}
        </div>

        {/* ✅ BUY NOW (LOGIN-PROTECTED) */}
        <button
          onClick={handleBuy}
          style={{ backgroundColor: "#007bff" }}
          className="w-full py-3 rounded-full text-white font-semibold
                     shadow-lg hover:opacity-90 transition duration-300"
        >
          Buy Now
        </button>
      </div>
    </div>
  );
};

/* ---------------- PLAN LIST ---------------- */
const PlanList = ({ items }) => {
  return (
    <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {items.map((item) => {
        if (
          ["pre-paid", "postpaid", "fiber-net", "entertainment", "bundle"].includes(
            item.category
          )
        ) {
          const plan = {
            id: item.id,
            type: item.category === "postpaid" ? "postpaid" : "prepaid",
            title:
              item.offeringDetails?.name ||
              item.offeringDetails?.plan?.serviceId,
            price:
              typeof item.price === "number"
                ? `₹ ${item.price}`
                : item.price,
            data: item.offeringDetails?.plan?.data || "—",
            validity: item.validityMonths
              ? `${item.validityMonths}m`
              : "—",
            badge: item.isRecurring ? "Recurring" : undefined,
            badgeColor: item.isRecurring ? "bg-accent" : "bg-primary",
            borderColor: item.borderColor || "",
            buttonClass: item.buttonClass || "bg-primary",
            buttonText: item.buttonText || "Choose Plan",
            details: item.offeringDetails?.plan?.features
              ? Object.keys(item.offeringDetails.plan.features).map((k) => {
                  const v = item.offeringDetails.plan.features[k];
                  return Array.isArray(v)
                    ? `${k}: ${v.join(", ")}`
                    : `${k}: ${v}`;
                })
              : ["—"]
          };

          return <PlanCard key={item.id} plan={plan} />;
        }

        return <DeviceCard key={item.id} item={item} />;
      })}
    </div>
  );
};

export default PlanList;
