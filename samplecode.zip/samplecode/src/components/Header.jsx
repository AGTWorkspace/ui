import React, { useState } from "react";
import { NavLink, useNavigate, useLocation } from "react-router-dom";
import { MapPin, LogOut, Search } from "lucide-react";

const Header = ({ isLoggedIn, mobileNumber, onShowLogin, onLogout }) => {
  const [locationInput, setLocationInput] = useState("");
  const navigate = useNavigate();
  const routeLocation = useLocation();

  /* ---------------- SEARCH ---------------- */
  const handleSearch = () => {
    if (!locationInput.trim()) return;

    const targetRoute = routeLocation.pathname.includes("postpaid")
      ? "/postpaid"
      : routeLocation.pathname.includes("recharge")
      ? "/recharge"
      : routeLocation.pathname;

    navigate(
      `${targetRoute}?location=${encodeURIComponent(locationInput.trim())}`
    );
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md font-poppins">
      <div className="flex items-center justify-between px-[5%] py-4">
        {/* LOGO */}
        <div
          className="text-3xl font-bold text-primary cursor-pointer"
          onClick={() => navigate("/")}
        >
          MyTelco
        </div>

        {/* NAV */}
        <nav className="hidden md:flex items-center space-x-6">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `font-semibold ${
                isActive ? "text-primary" : "text-gray-700"
              } hover:text-primary`
            }
          >
            Home
          </NavLink>

          <NavLink to="/recharge" className="font-semibold text-gray-700 hover:text-primary">
            Prepaid
          </NavLink>
          <NavLink to="/postpaid" className="font-semibold text-gray-700 hover:text-primary">
            Postpaid
          </NavLink>
          <NavLink to="/fiber" className="font-semibold text-gray-700 hover:text-primary">
            Fiber-net
          </NavLink>
          <NavLink to="/entertainment" className="font-semibold text-gray-700 hover:text-primary">
            Entertainment
          </NavLink>
          <NavLink to="/device" className="font-semibold text-gray-700 hover:text-primary">
            Devices
          </NavLink>
          <NavLink to="/bundle" className="font-semibold text-gray-700 hover:text-primary">
            Bundles
          </NavLink>

          {isLoggedIn && (
            <NavLink to="/orders" className="font-semibold text-gray-700 hover:text-primary">
              Orders
            </NavLink>
          )}

          <NavLink to="/support" className="font-semibold text-gray-700 hover:text-primary">
            Support
          </NavLink>

          {/* LOCATION SEARCH */}
          <div className="ml-4 flex items-center bg-gray-100 border border-gray-300 rounded-full px-4 py-2">
            <MapPin size={16} className="text-gray-600 mr-2" />

            <input
              type="text"
              value={locationInput}
              onChange={(e) => setLocationInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              placeholder="Enter your State"
              className="bg-transparent text-sm text-gray-800 focus:outline-none w-36"
            />

            {/* 🔍 SEARCH ICON BUTTON */}
            <button
            onClick={handleSearch}
             className="ml-2 w-9 h-9 flex items-center justify-center rounded-full
             text-gray-600 hover:text-primary
             hover:bg-gray-200 transition"
             title="Search"
             >
            <Search size={18} />
            </button>

          </div>
        </nav>

        {/* RIGHT */}
        <div className="flex items-center gap-3">
          {isLoggedIn ? (
            <>
              <div className="px-5 py-2 font-semibold text-primary border-2 border-primary rounded-full">
                Welcome, ***{mobileNumber.slice(-4)}
              </div>
              <button
                onClick={onLogout}
                className="flex items-center gap-1 px-4 py-2 text-sm font-semibold
                           text-red-600 border border-red-500 rounded-full hover:bg-red-50"
              >
                <LogOut size={16} />
                Logout
              </button>
            </>
          ) : (
            <button
              onClick={onShowLogin}
              className="px-6 py-3 font-semibold text-white rounded-full shadow-lg
                         bg-blue-600 hover:bg-blue-700 transition"
            >
              Login / Recharge
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
