// src/components/ChatbotWidget.jsx
import React, { useState, useRef, useEffect } from "react";
import { MessageSquare, Send, RefreshCw, X } from "lucide-react";
import { useNavigate } from "react-router-dom";

/* ---------------- MESSAGE BUBBLES ---------------- */

const BotMessage = ({ text, onLoginClick }) => {
  if (text === "__LOGIN_REQUIRED__") {
    return (
      <div className="flex flex-col items-start gap-1 animate-fadeIn">
        <div className="max-w-[86%] bg-white/90 backdrop-blur-md p-4 rounded-2xl border shadow-sm">
          <button
            onClick={onLoginClick}
            className="text-blue-600 font-semibold hover:underline"
          >
            🔒 Login required — Click here to login
          </button>
        </div>
        <span className="text-[10px] text-gray-400">Now</span>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-start gap-1 animate-fadeIn">
      <div className="max-w-[86%] bg-white/90 backdrop-blur-md p-4 rounded-2xl border shadow-sm">
        <p className="whitespace-pre-wrap text-sm text-gray-800">{text}</p>
      </div>
      <span className="text-[10px] text-gray-400">Now</span>
    </div>
  );
};

const UserMessage = ({ text }) => (
  <div className="flex flex-col items-end gap-1 animate-slideUp">
    <div className="max-w-[86%] bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-3 rounded-2xl shadow">
      <p className="text-sm">{text}</p>
    </div>
    <span className="text-[10px] text-gray-400">Now</span>
  </div>
);

/* ---------------- CHATBOT ---------------- */

const ChatbotWidget = ({ messages, addMessage, setMessages, onLoginClick, isLoggedIn }) => {
  const navigate = useNavigate();

  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState("");
  const textareaRef = useRef(null);
  const messagesEndRef = useRef(null);

  /* AUTO SCROLL */
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  /* ---------------- SEND MESSAGE ---------------- */
  const handleSendMessage = () => {
    const text = input.trim();
    if (!text) return;

    addMessage({ sender: "user", text });
    setInput("");
    textareaRef.current.style.height = "auto";

    if (!isLoggedIn) {
      setTimeout(() => {
        addMessage({ sender: "bot", text: "__LOGIN_REQUIRED__" });
      }, 300);
      return;
    }

    if (text.toLowerCase().includes("plan")) {
      addMessage({ sender: "bot", text: "Opening plan assistant for you 🚀" });

      // ✅ navigate first, then close widget
      navigate("/chatbot-assistant");
      return;
    }

    setTimeout(() => {
      addMessage({ sender: "bot", text: "Please type **plans** to continue." });
    }, 400);
  };

  const handleInputChange = (e) => {
    setInput(e.target.value);
    textareaRef.current.style.height = "auto";
    textareaRef.current.style.height = textareaRef.current.scrollHeight + "px";
  };

  const handleRestart = () => {
    setMessages([
      { id: Date.now(), sender: "bot", text: "Chat restarted. Type **plans** to explore again." }
    ]);
  };

  return (
    <>
      {/* CHAT WINDOW */}
      <div
        className={`fixed bottom-28 right-8 w-80 md:w-96 h-[560px]
        bg-white/80 backdrop-blur-xl rounded-3xl border shadow-2xl
        flex flex-col z-[999] transition-all duration-300
        ${isOpen ? "opacity-100 scale-100" : "opacity-0 scale-95 pointer-events-none"}`}
      >
        {/* HEADER */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-4 rounded-t-3xl flex justify-between items-center">
          <h2 className="font-semibold tracking-wide">MyTelco Assistant</h2>
          <X
            className="cursor-pointer opacity-80 hover:opacity-100"
            onClick={() => setIsOpen(false)}
          />
        </div>

        {/* MESSAGES */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 bg-gray-50/60">
          {messages.map((msg, idx) =>
            msg.sender === "bot" ? (
              <BotMessage
                key={idx}
                text={msg.text}
                onLoginClick={onLoginClick}
              />
            ) : (
              <UserMessage key={idx} text={msg.text} />
            )
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* INPUT */}
        <div className="p-4 border-t bg-white/80 backdrop-blur-md rounded-b-3xl">
          <div className="flex gap-2 items-end">
            <textarea
              ref={textareaRef}
              rows="1"
              value={input}
              onChange={handleInputChange}
              onKeyDown={(e) =>
                e.key === "Enter" && !e.shiftKey && handleSendMessage()
              }
              placeholder="Type your message..."
              className="flex-1 px-4 py-2 rounded-2xl border bg-gray-100
              resize-none focus:ring-2 focus:ring-blue-500 outline-none text-sm"
            />

            <button
              onClick={handleSendMessage}
              className="w-11 h-11 bg-gradient-to-r from-blue-600 to-indigo-600
              text-white rounded-full flex items-center justify-center
              hover:scale-105 transition"
            >
              <Send size={18} />
            </button>
          </div>

          <button
            onClick={handleRestart}
            className="mt-3 flex items-center gap-1 text-xs text-gray-500 hover:text-blue-600"
          >
            <RefreshCw size={12} /> Restart chat
          </button>
        </div>
      </div>

      {/* FLOATING BUTTON */}
      <div
        className="fixed bottom-8 right-8 w-16 h-16 rounded-full
        bg-gradient-to-r from-blue-600 to-indigo-600
        text-white flex items-center justify-center cursor-pointer
        shadow-xl hover:scale-110 transition animate-pulse"
        onClick={() => setIsOpen(true)}
      >
        <MessageSquare size={30} />
      </div>
    </>
  );
};

export default ChatbotWidget;
