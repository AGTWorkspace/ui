// src/components/chatbot/CategorySelector.jsx
import React from "react";

const categories = [
  { label: "Prepaid", value: "pre-paid", icon: "📱" },
  { label: "Postpaid", value: "postpaid", icon: "💼" },
  { label: "Fiber-net", value: "fiber-net", icon: "🌐" },
  { label: "Entertainment", value: "entertainment", icon: "🎬" },
  { label: "Devices", value: "device", icon: "📦" },
  { label: "Bundles", value: "bundles", icon: "🎁" }
];

const CategorySelector = ({ selected, setSelected, onSubmit, addMessage }) => {
  const toggle = (val) => {
    setSelected((prev) =>
      prev.includes(val) ? prev.filter((c) => c !== val) : [...prev, val]
    );
  };

  const handleContinue = () => {
    // ✅ Send to chatbot via addMessage
    addMessage({
      sender: "user",
      text: `📂 Selected Categories: ${selected.join(", ")}`
    });

    addMessage({
      sender: "bot",
      text: "Great 👍 Let me show you the best plans."
    });

    onSubmit();
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow border">
      <h3 className="text-xl font-semibold mb-4">
        Select categories you’re interested in
      </h3>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {categories.map(({ label, value, icon }) => {
          const active = selected.includes(value);

          return (
            <button
              key={value}
              onClick={() => toggle(value)}
              className={`flex flex-col items-center justify-center p-4 rounded-xl border transition-all
                ${
                  active
                    ? "bg-blue-600 text-white border-blue-600 shadow-md scale-[1.02]"
                    : "bg-gray-50 text-gray-800 hover:bg-gray-100"
                }`}
            >
              <span className="text-2xl mb-2">{icon}</span>
              <span className="font-medium">{label}</span>
            </button>
          );
        })}
      </div>

      <button
        onClick={handleContinue}
        disabled={!selected.length}
        className={`mt-6 w-full py-3 rounded-xl font-semibold transition
          ${
            selected.length
              ? "bg-blue-600 text-white hover:bg-blue-700"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          }`}
      >
        Continue
      </button>
    </div>
  );
};

export default CategorySelector;
