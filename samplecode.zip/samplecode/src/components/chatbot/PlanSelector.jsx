// src/components/chatbot/PlanSelector.jsx
import React from "react";
import { useNavigate } from "react-router-dom";

const PlanSelector = ({ categories, plansData, addMessage, setSelectedPlan }) => {
  const navigate = useNavigate();

  // Filter plans by selected categories
  const filteredPlans = plansData.filter((p) => categories.includes(p.category));

  const handleChoosePlan = (plan) => {
    const details = plan.offeringDetails || {};
    const planInfo = details.plan || {};

    const normalizedPlan = {
      title: details.name || "Selected Plan",
      price: `₹${plan.price}`,
      data: planInfo.data || "N/A",
      validity: plan.validityMonths ? `${plan.validityMonths} month(s)` : "N/A",
      rawPlan: plan, // optional (future use)
    };

    // Save selected plan in parent state
    setSelectedPlan(normalizedPlan);

    // Navigate to confirm order page
    navigate("/confirm-order", { state: { plan: normalizedPlan } });

    // ✅ Send to chatbot immediately
    addMessage({
      sender: "user",
      text: `📦 Selected Plan\n• ${normalizedPlan.title}\n• ${normalizedPlan.price}\n• ${normalizedPlan.data}\n• ${normalizedPlan.validity}`,
    });

    addMessage({
      sender: "bot",
      text: "Great choice! 🎉 Please confirm your order.",
    });
  };

  return (
    <div className="bg-white p-6 rounded-xl border">
      <h3 className="font-bold mb-4">Available Plans</h3>

      {filteredPlans.length === 0 && (
        <p className="text-gray-500">No plans available for the selected categories.</p>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPlans.map((plan) => {
          const details = plan.offeringDetails || {};
          const planInfo = details.plan || {};
          const deviceInfo = details.device || {};
          const isPostpaid = plan.category === "postpaid";

          return (
            <div
              key={plan.id}
              className="p-6 bg-white rounded-2xl shadow-xl border border-gray-200 transition duration-300 hover:shadow-2xl hover:-translate-y-1 flex flex-col"
            >
              {/* Title */}
              <h4 className="mb-3 text-lg font-bold text-primary border-b border-gray-100 pb-2">
                {details.name}
              </h4>

              {/* Price */}
              <div className="text-center mb-4">
                <small className="block text-sm text-gray-600">Price</small>
                <strong className="block text-2xl font-black text-blue-600">
                  {plan.price ? `₹${plan.price}` : "N/A"}
                </strong>
              </div>

              {/* Data / Validity / Device */}
              {planInfo.data && (
                <p className="text-sm text-gray-700 mb-2">
                  <strong>Data:</strong> {planInfo.data}
                </p>
              )}
              {plan.validityMonths && (
                <p className="text-sm text-gray-700 mb-2">
                  <strong>Validity:</strong> {plan.validityMonths} month(s)
                </p>
              )}
              {deviceInfo.configuration && (
                <div className="text-sm text-gray-700 mb-2">
                  <strong>Device Config:</strong>{" "}
                  {Object.entries(deviceInfo.configuration)
                    .map(([k, v]) => `${k}: ${v}`)
                    .join(", ")}
                </div>
              )}

              {/* Description */}
              {plan.description && (
                <p className="text-xs text-gray-500 mb-3">{plan.description}</p>
              )}

              {/* Features */}
              {planInfo.features && (
                <details className="mt-2 pt-2 border-t border-gray-200">
                  <summary className="cursor-pointer font-semibold text-primary hover:text-black">
                    View Features
                  </summary>
                  <div className="pt-2 space-y-1 text-sm text-gray-700">
                    {Object.entries(planInfo.features).map(([k, v], index) => (
                      <div key={index} className="flex items-start">
                        <svg
                          className="w-4 h-4 mr-2 mt-1 text-green-500"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <circle cx="10" cy="10" r="10" />
                        </svg>
                        <p>
                          {k}: {Array.isArray(v) ? v.join(", ") : v.toString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </details>
              )}

              {/* CTA */}
              <button
                onClick={() => handleChoosePlan(plan)}
                className="mt-auto w-full py-2 font-semibold text-white rounded-full shadow-lg bg-blue-600 hover:bg-blue-700 transition duration-300"
              >
                {isPostpaid ? "Get New Connection" : "Proceed"}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PlanSelector;
